/* Shared UI pieces + pages used by both roles (comparison chart, password, help). */
(function () {
  "use strict";
  var A = window.A, html = A.html, icon = A.icon;
  var U = (A.ui = {});

  U.head = function (title, sub, actions) {
    return html`<div class="page-head"><div><h2>${title}</h2>${sub ? html`<p>${sub}</p>` : ""}</div>${actions || ""}</div>`;
  };
  U.empty = function (ic, text) { return html`<div class="empty">${icon(ic, 36)}<p>${text}</p></div>`; };
  U.tabs = function (base, items, active) {
    return html`<div class="tabs">${items.map(function (t) {
      return html`<a class="tab ${t.key === active ? "active" : ""}" href="${A.link(base + "?tab=" + t.key)}">${icon(t.icon, 16)} ${t.label}${t.badge ? html` <span class="badge-dot">${t.badge}</span>` : ""}</a>`;
    })}</div>`;
  };
  U.avatarOf = function (p, size) { return A.avatar(p, size); };
  U.bars = function (chart) {
    return html`<div class="card">${chart.length ? html`<div class="bar-chart">${chart.map(function (r) {
      return html`<div class="bar-row"><div class="lbl"><b>${r.label}</b><span class="muted small">${r.sub} · ${r.detail}</span></div>
        <div class="bar-track"><div class="bar-fill ${A.tone(r.pct)}" data-w="${r.pct.toFixed(1)}"></div><div class="bar-mark" title="75% target"></div></div>
        <div class="bar-val ${r.pct < 75 ? "text-bad" : ""}">${r.pct}%</div></div>`;
    })}</div><p class="muted small mt-3">The vertical line marks the 75% minimum attendance target.</p>` : U.empty("bar-chart", "No attendance data to compare yet.")}</div>`;
  };

  // ---- PWA install prompt (browser only)
  window.addEventListener("beforeinstallprompt", function (e) { e.preventDefault(); A.installEvt = e; if (A.S.profile) A.render(false); });
  A.acts.install = function () {
    if (!A.installEvt) return;
    A.installEvt.prompt();
    A.installEvt.userChoice.then(function () { A.installEvt = null; A.render(false); });
  };

  // ---- change password (both roles)
  A.route("account/password", null, function () {
    return html`${U.head("Change password", "Keep your account secure with a fresh password.")}
      <div class="card" style="max-width:560px"><form data-form="changePw" class="grid" style="gap:14px">
        <div class="field"><label>Old password</label><input class="input" type="password" name="old" required autocomplete="current-password"></div>
        <div class="field"><label>New password</label><input class="input" type="password" name="new" required minlength="6" autocomplete="new-password"></div>
        <div class="field"><label>Confirm new password</label><input class="input" type="password" name="confirm" required autocomplete="new-password"></div>
        <div class="form-actions"><button class="btn purple" type="submit">${icon("lock", 18)} Update password</button></div></form></div>`;
  });
  A.forms.changePw = function (f, fd) {
    if (fd.get("new").length < 6) throw new Error("New password is too short (minimum 6 characters).");
    if (fd.get("new") !== fd.get("confirm")) throw new Error("New passwords do not match.");
    return A.svc.changePassword(fd.get("old"), fd.get("new")).then(function () { f.reset(); A.toast("Password changed successfully."); });
  };

  // ---- help
  A.route("account/help", null, function () {
    var inApp = !!window.AndroidBridge;
    return html`${U.head("Help & support", "Tell us what you need and we will get back to you.")}
      <div class="card mb-3" style="max-width:680px"><h3 class="mb-2">${icon("download", 18)} Get the app on your phone</h3>
        ${inApp ? html`<p class="muted small">You are using the Acadance Android app.</p>` : html`
          <p class="muted small mb-2">Acadance can be installed like a normal app - no app store needed.</p>
          ${A.installEvt ? html`<button class="btn mb-2" data-act="install">${icon("download", 16)} Install Acadance</button>` : ""}
          <ul class="small muted" style="margin:0;padding-left:18px;line-height:1.8"><li><b>Android (Chrome):</b> menu ⋮ → <b>Install app</b> / <b>Add to Home screen</b>.</li>
          <li><b>iPhone (Safari):</b> Share → <b>Add to Home Screen</b>.</li></ul>`}
        <p class="small muted mt-2">${A.cloud ? "Your data is stored in the cloud and appears on every device you sign in on." : "Demo mode: your data is stored only on this device."}</p></div>
      <div class="card" style="max-width:680px"><h3 class="mb-2">Contact support</h3>
        <form data-form="support" class="grid" style="gap:14px">
          <div class="field"><label>Subject</label><input class="input" name="subject" placeholder="What is this about?"></div>
          <div class="field"><label>Message</label><textarea class="input" name="message" rows="6" placeholder="Describe your problem or question…" required></textarea></div>
          <div class="form-actions"><button class="btn" type="submit">${icon("send", 18)} Send message</button></div></form></div>`;
  });
  A.forms.support = function (f, fd) {
    return A.svc.support(fd.get("subject"), fd.get("message")).then(function () { f.reset(); A.toast("Support request sent. We will get back to you soon."); });
  };

  // ---- profile picture (resized in the browser, stored in the user's own document)
  A.acts.photo = function (el) {
    var file = el.files && el.files[0];
    if (!file) return;
    if (!/^image\//.test(file.type)) { A.toast("Only image files are allowed.", "error"); return; }
    var img = new Image(), url = URL.createObjectURL(file);
    img.onload = function () {
      var s = 256, c = document.createElement("canvas"), r = Math.min(img.width, img.height), ctx = c.getContext("2d");
      c.width = c.height = s;
      ctx.drawImage(img, (img.width - r) / 2, (img.height - r) / 2, r, r, 0, 0, s, s);
      URL.revokeObjectURL(url);
      A.svc.setPhoto(c.toDataURL("image/jpeg", 0.82)).then(function () { A.toast("Profile picture updated."); }, function (e) { A.toast(A.errMsg(e), "error"); });
    };
    img.src = url;
  };
  A.acts["photo-pick"] = function () { document.getElementById("photo-input").click(); };
  A.acts["photo-remove"] = function () { return A.svc.setPhoto(null).then(function () { A.toast("Profile picture removed."); }); };
  U.picCard = function (p) {
    return html`<div class="flex" style="flex-direction:column;align-items:center;gap:14px">${A.avatar(p, 140)}
      <input type="file" id="photo-input" accept="image/*" class="hidden" data-change="photo" data-nodirty>
      <button class="btn sm" data-act="photo-pick">${icon("camera", 16)} Change picture</button>
      ${p.photo ? html`<button class="btn ghost sm" data-act="photo-remove">Remove</button>` : ""}</div>`;
  };
})();
