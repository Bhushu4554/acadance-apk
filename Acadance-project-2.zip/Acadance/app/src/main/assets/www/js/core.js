/* Acadance core helpers: safe HTML templating, formatting, toasts, modals, downloads. */
(function () {
  "use strict";
  var A = (window.A = window.A || {});

  // ------------------------------------------------------------------ safe templating
  // A.html`...${value}...` escapes every inserted value unless it is itself the result of A.html / A.raw.
  function Raw(s) { this.s = s; }
  var ESC = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
  A.esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return ESC[c]; }); };
  A.raw = function (s) { return new Raw(s); };
  function fmt(v) {
    if (v === null || v === undefined || v === false || v === true) return "";
    if (v instanceof Raw) return v.s;
    if (Array.isArray(v)) return v.map(fmt).join("");
    return A.esc(v);
  }
  A.html = function (strings) {
    var out = strings[0];
    for (var i = 1; i < strings.length; i++) out += fmt(arguments[i]) + strings[i];
    return new Raw(out);
  };
  A.str = function (v) { return fmt(v); };
  A.each = function (list, fn, empty) {
    if (!list || !list.length) return empty || "";
    return list.map(fn);
  };

  // ------------------------------------------------------------------ misc helpers
  A.newId = function () { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); };
  A.natCmp = function (a, b) { return String(a).localeCompare(String(b), undefined, { numeric: true }); };
  A.pct = function (p, t) { return t ? Math.round((p * 1000) / t) / 10 : 0; };
  A.tone = function (v) { v = +v || 0; return v >= 85 ? "good" : v >= 75 ? "warn" : "bad"; };
  A.clamp = function (v, lo, hi) { return Math.max(lo, Math.min(hi, v)); };
  A.int = function (v) { var n = parseInt(String(v).trim(), 10); return isNaN(n) ? null : n; };
  A.initial = function (name) { return ((name || "U").trim()[0] || "U").toUpperCase(); };
  A.uniq = function (arr) { return arr.filter(function (x, i) { return arr.indexOf(x) === i; }); };

  /** Same 75% rule as the original app: how many classes can still be missed / must be attended. */
  A.advice = function (present, total) {
    if (!total) return null;
    var p = (present * 100) / total;
    if (p >= 75) {
      var spare = Math.floor((4 * present - 3 * total) / 3);
      if (spare <= 0) return { tone: "warn", text: "Right at the 75% limit - try not to miss the next class." };
      return { tone: "good", text: "You can miss up to " + spare + " more class" + (spare === 1 ? "" : "es") + " and stay at or above 75%." };
    }
    var need = Math.max(1, 3 * total - 4 * present);
    return { tone: "bad", text: "Attend the next " + need + " class" + (need === 1 ? "" : "es") + " in a row to get back to 75%." };
  };

  // ------------------------------------------------------------------ dates (stored as "YYYY-MM-DD" text)
  var MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  function p2(n) { return (n < 10 ? "0" : "") + n; }
  A.today = function () { var d = new Date(); return d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate()); };
  A.parseD = function (s) { var x = s.split("-").map(Number); return new Date(x[0], x[1] - 1, x[2]); };
  A.dmy = function (s) { return s ? s.slice(8, 10) + "-" + s.slice(5, 7) + "-" + s.slice(2, 4) : ""; };
  A.dLong = function (s) { if (!s) return ""; var d = A.parseD(s); return d.getDate() + " " + MON[d.getMonth()] + " " + d.getFullYear(); };
  A.dShort = function (s) { if (!s) return ""; var d = A.parseD(s); return d.getDate() + " " + MON[d.getMonth()]; };
  A.dow = function (s) { return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][A.parseD(s).getDay()]; };
  A.time12 = function (hhmm) {
    var x = (hhmm || "00:00").split(":").map(Number);
    return ((x[0] + 11) % 12 + 1) + ":" + p2(x[1]) + " " + (x[0] >= 12 ? "PM" : "AM");
  };
  A.ts = function (ms) {
    if (!ms) return "";
    var d = new Date(ms), h = d.getHours();
    return d.getDate() + " " + MON[d.getMonth()] + ", " + ((h + 11) % 12 + 1) + ":" + p2(d.getMinutes()) + " " + (h >= 12 ? "PM" : "AM");
  };
  A.tsLong = function (ms) { var d = new Date(ms); return d.getDate() + " " + MON[d.getMonth()] + " " + d.getFullYear() + ", " + A.ts(ms).split(", ")[1]; };
  /** Monday = 0 ... Saturday = 5, Sunday = -1 */
  A.todayIndex = function () { var d = new Date().getDay(); return d === 0 ? -1 : d - 1; };
  A.nowHM = function () { var d = new Date(); return p2(d.getHours()) + ":" + p2(d.getMinutes()); };
  A.DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

  // ------------------------------------------------------------------ toasts
  A.toast = function (msg, type) {
    var box = document.getElementById("toasts");
    if (!box) return;
    var el = document.createElement("div");
    el.className = "toast " + (type || "success");
    el.textContent = msg;
    box.appendChild(el);
    var kill = function () { el.classList.add("leaving"); setTimeout(function () { el.remove(); }, 320); };
    setTimeout(kill, type === "error" ? 6000 : 4200);
    el.addEventListener("click", kill);
  };

  // ------------------------------------------------------------------ modal (one host element)
  A.openModal = function (content, cls) {
    var host = document.getElementById("modal-host");
    host.innerHTML = '<div class="modal-overlay show" data-overlay><div class="modal ' + (cls || "") + '">' + A.str(content) + "</div></div>";
    var f = host.querySelector("[autofocus]");
    if (f) setTimeout(function () { f.focus(); }, 60);
  };
  A.closeModal = function () {
    var host = document.getElementById("modal-host");
    host.innerHTML = "";
    if (A.onModalClosed) A.onModalClosed();
  };
  A.modalOpen = function () { return !!document.querySelector("#modal-host .modal-overlay"); };
  A.confirm = function (title, message, okLabel) {
    return new Promise(function (resolve) {
      A.openModal(A.html`<h3>${title}</h3><p class="muted mt-2">${message}</p>
        <div class="form-actions mt-3"><button class="btn ghost" data-act="confirm-no">Cancel</button>
        <button class="btn danger" data-act="confirm-yes">${okLabel || "Confirm"}</button></div>`, "small");
      A._confirmResolve = function (v) { A._confirmResolve = null; A.closeModal(); resolve(v); };
    });
  };

  // ------------------------------------------------------------------ downloads (browser + Android app)
  A.download = function (filename, text, mime) {
    mime = mime || "text/csv;charset=utf-8";
    if (window.AndroidBridge && window.AndroidBridge.saveFile) {
      var b64 = btoa(unescape(encodeURIComponent("\ufeff" + text)));
      window.AndroidBridge.saveFile(filename, mime.split(";")[0], b64);
      return;
    }
    var blob = new Blob(["\ufeff" + text], { type: mime });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  };
  A.csv = function (rows) {
    return rows.map(function (r) {
      return r.map(function (c) {
        c = c === null || c === undefined ? "" : String(c);
        return /[",\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c;
      }).join(",");
    }).join("\r\n");
  };
  A.slug = function (s) { return String(s || "file").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "file"; };
})();
