/* Teacher pages. */
(function () {
  "use strict";
  var A = window.A, html = A.html, icon = A.icon, U = A.ui;
  function P() { return A.S.profile; }
  function roster(d) { return d.roster.slice().sort(function (a, b) { return A.natCmp(a.roll, b.roll); }); }
  function allDates(d) {
    var s = {}; d.roster.forEach(function (r) { Object.keys(A.q.records(d.id, r.uid)).forEach(function (x) { s[x] = 1; }); });
    return Object.keys(s).sort();
  }
  function divStats(d) {
    var p = 0, t = 0;
    d.roster.forEach(function (r) { var s = A.q.attStats(r.uid, [d.id]); p += s.present; t += s.total; });
    return { present: p, total: t, pct: A.pct(p, t) };
  }

  // ------------------------------------------------------------------ home
  A.route("teacher/home", "teacher", function () {
    var divs = A.q.divs(), divIds = divs.map(function (d) { return d.id; }), uids = [];
    divs.forEach(function (d) { uids = uids.concat(d.studentUids); }); uids = A.uniq(uids);
    var ranked = uids.map(function (u) { var s = A.q.attStats(u, divIds); s.uid = u; return s; }).filter(function (s) { return s.total > 0; }).sort(function (a, b) { return a.pct - b.pct; });
    var below = ranked.filter(function (r) { return r.pct < 75; }).length;
    var per = {};
    A.store.attendance.forEach(function (doc) { var r = doc.records || {}; Object.keys(r).forEach(function (x) { var o = per[x] || (per[x] = [0, 0]); o[1]++; if (r[x]) o[0]++; }); });
    var trend = Object.keys(per).sort().slice(-10).map(function (x) { return { label: A.dShort(x), pct: A.pct(per[x][0], per[x][1]) }; });
    var today = [];
    A.store.timetables.forEach(function (tt) { A.todays(tt).forEach(function (l) { if (!l.isBreak) { l.division = tt.divisionName; today.push(l); } }); });
    today.sort(function (a, b) { return a.slot.start < b.slot.start ? -1 : 1; });
    var acts = ((A.S.feed && A.S.feed.activity) || []).slice(0, 10);
    return html`<div class="card hero-card mb-3"><div class="flex justify-between gap-2 wrap items-center"><div><div class="eyebrow" style="color:#fcd34d">Teacher dashboard</div>
      <h2 style="font-size:24px">Welcome back, ${P().name}</h2><p class="muted mt-1">Manage divisions, take attendance, grade students and keep everyone informed.</p></div>
      <div class="flex gap-2 wrap"><a class="btn warn" href="${A.link("teacher/attendance")}">${icon("calendar", 17)} Take attendance</a><a class="btn ghost" href="${A.link("teacher/comm")}">${icon("megaphone", 17)} Post announcement</a></div></div></div>
    <div class="grid cols-3 home-stats mb-3"><div class="stat"><div class="ico">${icon("book", 20)}</div><div class="label">Divisions</div><div class="value">${divs.length}</div><div class="hint">you manage</div></div>
      <div class="stat tone-good"><div class="ico">${icon("users", 20)}</div><div class="label">Students</div><div class="value">${uids.length}</div><div class="hint">across all divisions</div></div>
      <div class="stat tone-bad"><div class="ico">${icon("trending-down", 20)}</div><div class="label">Below 75%</div><div class="value">${below}</div><div class="hint">need attention</div></div></div>
    <div class="grid cols-2">
      <div class="card"><div class="card-head"><div><h3>Attendance trend</h3><div class="sub">Average of the last ${trend.length} recorded days</div></div></div>
        ${trend.length ? html`<div class="columns">${trend.map(function (t) { return html`<div class="col"><div class="col-val">${Math.round(t.pct)}%</div><div class="col-bar ${A.tone(t.pct)}" data-h="${t.pct.toFixed(1)}"></div><div class="col-lbl">${t.label}</div></div>`; })}</div>` : U.empty("bar-chart", "Save attendance for a division to see the trend.")}</div>
      <div class="card"><div class="card-head"><div><h3>Today's classes</h3><div class="sub">From your timetables</div></div><a class="btn ghost sm" href="${A.link("teacher/schedule")}">Timetables</a></div>
        ${A.each(today, function (l) { return html`<div class="today-row ${l.isNow ? "now" : ""}"><div class="today-time">${A.time12(l.slot.start)} – ${A.time12(l.slot.end)}</div><div class="grow today-subj">${l.subject} <span class="muted small">· ${l.division}</span></div>${l.isNow ? html`<span class="badge info">Now</span>` : ""}</div>`; }, html`<p class="muted small">No lectures scheduled for today.</p>`)}</div>
      <div class="card"><div class="card-head"><div><h3>Needs attention</h3><div class="sub">Lowest attendance first</div></div></div><div class="list">${A.each(ranked.slice(0, 5), function (r) {
        var s = A.q.stu(r.uid);
        return html`<div class="item" style="align-items:center">${A.avatar(s, 38)}<div class="grow"><h4>${s.name} <span class="muted small">(${s.prn || "no PRN"})</span></h4><div class="progress mt-1"><span class="${A.tone(r.pct)}" data-w="${r.pct.toFixed(1)}"></span></div></div>
          <b class="${r.pct < 75 ? "text-bad" : "text-good"}">${r.pct}%</b>${r.pct < 75 ? html`<button class="btn sm warn" data-act="remind" data-uid="${r.uid}" title="Send reminder">${icon("send", 14)}</button>` : ""}</div>`;
      }, html`<p class="muted small">No attendance data yet - save attendance for a division to see this list.</p>`)}</div></div>
      <div class="card"><div class="card-head"><h3>${icon("activity", 17)} Activity</h3></div><div class="list" style="gap:9px">${A.each(acts, function (a) { return html`<div class="small"><span class="muted">${A.ts(a.ts)}</span> — ${a.text}</div>`; }, html`<p class="muted small">No activity yet.</p>`)}</div></div>
    </div>`;
  });
  A.acts.remind = function (el) {
    var uid = el.getAttribute("data-uid");
    return A.confirm("Send reminder", "Send an attendance reminder message to " + A.q.stu(uid).name + "?", "Send").then(function (ok) {
      if (ok) return A.svc.sendReminder(uid).then(function () { A.toast("Reminder sent to " + A.q.stu(uid).name + "."); });
    });
  };

  // ------------------------------------------------------------------ divisions
  A.route("teacher/attendance", "teacher", function () {
    var divs = A.q.divs();
    return html`${U.head("Attendance & division management", "Select a division to take attendance, or create a new one.", html`<button class="btn" data-act="new-div">${icon("plus", 18)} Create new division</button>`)}
      <div class="grid cols-3">${A.each(divs, function (d) {
        var s = divStats(d), dates = allDates(d).length;
        return html`<a class="card" href="${A.link("teacher/attendance/" + d.id)}" style="color:inherit;text-decoration:none"><div class="flex justify-between gap-2"><h3 style="font-size:22px">${d.name}</h3><span class="badge ${A.tone(s.pct)}">${s.pct}%</span></div>
          <p class="muted">${d.subject}</p><div class="chip-row mt-2"><span class="chip">${d.program}</span><span class="chip">${d.sem}</span><span class="chip">${d.year}</span></div>
          <div class="flex justify-between mt-3 small muted"><span>${icon("users", 14)} ${d.roster.length} students</span><span>${icon("calendar", 14)} ${dates} dates</span></div></a>`;
      }, html`<div style="grid-column:1/-1">${U.empty("book", "You haven't created any divisions yet.")}</div>`)}</div>`;
  });
  A.acts["new-div"] = function () {
    function f(l, n, extra) { return html`<div class="field ${extra || ""}"><label>${l}</label><input class="input" name="${n}" required></div>`; }
    A.openModal(html`<div class="modal-head"><h3>Create new division</h3><button class="icon-btn" data-act="close-modal" aria-label="Close">${icon("x", 18)}</button></div>
      <form data-form="createDivision" class="form-grid"><div class="field"><label>Division name</label><input class="input" name="name" placeholder="e.g. SY-A" required autofocus></div>
        ${f("Subject", "subject")}<div class="field"><label>Faculty name</label><input class="input" name="faculty" value="${P().name}" required></div>${f("Program", "program")}
        <div class="field"><label>Semester</label><input class="input" name="sem" placeholder="e.g. SEM-IV" required></div><div class="field"><label>Year</label><input class="input" name="year" placeholder="e.g. 2025-26" required></div>
        ${f("School name", "school", "span-2")}<div class="form-actions span-2"><button class="btn ghost" type="button" data-act="close-modal">Cancel</button><button class="btn" type="submit">Create division</button></div></form>`);
  };
  A.forms.createDivision = function (f, fd) {
    var o = {}; fd.forEach(function (v, k) { o[k] = v; });
    return A.svc.createDivision(o).then(function () { A.closeModal(); A.toast("Division " + o.name + " created successfully!"); });
  };

  // ------------------------------------------------------------------ attendance sheet
  A.route("teacher/attendance/:id", "teacher", function (ctx) {
    var d = A.q.div(ctx.params.id);
    if (!d) return html`${U.head("Division not found", "")}<a class="btn ghost" href="${A.link("teacher/attendance")}">Back to divisions</a>`;
    var dates = allDates(d), rs = roster(d);
    return html`<a class="btn ghost sm mb-3" href="${A.link("teacher/attendance")}">${icon("arrow-left", 16)} Back to divisions</a>
      ${U.head(html`${d.name} <span class="muted" style="font-weight:500">(${d.subject})</span>`, d.school + " · " + d.program + " · " + d.sem + " · " + d.year + " · Faculty: " + d.faculty,
        html`<div class="flex gap-2 wrap"><button class="btn ghost sm" data-act="att-csv" data-id="${d.id}">${icon("download", 15)} Download CSV</button><button class="btn danger sm" data-act="del-div" data-id="${d.id}">${icon("trash", 15)} Delete division</button></div>`)}
      <div class="grid cols-2 mb-3"><div class="card"><h3 class="mb-2">Add student to division</h3><form data-form="addStudent" class="flex gap-2 wrap"><input type="hidden" name="div" value="${d.id}">
        <input class="input grow" name="prn" placeholder="Student PRN" required><input class="input" style="width:150px" name="roll" placeholder="Roll no." required><button class="btn success" type="submit">${icon("user-plus", 16)} Find &amp; add</button></form></div>
        <div class="card"><h3 class="mb-1">Quick mark present</h3><p class="muted small mb-2">Roll numbers separated by commas — everyone else becomes absent.</p>
          <div class="flex gap-2"><input class="input grow" id="quick-rolls" placeholder="e.g. 1, 5, 12, 18" data-nodirty><button class="btn purple" data-act="quick-mark">Mark</button></div></div></div>
      <div class="card pad-0"><div class="card-head" style="padding:18px 22px 0"><h3>Attendance sheet</h3>
        <label class="flex items-center gap-2" style="font-weight:600"><input type="checkbox" class="cb" id="record-new"> Record a new date: <input class="input" style="width:auto" type="date" id="new-date" value="${A.today()}"></label></div>
        <div class="flex items-center justify-between gap-2 wrap" style="padding:4px 22px 14px"><p class="muted small">Click any <b>P</b> / <b>A</b> to flip it. Tick “Record a new date” to add a column for that day, then press <b>Save</b>.</p>
          <input class="input tbl-search" type="search" placeholder="Search name, PRN or roll…" data-filter="#sheet-body"></div>
        <div class="table-wrap" style="border:0;border-top:1px solid var(--border);border-radius:0"><table class="tbl"><thead><tr><th>Roll</th><th>Name</th><th>PRN</th>${dates.map(function (x) { return html`<th class="c">${A.dmy(x)}</th>`; })}<th class="c">%</th>
          <th class="c" style="background:var(--primary-50);color:var(--primary)"><div>New date</div><label class="small" style="text-transform:none;font-weight:600"><input type="checkbox" class="cb" id="mark-all"> all present</label></th><th></th></tr></thead>
          <tbody id="sheet-body">${A.each(rs, function (r) {
            var s = A.q.stu(r.uid), rec = A.q.records(d.id, r.uid), st = A.q.attStats(r.uid, [d.id]);
            return html`<tr><td class="bold">${r.roll}</td><td>${s.name}</td><td><button type="button" class="link-btn" data-act="student-modal" data-uid="${r.uid}">${s.prn || "—"}</button></td>
              ${dates.map(function (x) { var v = rec[x] === true ? "P" : rec[x] === false ? "A" : "-"; return html`<td class="att-cell"><button type="button" class="att-btn ${v}" data-act="flip" data-uid="${r.uid}" data-date="${x}" data-orig="${v}">${v}</button></td>`; })}
              <td class="c bold ${st.total && st.pct < 75 ? "text-bad" : ""}">${st.total ? st.pct + "%" : "—"}</td>
              <td class="c" style="background:color-mix(in srgb,var(--primary-50) 50%,transparent)"><input type="checkbox" class="cb new-cb" data-uid="${r.uid}" data-roll="${r.roll}"></td>
              <td><div class="row-tools"><button type="button" class="btn ghost sm" title="Remove from division" data-act="rm-student" data-div="${d.id}" data-uid="${r.uid}">${icon("trash", 14)}</button></div></td></tr>`;
          }, html`<tr><td colspan="${dates.length + 6}" class="center muted" style="padding:30px">No students yet — add one by PRN above.</td></tr>`)}</tbody></table></div>
        <div class="form-actions" style="padding:16px 22px"><button class="btn" data-act="save-att" data-id="${d.id}">${icon("check", 18)} Save all attendance data</button></div></div>`;
  });
  A.acts.flip = function (el) { var n = el.textContent.trim() === "P" ? "A" : "P"; el.textContent = n; el.className = "att-btn " + n; A.dirty = true; };
  document.addEventListener("change", function (e) {
    if (e.target.id === "mark-all") { document.querySelectorAll(".new-cb").forEach(function (c) { c.checked = e.target.checked; }); document.getElementById("record-new").checked = true; }
    else if (e.target.classList && e.target.classList.contains("new-cb") || e.target.id === "new-date") { var r = document.getElementById("record-new"); if (r) r.checked = true; }
  });
  A.acts["quick-mark"] = function () {
    var raw = document.getElementById("quick-rolls").value.trim();
    if (!raw) throw new Error("Please enter roll numbers to quick mark.");
    var rolls = raw.split(",").map(function (x) { return x.trim(); }).filter(Boolean), boxes = document.querySelectorAll(".new-cb"), all = true;
    boxes.forEach(function (c) { c.checked = rolls.indexOf(c.getAttribute("data-roll")) > -1; if (!c.checked) all = false; });
    document.getElementById("mark-all").checked = all && boxes.length > 0; document.getElementById("record-new").checked = true; A.dirty = true;
    A.toast("Marked " + rolls.length + " roll number(s) as present. Remember to save.");
  };
  A.acts["save-att"] = function (el) {
    var edits = {};
    document.querySelectorAll('[data-act="flip"]').forEach(function (b) {
      var cur = b.textContent.trim();
      if (cur !== b.getAttribute("data-orig") && (cur === "P" || cur === "A")) { var u = b.getAttribute("data-uid"); (edits[u] = edits[u] || {})[b.getAttribute("data-date")] = cur === "P"; }
    });
    var rec = document.getElementById("record-new").checked, nd = document.getElementById("new-date").value;
    var present = Array.prototype.map.call(document.querySelectorAll(".new-cb:checked"), function (c) { return c.getAttribute("data-uid"); });
    return A.svc.saveAttendance(el.getAttribute("data-id"), edits, rec && nd ? nd : null, present).then(function (warn) {
      A.toast("Attendance saved!"); if (warn) A.toast(warn, "warning"); A.refresh();
    });
  };
  A.forms.addStudent = function (f, fd) {
    return A.svc.addStudent(fd.get("div"), fd.get("prn"), fd.get("roll")).then(function (name) { f.reset(); A.toast(name + " added."); });
  };
  A.acts["rm-student"] = function (el) {
    var d = A.q.div(el.getAttribute("data-div")), uid = el.getAttribute("data-uid"), name = A.q.stu(uid).name;
    return A.confirm("Remove student", "Remove " + name + " from " + d.name + "? Their attendance and marks in this division will be deleted.", "Remove").then(function (ok) {
      if (ok) return A.svc.removeStudent(d.id, uid).then(function () { A.dirty = false; A.toast(name + " was removed from " + d.name + "."); });
    });
  };
  A.acts["del-div"] = function (el) {
    var d = A.q.div(el.getAttribute("data-id"));
    return A.confirm("Delete division", "Delete division " + d.name + "? All its students, attendance, grade sheets and timetable will be removed.", "Delete").then(function (ok) {
      if (ok) return A.svc.deleteDivision(d.id).then(function () { A.toast('Division "' + d.name + '" and all its data were deleted.'); A.go("teacher/attendance"); });
    });
  };
  A.acts["att-csv"] = function (el) {
    var d = A.q.div(el.getAttribute("data-id")), dates = allDates(d), out = [["Roll", "Name", "PRN"].concat(dates, ["Present", "Total", "Percent"])];
    roster(d).forEach(function (r) {
      var rec = A.q.records(d.id, r.uid), s = A.q.stu(r.uid), st = A.q.attStats(r.uid, [d.id]);
      out.push([r.roll, s.name, s.prn].concat(dates.map(function (x) { return rec[x] === true ? "P" : rec[x] === false ? "A" : ""; }), [st.present, st.total, st.pct]));
    });
    A.download("attendance_" + A.slug(d.name) + ".csv", A.csv(out));
  };

  // ---- student profile pop-up
  A.acts["student-modal"] = function (el) {
    var uid = el.getAttribute("data-uid"), divIds = A.store.divisions.map(function (d) { return d.id; });
    return A.DB.get("users", uid).then(function (s) {
      if (!s) throw new Error("Student not found.");
      var st = A.q.attStats(uid, divIds), tone = A.tone(st.pct), color = tone === "good" ? "#22c55e" : tone === "warn" ? "#f59e0b" : "#ef4444";
      var hist = A.store.gradeItems.filter(function (g) { return g.studentUids.indexOf(uid) > -1; }).map(function (g) { return { g: g, r: A.grade(A.q.mark(g.id, uid), g.finalMax) }; });
      function kv(k, v) { return html`<dt>${k}</dt><dd>${v || "Not provided"}</dd>`; }
      var prog = s.program ? s.program + (s.specialization ? " (" + s.specialization + ")" : "") : "";
      A.openModal(html`<div class="modal-head"><h3>Student profile</h3><button class="icon-btn" data-act="close-modal" aria-label="Close">${icon("x", 18)}</button></div>
        <div class="modal-page active" data-page="profile"><div class="center"><div class="ring-wrap"><svg viewBox="0 0 160 160"><circle class="track" cx="80" cy="80" r="75" fill="none" stroke-width="10"/>
          <circle class="bar" id="ring" cx="80" cy="80" r="75" fill="none" stroke-width="10" stroke-linecap="round" stroke="${color}" style="stroke-dasharray:471;stroke-dashoffset:471"/></svg>${A.avatar(s, 104)}</div>
          <h3 style="font-size:22px" class="mt-2">${s.name}</h3><p class="bold mt-1">Attendance: ${st.pct}% <span class="muted small">(${st.present}/${st.total} classes)</span></p></div>
          <dl class="kv mt-3">${kv("PRN", s.prn)}${kv("ABC ID", s.abcId)}${kv("Program", prog)}${kv("Year & sem", s.yearSem)}${kv("Division", s.division)}${kv("Mobile", s.mobile)}${kv("Date of birth", s.dob ? A.dLong(s.dob) : "")}${kv("Aadhaar", s.aadhaar)}${kv("Address", s.address)}</dl>
          <div class="card mt-3" style="background:var(--surface-2);box-shadow:none"><h4 class="mb-2">Parent / guardian</h4><dl class="kv">${kv("Name", s.parentName)}${kv("Mobile", s.parentMobile)}${kv("Email", s.parentEmail)}</dl></div>
          <div class="form-actions mt-3"><button class="btn" data-act="modal-page" data-page="academics">${icon("graduation", 18)} View academic details</button></div></div>
        <div class="modal-page" data-page="academics"><div class="flex items-center gap-2 mb-3"><button class="btn ghost sm" data-act="modal-page" data-page="profile">${icon("arrow-left", 16)} Back</button><h4>Academic history</h4></div>
          <div class="list">${A.each(hist, function (h) {
            var tcl = function (x) { return x === "PASS" ? "solid-good" : x === "FAIL" ? "solid-bad" : "solid-muted"; };
            return html`<div class="item" style="border-left:4px solid var(--primary);display:block"><b>${h.g.title}</b> <span class="muted small">(${h.g.divisionName})</span>
              <div class="grid cols-2 mt-2 small"><div class="chip">UT-1: <b>${h.r.ut1 === null ? "N/A" : h.r.ut1}</b></div><div class="chip">UT-2: <b>${h.r.ut2 === null ? "N/A" : h.r.ut2}</b></div></div>
              <div class="flex justify-between mt-2 small bold"><span>T1 + T2 = ${h.r.combined}</span><span class="badge ${tcl(h.r.cstatus)}">${h.r.cstatus}</span></div>
              <div class="flex justify-between mt-1 small bold"><span>Final = ${h.r.fin === null ? "N/A" : h.r.fin} / ${h.g.finalMax}</span><span class="badge ${tcl(h.r.fstatus)}">${h.r.fstatus}</span></div></div>`;
          }, html`<p class="muted">No grade sheets recorded for this student yet.</p>`)}</div></div>`, "wide tone-" + tone);
      setTimeout(function () { var r = document.getElementById("ring"); if (r) r.style.strokeDashoffset = String(471 - (471 * st.pct) / 100); }, 60);
    });
  };
  A.acts["modal-page"] = function (el) {
    var n = el.getAttribute("data-page");
    document.querySelectorAll("#modal-host .modal-page").forEach(function (p) { p.classList.toggle("active", p.getAttribute("data-page") === n); });
  };

  // ------------------------------------------------------------------ gradebook
  A.route("teacher/gradebook", "teacher", function () {
    var divs = A.q.divs(), items = A.store.gradeItems.slice().sort(function (a, b) { return (b.created || 0) - (a.created || 0); });
    return html`${U.head("Gradebook", "Create a grade sheet per subject and division, then enter marks.")}
      <div class="card mb-3"><h3 class="mb-2">Create grade sheet</h3><form data-form="createGrade" class="form-grid" style="grid-template-columns:repeat(3,minmax(0,1fr))">
        <div class="field"><label>Subject name</label><input class="input" name="title" placeholder="e.g. MATHS" required></div>
        <div class="field"><label>Division</label><select class="input" name="divisionId" required><option value="">Select division</option>${divs.map(function (d) { return html`<option value="${d.id}">${d.name} — ${d.subject}</option>`; })}</select></div>
        <div class="field"><label>Final exam max marks</label><input class="input" type="number" min="1" name="finalMax" required></div>
        <div class="hint-box" style="grid-column:1/-1">${icon("info", 18)}<div>UT-1 and UT-2 are fixed at 30 marks each. Combined pass mark is 18 (30% of 60); the final exam is open only to students who pass it, and its pass mark is 30% of the maximum.</div></div>
        <div class="form-actions" style="grid-column:1/-1"><button class="btn" type="submit">${icon("plus", 18)} Create subject grade sheet</button></div></form></div>
      <h3 class="mb-2">Marks entry sheets</h3><div class="list">${A.each(items, function (i) {
        return html`<a class="picker-btn" href="${A.link("teacher/gradebook/" + i.id)}"><div><div class="bold">${i.title} <span class="muted">(${i.divisionName})</span></div><div class="muted small">UT max 30 each · Final max ${i.finalMax}</div></div>${icon("chevron-right", 20)}</a>`;
      }, U.empty("award", "No subject grade sheets yet. Create one above."))}</div>`;
  });
  A.forms.createGrade = function (f, fd) {
    return A.svc.createGradeItem({ title: fd.get("title"), divisionId: fd.get("divisionId"), finalMax: fd.get("finalMax") }).then(function (id) { A.toast("Subject grade sheet created!"); A.go("teacher/gradebook/" + id); });
  };
  A.route("teacher/gradebook/:id", "teacher", function (ctx) {
    var g = A.q.item(ctx.params.id), d = g && A.q.div(g.divisionId);
    if (!g || !d) return html`${U.head("Grade sheet not found", "")}<a class="btn ghost" href="${A.link("teacher/gradebook")}">Back to list</a>`;
    return html`<a class="btn ghost sm mb-3" href="${A.link("teacher/gradebook")}">${icon("arrow-left", 16)} Back to list</a>
      ${U.head(html`Marks entry: ${g.title} <span class="muted" style="font-weight:500">(${g.divisionName})</span>`, "UT-1 / UT-2 out of 30 · Final out of " + g.finalMax + " · final pass mark " + (Math.round(g.finalMax * 3) / 10),
        html`<div class="flex gap-2 wrap"><button class="btn ghost sm" data-act="grade-csv" data-id="${g.id}">${icon("download", 15)} Download CSV</button><button class="btn danger sm" data-act="del-grade" data-id="${g.id}">${icon("trash", 15)} Delete sheet</button></div>`)}
      <div class="table-wrap"><table class="tbl" id="marks-table" data-fmax="${g.finalMax}"><thead><tr><th>Roll</th><th>Name</th><th>PRN</th><th class="c">UT-1 (30)</th><th class="c">UT-2 (30)</th><th class="c">T1+T2 (60)</th><th class="c">Result</th><th class="c">Final (${g.finalMax})</th><th class="c">Final result</th></tr></thead><tbody>
        ${A.each(roster(d), function (r) {
          var s = A.q.stu(r.uid), v = A.grade(A.q.mark(g.id, r.uid), g.finalMax), cc = v.cstatus === "PASS" ? "pass" : v.cstatus === "FAIL" ? "fail" : "", fc = v.fstatus === "PASS" ? "pass" : v.fstatus === "FAIL" ? "fail" : "";
          return html`<tr data-uid="${r.uid}"><td class="bold">${r.roll}</td><td>${s.name}</td><td><button type="button" class="link-btn" data-act="student-modal" data-uid="${r.uid}">${s.prn || "—"}</button></td>
            <td class="c"><input class="input mark-input" type="number" min="0" max="30" data-f="ut1" value="${v.ut1 === null ? "" : v.ut1}"></td>
            <td class="c"><input class="input mark-input" type="number" min="0" max="30" data-f="ut2" value="${v.ut2 === null ? "" : v.ut2}"></td>
            <td class="c bold" data-out="combined">${v.combined}</td><td class="pass-cell ${cc}" data-out="cstatus">${v.cstatus}</td>
            <td class="c"><input class="input mark-input" type="number" min="0" max="${g.finalMax}" data-f="final" value="${v.fin === null ? "" : v.fin}" ${v.canFinal ? "" : html`disabled placeholder="${v.entered ? "Locked" : "UT first"}"`}></td>
            <td class="pass-cell ${fc}" data-out="fstatus">${v.fstatus}</td></tr>`;
        }, html`<tr><td colspan="9" class="center muted" style="padding:30px">No students in this division yet.</td></tr>`)}</tbody></table></div>
      <div class="form-actions mt-3"><button class="btn success" data-act="save-marks" data-id="${g.id}">${icon("check", 18)} Save all marks</button></div>`;
  });
  function paint(cell, text, cls) { cell.textContent = text; cell.className = "pass-cell " + (cls || ""); }
  function recalc(row, fmax) {
    function num(el) { return el.value.trim() === "" ? null : parseInt(el.value, 10); }
    var u1 = row.querySelector('[data-f="ut1"]'), u2 = row.querySelector('[data-f="ut2"]'), fin = row.querySelector('[data-f="final"]');
    var a = num(u1), b = num(u2), entered = a !== null || b !== null, sum = (a || 0) + (b || 0), ok = entered && sum >= 18;
    row.querySelector('[data-out="combined"]').textContent = sum;
    paint(row.querySelector('[data-out="cstatus"]'), !entered ? "PENDING" : sum >= 18 ? "PASS" : "FAIL", !entered ? "" : sum >= 18 ? "pass" : "fail");
    var fc = row.querySelector('[data-out="fstatus"]');
    if (!ok) { fin.disabled = true; fin.value = ""; fin.placeholder = entered ? "Locked" : "UT first"; paint(fc, entered ? "N/A" : "PENDING", ""); }
    else { fin.disabled = false; fin.placeholder = "Marks"; var f = num(fin); if (f === null) paint(fc, "PENDING", ""); else { var p = f >= fmax * 0.3; paint(fc, p ? "PASS" : "FAIL", p ? "pass" : "fail"); } }
  }
  document.addEventListener("input", function (e) {
    var i = e.target; if (!i.classList || !i.classList.contains("mark-input")) return;
    if (i.value !== "") { if (+i.value > +i.max) i.value = i.max; if (+i.value < 0) i.value = 0; }
    var t = document.getElementById("marks-table"); recalc(i.closest("tr"), +t.getAttribute("data-fmax"));
  });
  A.acts["save-marks"] = function (el) {
    var entries = {};
    document.querySelectorAll("#marks-table tbody tr[data-uid]").forEach(function (tr) {
      entries[tr.getAttribute("data-uid")] = { ut1: tr.querySelector('[data-f="ut1"]').value, ut2: tr.querySelector('[data-f="ut2"]').value, final: tr.querySelector('[data-f="final"]').value };
    });
    return A.svc.saveMarks(el.getAttribute("data-id"), entries).then(function () { A.toast("Marks saved."); A.refresh(); });
  };
  A.acts["del-grade"] = function (el) {
    var g = A.q.item(el.getAttribute("data-id"));
    return A.confirm("Delete grade sheet", "Permanently delete the grade sheet for " + g.title + " in " + g.divisionName + "? This cannot be undone.", "Delete").then(function (ok) {
      if (ok) return A.svc.deleteGradeItem(g.id).then(function () { A.toast("Grade sheet deleted."); A.go("teacher/gradebook"); });
    });
  };
  A.acts["grade-csv"] = function (el) {
    var g = A.q.item(el.getAttribute("data-id")), d = A.q.div(g.divisionId), out = [["Roll", "Name", "PRN", "UT-1", "UT-2", "Combined", "Combined result", "Final exam", "Final result"]];
    roster(d).forEach(function (r) {
      var s = A.q.stu(r.uid), v = A.grade(A.q.mark(g.id, r.uid), g.finalMax);
      out.push([r.roll, s.name, s.prn, v.ut1 === null ? "" : v.ut1, v.ut2 === null ? "" : v.ut2, v.combined, v.cstatus, v.fin === null ? "" : v.fin, v.fstatus]);
    });
    A.download("grades_" + A.slug(g.title) + "_" + A.slug(g.divisionName) + ".csv", A.csv(out));
  };

  // ------------------------------------------------------------------ timetable manager
  A.route("teacher/schedule", "teacher", function () {
    return html`${U.head("Weekly timetable manager", "Pick a division to view or edit its timetable.")}
      <div class="list">${A.each(A.q.divs(), function (d) {
        return A.q.timetable(d.id) ? html`<a class="picker-btn" href="${A.link("teacher/schedule/" + d.id)}"><div><div class="bold">Division: ${d.name}</div><div class="muted small">${d.subject} · <span class="text-good">Timetable ready</span></div></div>${icon("chevron-right", 20)}</a>`
          : html`<button class="picker-btn" data-act="make-tt" data-id="${d.id}"><div><div class="bold">Division: ${d.name}</div><div class="muted small">${d.subject} · <span class="text-warn">Click to create timetable structure</span></div></div>${icon("plus", 20)}</button>`;
      }, U.empty("clock", "No divisions found. Create one in the Attendance section first."))}</div>`;
  });
  A.acts["make-tt"] = function (el) { var id = el.getAttribute("data-id"); return A.svc.createTimetable(id).then(function () { A.toast("Timetable structure created."); A.go("teacher/schedule/" + id); }); };
  A.ttEditing = false;
  function enterEdit() {
    A.ttEditing = true; document.body.classList.add("tt-editing");
    document.querySelectorAll(".tt-input").forEach(function (i) { i.disabled = false; });
    var s = document.getElementById("save-tt"); if (s) s.disabled = false;
    var t = document.getElementById("row-tools"); if (t) t.style.display = "flex";
    var b = document.getElementById("edit-toggle"); if (b) b.querySelector("span").textContent = "Disable edit";
  }
  function leaveEdit() { A.ttEditing = false; document.body.classList.remove("tt-editing"); }
  window.addEventListener("hashchange", leaveEdit);
  function cellsFromDom(tt) {
    var cells = {}, valid = {}; tt.slots.forEach(function (s) { valid[s.id] = 1; });
    document.querySelectorAll(".tt-input").forEach(function (i) { var v = i.value.trim(); if (v && valid[i.getAttribute("data-key").split("_")[0]]) cells[i.getAttribute("data-key")] = v.slice(0, 120); });
    return cells;
  }
  A.route("teacher/schedule/:id", "teacher", function (ctx) {
    var d = A.q.div(ctx.params.id), tt = d && A.q.timetable(d.id);
    if (!d || !tt) return html`${U.head("Timetable", "")}${U.empty("clock", "No timetable yet for this division.")}<p class="mt-3"><a class="btn ghost" href="${A.link("teacher/schedule")}">Back</a></p>`;
    if (A.ttEditing) A.post = enterEdit;
    return html`<a class="btn ghost sm mb-3" href="${A.link("teacher/schedule")}">${icon("arrow-left", 16)} Back</a>
      ${U.head("Timetable for " + d.name, d.subject + " · " + d.faculty + " · " + d.program + " · " + d.sem + " · " + d.year,
        html`<div class="flex gap-2"><button class="btn warn" id="edit-toggle" data-act="tt-edit">${icon("edit", 16)} <span>Edit subjects</span></button><button class="btn danger" data-act="tt-del" data-id="${d.id}">${icon("trash", 16)} Delete</button></div>`)}
      ${A.ttTable(tt, true)}
      <div class="flex justify-between wrap gap-2 mt-3"><div class="flex gap-2 wrap" id="row-tools" style="display:none"><button class="btn ghost" data-act="slot-add" data-kind="lecture">${icon("plus", 16)} Add lecture row</button><button class="btn ghost" data-act="slot-add" data-kind="break">${icon("coffee", 16)} Add break row</button></div>
        <button class="btn success" id="save-tt" data-act="tt-save" data-id="${d.id}" disabled>${icon("check", 18)} Save timetable</button></div>`;
  });
  A.acts["tt-edit"] = function () { if (A.ttEditing) { leaveEdit(); A.dirty = false; A.render(true); } else { enterEdit(); A.toast("Editing enabled — remember to save.", "info"); } };
  function curTT() { return A.q.timetable(location.hash.split("?")[0].split("/").pop()); }
  A.acts["tt-save"] = function (el) {
    var tt = curTT();
    return A.svc.saveTimetable(tt.id, tt.slots, cellsFromDom(tt)).then(function () { leaveEdit(); A.toast("Timetable saved!"); A.refresh(); });
  };
  A.acts["tt-del"] = function (el) {
    var d = A.q.div(el.getAttribute("data-id"));
    return A.confirm("Delete timetable", "Delete the whole timetable for " + d.name + "?", "Delete").then(function (ok) {
      if (ok) return A.svc.deleteTimetable(d.id).then(function () { leaveEdit(); A.toast("Timetable deleted successfully!"); A.go("teacher/schedule"); });
    });
  };
  function slotModal(kind, slot) {
    var isBreak = kind === "break";
    A.openModal(html`<div class="modal-head"><h3>${slot ? (isBreak ? "Edit break time" : "Edit lecture time") : isBreak ? "Add break row" : "Add lecture row"}</h3><button class="icon-btn" data-act="close-modal" aria-label="Close">${icon("x", 18)}</button></div>
      <form data-form="slot" class="grid" style="gap:14px"><input type="hidden" name="id" value="${slot ? slot.id : ""}"><input type="hidden" name="kind" value="${kind}">
        ${isBreak ? html`<div class="field"><label>Break name</label><input class="input" name="name" placeholder="LUNCH BREAK" value="${slot ? slot.name : ""}" required></div>` : ""}
        <div class="form-grid"><div class="field"><label>Start time</label><input class="input" type="time" name="start" value="${slot ? slot.start : ""}" required></div><div class="field"><label>End time</label><input class="input" type="time" name="end" value="${slot ? slot.end : ""}" required></div></div>
        <div class="form-actions"><button class="btn ghost" type="button" data-act="close-modal">Cancel</button><button class="btn" type="submit">Save</button></div></form>`, "small");
  }
  A.acts["slot-add"] = function (el) { slotModal(el.getAttribute("data-kind"), null); };
  A.acts["slot-edit"] = function (el) {
    var s = curTT().slots.filter(function (x) { return x.id === el.getAttribute("data-id"); })[0];
    slotModal(s.isBreak ? "break" : "lecture", s);
  };
  A.acts["slot-del"] = function (el) {
    var tt = curTT(), id = el.getAttribute("data-id"), cells = cellsFromDom(tt);
    return A.confirm("Delete row", "Delete this time slot row? This cannot be undone.", "Delete").then(function (ok) {
      if (!ok) return;
      return A.svc.saveTimetable(tt.id, tt.slots.filter(function (s) { return s.id !== id; }), cells, "Deleted a row from " + tt.divisionName).then(function () { A.toast("Row deleted successfully."); A.refresh(); });
    });
  };
  A.forms.slot = function (f, fd) {
    var tt = curTT(), start = fd.get("start"), end = fd.get("end"), isBreak = fd.get("kind") === "break", id = fd.get("id");
    if (end <= start) throw new Error("End time must be after start time.");
    var slots = tt.slots.map(function (s) { return Object.assign({}, s); });
    if (id) slots.forEach(function (s) { if (s.id === id) { s.start = start; s.end = end; if (s.isBreak) s.name = (fd.get("name") || "").trim(); } });
    else slots.push({ id: "s" + A.newId(), start: start, end: end, isBreak: isBreak, name: isBreak ? (fd.get("name") || "").trim() : "" });
    return A.svc.saveTimetable(tt.id, slots, cellsFromDom(tt), (id ? "Edited" : "Added") + " a time slot in " + tt.divisionName).then(function () {
      A.closeModal(); A.toast(id ? "Time slot updated." : "New slot added."); A.refresh();
    });
  };

  // ------------------------------------------------------------------ comm hub
  A.route("teacher/comm", "teacher", function (ctx) {
    var tab = ["announcements", "assignments", "directmessage", "inbox", "history"].indexOf(ctx.q.tab) > -1 ? ctx.q.tab : "announcements", divs = A.q.divs();
    var inbox = A.store.msgIn.slice().sort(function (a, b) { return b.created - a.created; }), unread = inbox.filter(function (m) { return !m.read; });
    var scope = html`<option value="ALL">All divisions</option>${divs.map(function (d) { return html`<option value="${d.id}">${d.name} — ${d.subject}</option>`; })}`, body;
    if (tab === "announcements") body = html`<div class="card" style="max-width:720px"><h3 class="mb-2">Create new announcement</h3><form data-form="postAnn" class="grid" style="gap:14px">
      <div class="field"><label>Title</label><input class="input" name="title" required></div><div class="field"><label>Message</label><textarea class="input" name="body" rows="4" required></textarea></div>
      <div class="field"><label>Send to</label><select class="input" name="scope">${scope}</select></div><div class="form-actions"><button class="btn" type="submit">${icon("megaphone", 16)} Post announcement</button></div></form></div>`;
    else if (tab === "assignments") body = html`<div class="card" style="max-width:720px"><h3 class="mb-2">Create new assignment</h3><form data-form="postAsg" class="grid" style="gap:14px">
      <div class="field"><label>Assignment title</label><input class="input" name="title" required></div><div class="field"><label>Description / instructions</label><textarea class="input" name="description" rows="4" required></textarea></div>
      <div class="form-grid" style="grid-template-columns:repeat(3,minmax(0,1fr))"><div class="field"><label>Due date</label><input class="input" type="date" name="dueDate" required></div><div class="field"><label>Max marks</label><input class="input" type="number" min="1" name="maxMarks" required></div>
        <div class="field"><label>Send to</label><select class="input" name="scope">${scope}</select></div></div><div class="form-actions"><button class="btn purple" type="submit">${icon("clipboard", 16)} Create assignment</button></div></form></div>`;
    else if (tab === "directmessage") body = html`<div class="card" style="max-width:720px"><h3 class="mb-2">Send direct message to a student</h3><form data-form="teacherDm" class="grid" style="gap:14px">
      <div class="field"><label>Student PRN</label><input class="input" name="prn" required></div><div class="field"><label>Message</label><textarea class="input" name="message" rows="4" placeholder="Your private message…" required></textarea></div>
      <div class="form-actions"><button class="btn warn" type="submit">${icon("send", 16)} Send message</button></div></form></div>`;
    else if (tab === "inbox") {
      body = html`<div class="list">${A.each(inbox, function (m) {
        return html`<div class="item ${m.read ? "" : "unseen"}"><div class="ico-box orange">${icon("mail", 20)}</div><div class="grow"><div class="flex justify-between gap-2 wrap"><h4>From ${m.fromName}</h4><span class="muted small">${A.tsLong(m.created)}</span></div>
          <p class="body pre-wrap">${m.body}</p>${m.read ? "" : html`<span class="badge info mt-1">NEW</span>`}</div></div>`;
      }, U.empty("inbox", "No messages from students yet."))}</div>`;
      if (unread.length) { var ids = unread.map(function (m) { return m.id; }); A.post = function () { A.svc.markRead(ids); }; }
    } else {
      var hist = A.q.posts().map(function (p) { return { type: p.type === "assignment" ? "Assignment" : "Announcement", title: p.title, target: p.scopeName, ts: p.created, ic: p.type === "assignment" ? "clipboard" : "megaphone", tone: p.type === "assignment" ? "purple" : "blue", id: p.id, kind: p.type }; })
        .concat(A.store.msgOut.map(function (m) { return { type: "Direct Message", title: "Message to " + m.toName, target: m.toName, body: m.body, ts: m.created, ic: "send", tone: "orange" }; })).sort(function (a, b) { return b.ts - a.ts; }).slice(0, 100);
      body = html`<div class="list">${A.each(hist, function (h) {
        return html`<div class="item"><div class="ico-box ${h.tone}">${icon(h.ic, 20)}</div><div class="grow"><h4>${h.title}</h4><div class="meta">${h.type} · Target: ${h.target} · ${A.tsLong(h.ts)}</div>${h.body ? html`<p class="body pre-wrap">${h.body.length > 200 ? h.body.slice(0, 200) + "…" : h.body}</p>` : ""}</div>
          ${h.kind ? html`<button class="btn ghost sm" title="Delete" data-act="del-post" data-id="${h.id}" data-kind="${h.kind}">${icon("trash", 14)}</button>` : ""}</div>`;
      }, U.empty("clock", "No communications recorded yet."))}</div>`;
    }
    return html`${U.head("Communication hub", "Reach your students with announcements, assignments and private messages.")}
      ${U.tabs("teacher/comm", [{ key: "announcements", label: "Announcements", icon: "megaphone" }, { key: "assignments", label: "Assignments", icon: "clipboard" }, { key: "directmessage", label: "Direct message", icon: "send" },
        { key: "inbox", label: "Inbox", icon: "inbox", badge: tab === "inbox" ? 0 : unread.length }, { key: "history", label: "History", icon: "clock" }], tab)}${body}`;
  });
  A.forms.postAnn = function (f, fd) { return A.svc.postAnnouncement({ title: fd.get("title"), body: fd.get("body"), scope: fd.get("scope") }).then(function () { f.reset(); A.toast("Announcement posted!"); }); };
  A.forms.postAsg = function (f, fd) {
    return A.svc.postAssignment({ title: fd.get("title"), description: fd.get("description"), dueDate: fd.get("dueDate"), maxMarks: fd.get("maxMarks"), scope: fd.get("scope") }).then(function () { f.reset(); A.toast("Assignment created!"); });
  };
  A.forms.teacherDm = function (f, fd) { return A.svc.messageByPrn(fd.get("prn"), fd.get("message")).then(function (name) { f.reset(); A.toast("Direct message sent to " + name + "!"); }); };
  A.acts["del-post"] = function (el) {
    var kind = el.getAttribute("data-kind");
    return A.confirm("Delete " + kind, "Delete this " + kind + "? Students will no longer see it.", "Delete").then(function (ok) {
      if (ok) return A.svc.deletePost(el.getAttribute("data-id")).then(function () { A.toast(kind.charAt(0).toUpperCase() + kind.slice(1) + " deleted."); });
    });
  };

  // ------------------------------------------------------------------ comparison & export
  A.route("teacher/comparison", "teacher", function () {
    var chart = A.q.divs().map(function (d) { var s = divStats(d); return { label: d.name, sub: d.subject, pct: s.pct, detail: d.roster.length + " students" }; });
    return html`${U.head("Division Comparison", "Overall attendance percentage of each of your divisions.")}${U.bars(chart)}`;
  });
  A.route("teacher/export", "teacher", function (ctx) {
    var divs = A.q.divs(), d = ctx.q.div ? A.q.div(ctx.q.div) : null, pages = [];
    if (d) {
      var dates = allDates(d), rs = roster(d), size = 15;
      var chunks = []; for (var i = 0; i < dates.length; i += size) chunks.push(dates.slice(i, i + size)); if (!chunks.length) chunks.push([]);
      pages = chunks.map(function (c, idx) { return { index: idx + 1, dates: c, last: idx === chunks.length - 1 }; });
      var rowsFor = function (c) { return rs.map(function (r) { var rec = A.q.records(d.id, r.uid), s = A.q.stu(r.uid); return { roll: r.roll, name: s.name, prn: s.prn, cells: c.map(function (x) { return rec[x] === true ? "P" : rec[x] === false ? "A" : "-"; }), pct: A.q.attStats(r.uid, [d.id]).pct }; }); };
      pages.forEach(function (p) { p.rows = rowsFor(p.dates); });
    }
    return html`<style media="print">@page { size: A4 landscape; margin: 8mm; }</style>
      <div class="page-head no-print"><div><h2>Export detailed reports</h2><p>A full grid of students, daily attendance and overall percentage for a division.</p></div></div>
      <div class="card mb-3 no-print"><div class="flex gap-2 wrap items-center"><select class="input" style="max-width:360px" data-change="export-div" data-nodirty><option value="">Select a division to export</option>${divs.map(function (x) { return html`<option value="${x.id}" ${d && d.id === x.id ? "selected" : ""}>${x.name} — ${x.subject}</option>`; })}</select>
        ${d ? html`<button class="btn warn" data-act="print">${icon("printer", 17)} Export as PDF</button><button class="btn ghost" data-act="att-csv" data-id="${d.id}">${icon("download", 16)} Download CSV</button>` : ""}</div>
        <p class="muted small mt-2">In the print dialog choose <b>Save as PDF</b>. Pages are landscape with up to 15 dates each.</p></div>
      ${d ? html`<div class="report">${pages.map(function (p) {
        return html`<div class="page-block"><div class="report-center"><h2>Attendance report</h2><div style="font-weight:700;color:#374151;margin-top:6px">${d.name} — page ${p.index} of ${pages.length}</div></div>
          <table class="meta-table" style="margin-bottom:14px;border-top:1px solid #e5e7eb;border-bottom:1px solid #e5e7eb"><tr><td><b>FACULTY</b></td><td>: ${d.faculty}</td><td><b>SUBJECT</b></td><td>: ${d.subject}</td></tr>
            <tr><td><b>PROGRAM</b></td><td>: ${d.program}</td><td><b>DIVISION</b></td><td>: ${d.name}</td></tr><tr><td><b>SCHOOL</b></td><td>: ${d.school}</td><td><b>TEACHER</b></td><td>: ${P().name}</td></tr>
            <tr><td><b>YEAR</b></td><td>: ${d.year} · ${d.sem}</td><td></td><td></td></tr></table>
          <table><thead><tr><th style="width:5%">Roll</th><th>Name</th><th>PRN</th>${p.dates.map(function (x) { return html`<th class="D" style="color:#111">${A.dmy(x)}</th>`; })}${p.last ? html`<th>%</th>` : ""}</tr></thead>
          <tbody>${A.each(p.rows, function (r) { return html`<tr><td><b>${r.roll}</b></td><td>${r.name}</td><td>${r.prn}</td>${r.cells.map(function (c) { return html`<td class="${c === "P" ? "P" : c === "A" ? "A" : "D"}">${c}</td>`; })}${p.last ? html`<td style="text-align:center;font-weight:700;background:#f9fafb">${r.pct}%</td>` : ""}</tr>`; }, html`<tr><td colspan="4" class="D">No students in this division.</td></tr>`)}</tbody></table></div>`;
      })}</div>` : ""}`;
  });
  A.acts["export-div"] = function (el) { A.go("teacher/export" + (el.value ? "?div=" + el.value : "")); };

  // ------------------------------------------------------------------ profile
  A.route("teacher/profile", "teacher", function () {
    var p = P();
    return html`${U.head("Manage profile", "Students see your name when you post or message them.")}
      <div class="card" style="max-width:820px"><div class="grid profile-grid" style="grid-template-columns:220px 1fr;gap:28px"><div>${U.picCard(p)}</div>
        <form data-form="teacherProfile" class="form-grid"><div class="field span-2"><label>Name</label><input class="input" name="name" value="${p.name}" required></div>
          <div class="field"><label>Mobile number</label><input class="input" name="mobile" value="${p.mobile || ""}"></div><div class="field"><label>Account e-mail</label><input class="input" value="${A.S.user.email}" disabled></div>
          <div class="field span-2"><label>Username</label><input class="input" value="${p.username}" disabled></div><div class="form-actions span-2"><button class="btn success" type="submit">Save changes</button></div></form></div></div>`;
  });
  A.forms.teacherProfile = function (f, fd) { return A.svc.saveProfile({ name: fd.get("name").trim(), mobile: fd.get("mobile").trim() }).then(function () { A.toast("Profile saved."); }); };
})();
