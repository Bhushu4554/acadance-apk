/* Login, sign-up (student / teacher), forgot password. */
(function () {
  "use strict";
  var A = window.A, html = A.html, icon = A.icon;

  var CRIT = html`<div class="crit-grid"><div class="crit" data-crit="length">8+ characters</div><div class="crit" data-crit="case">Upper &amp; lowercase</div><div class="crit" data-crit="number">At least one number</div><div class="crit" data-crit="special">A special character</div></div>
    <div class="strength"><div></div></div><div class="strength-text"></div>`;
  function passField(name, ph, auto) {
    return html`<div class="input-icon has-toggle">${icon("lock", 18)}<input class="input" type="password" name="${name}" placeholder="${ph}" required autocomplete="${auto}">
      <button type="button" class="toggle-pass" data-act="toggle-pass" aria-label="Show password">${icon("eye", 18)}</button></div>`;
  }
  var CAPTCHA = html`<div class="label">Slide the key to the lock to verify</div>
    <div class="captcha" data-captcha><input type="hidden" name="captcha_ok" value="0"><div class="hint">Slide to verify →</div>
      <div class="key">${icon("key", 22)}</div><div class="lock">${icon("lock", 22)}</div><div class="done">${icon("shield-check", 24)} Verified</div></div>`;

  A.renderAuth = function () {
    var banner = A.cloudFailed ? html`<div class="hint-box bad mb-2">${icon("alert", 18)}<div class="grow"><b>Cloud unavailable.</b> Check your connection. Your account has not been switched to demo data.<button class="link-btn small" data-act="reload-cloud" style="display:block;margin-top:5px">Try again</button></div></div>`
      : !A.cloud ? html`<div class="hint-box warn mb-2">${icon("info", 18)}<div><b>Device-only demo.</b> Data stays on this phone. A Firebase configuration is required for live sharing.</div></div>` : "";
    var demoBox = !A.cloud && !A.cloudWanted ? html`<div class="demo-box"><button class="btn ghost sm" type="button" data-act="seed">Load sample data</button>
      <div class="mt-1">Creates teacher <b>teacher</b> / <b>Teacher@123</b> and students <b>aarav</b>, <b>diya</b>, <b>sana</b>… / <b>Student@123</b>.</div></div>` : "";
    var page = html`
    <canvas id="bg-canvas"></canvas>
    <div class="auth-shell">
      <section class="auth-art">
        <div class="panel" id="panel-login"><div class="brandline"><img src="img/logo.png" alt=""><span>Acadance</span></div>
          <h1>One place for every class, mark and message.</h1>
          <p class="lead">A secure academic portal for students and teachers - always in sync across all devices.</p>
          <div class="feature-list">
            <div class="f"><div class="fi">${icon("calendar", 19)}</div><div><b>Smart attendance</b><span>Daily sheets, 75% tracking and instant alerts.</span></div></div>
            <div class="f"><div class="fi">${icon("award", 19)}</div><div><b>Gradebook</b><span>Unit tests and finals with automatic pass rules.</span></div></div>
            <div class="f"><div class="fi">${icon("message", 19)}</div><div><b>Communication hub</b><span>Announcements, assignments and direct messages.</span></div></div></div></div>
        <div class="panel" id="panel-choice"><div class="art-ico">${icon("users", 42)}</div><h2>Create your account</h2><p class="lead">Join Acadance as a student or as a teacher in under a minute.</p></div>
        <div class="panel" id="panel-student"><div class="art-ico">${icon("graduation", 42)}</div><h2>Student registration</h2><p class="lead">Track your attendance, grades, timetable and announcements in one place.</p></div>
        <div class="panel" id="panel-teacher"><div class="art-ico">${icon("user-plus", 42)}</div><h2>Teacher registration</h2><p class="lead">Manage divisions, take attendance, grade students and keep everyone informed.</p></div>
        <div class="panel" id="panel-forgot"><div class="art-ico">${icon("key", 42)}</div><h2>Forgot your password?</h2><p class="lead">We will e-mail you a link to choose a new one.</p></div>
      </section>
      <section class="auth-form-side"><div class="auth-card">
        <div class="mobile-brand"><img src="img/logo.png" alt=""><span>Acadance</span></div>
        ${banner}
        <div class="auth-view" id="view-login"><h2>Welcome back</h2><p class="lead">Please enter your details to continue.</p>
          <form class="auth-form" data-form="login">
            <div class="input-icon">${icon("user", 18)}<input class="input" name="username" placeholder="Username or PRN" required autocomplete="username" autocapitalize="none"></div>
            ${passField("password", "Password", "current-password")}
            <button class="btn block" type="submit">Login</button></form>
          <p class="auth-switch"><a href="#" data-goto="forgot">Forgot password?</a></p>
          <p class="auth-switch" style="margin-top:6px">Don't have an account? <a href="#" data-goto="choice"><b>Sign Up</b></a></p>${demoBox}</div>
        <div class="auth-view" id="view-choice"><h2>Join the portal</h2><p class="lead">Please select your role to create an account.</p>
          <div class="auth-form"><button class="btn success block" type="button" data-goto="student">${icon("graduation", 18)} Sign up as Student</button>
            <button class="btn purple block" type="button" data-goto="teacher">${icon("user-plus", 18)} Sign up as Teacher</button></div>
          <p class="auth-switch"><a href="#" data-goto="login">Back to login</a></p></div>
        <div class="auth-view" id="view-student"><h2>Student registration</h2><p class="lead">Fill in the details to create your account.</p>
          <form class="auth-form" data-form="signupStudent">
            <div class="input-icon">${icon("user", 18)}<input class="input" name="username" placeholder="Choose a username" required autocomplete="username" autocapitalize="none"></div>
            <div class="input-icon">${icon("phone", 18)}<input class="input" type="tel" name="mobile" placeholder="Mobile number" required></div>
            <div class="input-icon">${icon("mail", 18)}<input class="input" type="email" name="email" placeholder="E-mail (optional, lets you reset your password)" autocomplete="email"></div>
            <div data-pw-block>${passField("password", "Create password", "new-password")}${CRIT}</div>${CAPTCHA}
            <button class="btn success block" type="submit">Create student account</button></form>
          <p class="auth-switch">Already have an account? <a href="#" data-goto="login"><b>Login</b></a></p></div>
        <div class="auth-view" id="view-teacher"><h2>Teacher registration</h2><p class="lead">An Admin Key is required for a teacher account.</p>
          <form class="auth-form" data-form="signupTeacher">
            <div class="input-icon">${icon("user", 18)}<input class="input" name="username" placeholder="Username" required autocomplete="username" autocapitalize="none"></div>
            <div class="input-icon">${icon("mail", 18)}<input class="input" type="email" name="email" placeholder="E-mail (optional, lets you reset your password)" autocomplete="email"></div>
            <div data-pw-block>${passField("password", "Password", "new-password")}${CRIT}</div>
            <div class="input-icon">${icon("key", 18)}<input class="input" type="password" name="adminKey" placeholder="Admin key" required autocomplete="off"></div>${CAPTCHA}
            <button class="btn purple block" type="submit">Create teacher account</button></form>
          <p class="auth-switch">Already have an account? <a href="#" data-goto="login"><b>Login</b></a></p></div>
        <div class="auth-view" id="view-forgot"><h2>Reset password</h2><p class="lead">Enter your username or PRN. If your account has an e-mail, we send a reset link.</p>
          <form class="auth-form" data-form="forgot"><div class="input-icon">${icon("user", 18)}<input class="input" name="username" placeholder="Username or PRN" required autocapitalize="none"></div>
            <button class="btn block" type="submit">Send reset link</button></form>
          <p class="auth-switch"><a href="#" data-goto="login">Back to login</a></p></div>
      </div></section>
    </div>`;
    document.getElementById("app").innerHTML = A.str(page);
    initAuth();
  };

  // ------------------------------------------------------------------ behaviour
  function strongEnough(pw) {
    return pw.replace(/\s/g, "").length >= 8 && /[a-z]/.test(pw) && /[A-Z]/.test(pw) && /\d/.test(pw) && /[^a-zA-Z\d\s]/.test(pw);
  }
  function showView(name) {
    document.querySelectorAll(".auth-view").forEach(function (v) { v.classList.toggle("active", v.id === "view-" + name); });
    document.querySelectorAll(".auth-art .panel").forEach(function (p) { p.classList.toggle("active", p.id === "panel-" + name); });
    document.querySelectorAll("[data-captcha]").forEach(function (c) { if (c._reset) c._reset(); });
  }
  var bgRunning = false;
  function background() {
    var canvas = document.getElementById("bg-canvas");
    if (!canvas || !canvas.getContext) return;
    var ctx = canvas.getContext("2d"), w, h, pts = [];
    var pal = [[16, 185, 129], [5, 150, 105], [52, 211, 153], [20, 184, 166], [132, 204, 22]];
    function size() { w = canvas.width = innerWidth; h = canvas.height = innerHeight; pts = pal.map(function (c) { return { x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - .5) * .6, vy: (Math.random() - .5) * .6, c: c }; }); }
    function frame() {
      if (!document.body.classList.contains("auth-body") || !document.getElementById("bg-canvas")) { bgRunning = false; return; }
      ctx.fillStyle = "#04281e"; ctx.fillRect(0, 0, w, h);
      pts.forEach(function (p) {
        p.x += p.vx; p.y += p.vy; if (p.x < 0 || p.x > w) p.vx *= -1; if (p.y < 0 || p.y > h) p.vy *= -1;
        var r = Math.max(w, h) * .62, g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r);
        g.addColorStop(0, "rgba(" + p.c.join(",") + ",.55)"); g.addColorStop(1, "rgba(" + p.c.join(",") + ",0)");
        ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
      });
      requestAnimationFrame(frame);
    }
    size();
    if (window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches) { ctx.fillStyle = "#064e3b"; ctx.fillRect(0, 0, w, h); return; }
    if (!bgRunning) { bgRunning = true; frame(); }
  }
  function initAuth() {
    background();
    document.querySelectorAll("[data-goto]").forEach(function (el) { el.addEventListener("click", function (e) { e.preventDefault(); showView(el.getAttribute("data-goto")); }); });
    document.querySelectorAll("[data-pw-block]").forEach(function (block) {
      var input = block.querySelector("input"), bar = block.querySelector(".strength > div"), text = block.querySelector(".strength-text");
      var lv = [["0%", "transparent", ""], ["25%", "#ef4444", "Weak"], ["50%", "#f59e0b", "Medium"], ["75%", "#10b981", "Good"], ["100%", "#22c55e", "Strong"]];
      input.addEventListener("input", function () {
        var v = input.value, ck = { length: v.replace(/\s/g, "").length >= 8, case: /[a-z]/.test(v) && /[A-Z]/.test(v), number: /\d/.test(v), special: /[^a-zA-Z\d\s]/.test(v) }, s = 0;
        Object.keys(ck).forEach(function (k) { if (ck[k]) s++; var el = block.querySelector('[data-crit="' + k + '"]'); if (el) el.classList.toggle("ok", ck[k]); });
        var l = lv[v ? s : 0]; bar.style.width = l[0]; bar.style.background = l[1]; text.textContent = l[2];
      });
    });
    document.querySelectorAll("[data-captcha]").forEach(function (box) {
      var key = box.querySelector(".key"), lock = box.querySelector(".lock"), flag = box.querySelector("input[name=captcha_ok]"), drag = false, sx = 0, sl = 4;
      function maxLeft() { return box.clientWidth - key.offsetWidth - 4; }
      box._reset = function () { box.classList.remove("verified"); flag.value = "0"; key.style.left = "4px"; };
      key.addEventListener("pointerdown", function (e) { if (box.classList.contains("verified")) return; drag = true; key.classList.add("dragging"); sx = e.clientX; sl = key.offsetLeft; key.setPointerCapture(e.pointerId); e.preventDefault(); });
      key.addEventListener("pointermove", function (e) { if (drag) key.style.left = Math.min(maxLeft(), Math.max(4, sl + e.clientX - sx)) + "px"; });
      function end() {
        if (!drag) return; drag = false; key.classList.remove("dragging");
        if (key.offsetLeft + key.offsetWidth >= lock.offsetLeft + 6) { box.classList.add("verified"); flag.value = "1"; }
        else { key.style.left = "4px"; A.toast("Slide the key all the way to the lock.", "error"); }
      }
      key.addEventListener("pointerup", end); key.addEventListener("pointercancel", end);
    });
    showView("login");
  }
  A.acts["toggle-pass"] = function (el) {
    var input = el.parentElement.querySelector("input");
    input.type = input.type === "password" ? "text" : "password";
  };

  // ------------------------------------------------------------------ forms
  function requireCloud() {
    if (A.cloudFailed) throw new Error("Cloud services are unavailable. Reconnect and tap Try again; no device-only account was created.");
  }
  A.forms.login = function (f, fd) {
    requireCloud();
    return A.svc.login(fd.get("username"), fd.get("password")).then(function () { A.toast("Login successful!"); });
  };
  A.forms.signupStudent = function (f, fd) {
    requireCloud();
    var pw = fd.get("password");
    if (fd.get("captcha_ok") !== "1") throw new Error("Please complete the security check.");
    if (/\s/.test(fd.get("username"))) throw new Error("Username cannot contain spaces.");
    if (/\s/.test(pw)) throw new Error("Spaces are not allowed in the password.");
    if (!strongEnough(pw)) throw new Error("Please use a strong password that meets all criteria.");
    return A.svc.register("student", { username: fd.get("username"), mobile: fd.get("mobile"), email: fd.get("email"), password: pw })
      .then(function () { A.toast("Student account created! Welcome to Acadance."); });
  };
  A.forms.signupTeacher = function (f, fd) {
    requireCloud();
    var pw = fd.get("password");
    if (fd.get("captcha_ok") !== "1") throw new Error("Please slide the key to verify.");
    if (/\s/.test(fd.get("username"))) throw new Error("Username cannot contain spaces.");
    if (/\s/.test(pw)) throw new Error("Spaces are not allowed in the password.");
    if (!strongEnough(pw)) throw new Error("Please use a strong password that meets all criteria.");
    return A.svc.register("teacher", { username: fd.get("username"), email: fd.get("email"), password: pw, adminKey: fd.get("adminKey") })
      .then(function () { A.toast("Teacher account created! Welcome to Acadance."); });
  };
  A.forms.forgot = function (f, fd) {
    requireCloud();
    return A.svc.forgot(fd.get("username")).then(function (masked) { A.toast("Reset link sent to " + masked + ". Check your inbox."); showView("login"); });
  };
})();
