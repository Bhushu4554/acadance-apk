/* Demo mode only: fills the local database with a small sample school. */
(function () {
  "use strict";
  var A = window.A;
  A.acts.seed = function () {
    var DB = A.DB, AUTH = A.AUTH, dom = A.domain, now = Date.now();
    A.seeding = true;
    function mk(username, name, role, extra) {
      var email = username + "@" + dom;
      return AUTH.signUp(email, role === "teacher" ? "Teacher@123" : "Student@123").then(function (c) {
        var u = Object.assign({ role: role, username: username, name: name, mobile: "", createdAt: now }, extra || {});
        return Promise.all([
          DB.set("users", c.uid, u),
          DB.set("directory", c.uid, { role: role, name: name, username: username, prn: u.prn || "" }),
          DB.set("logins", "u_" + username, { uid: c.uid, email: email, username: username }),
          u.prn ? DB.set("logins", "p_" + u.prn, { uid: c.uid, email: email, username: username }) : null
        ]).then(function () { return c.uid; });
      });
    }
    var people = [["aarav", "Aarav Sharma", "1001"], ["diya", "Diya Patil", "1002"], ["kabir", "Kabir Deshmukh", "1003"],
      ["meera", "Meera Joshi", "1004"], ["rohan", "Rohan Kulkarni", "1005"], ["sana", "Sana Shaikh", "1006"]];
    var tUid, sUids = [];
    return mk("teacher", "Prof. Anita Verma", "teacher", { mobile: "9111111111" }).then(function (id) { tUid = id; })
      .then(function () {
        return people.reduce(function (p, s, i) {
          return p.then(function () {
            return mk(s[0], s[1], "student", { prn: s[2], mobile: "900000000" + (i + 1), division: "SY-A", yearSem: "3rd Year SEM-V",
              programLevel: "UG", program: "B.Tech / Engineering", specialization: "Computer Science & Engineering" }).then(function (id) { sUids.push(id); });
          });
        }, Promise.resolve());
      }).then(function () {
        var divId = DB.newId(), ops = [], rnd = (function (s) { return function () { s = (s * 16807) % 2147483647; return s / 2147483647; }; })(7);
        ops.push({ op: "set", c: "divisions", id: divId, data: { teacherUid: tUid, teacherName: "Prof. Anita Verma", name: "SY-A", subject: "Operating System",
          faculty: "Prof. Anita Verma", program: "Diploma in Computer Science", sem: "SEM-V", year: "2026-27", school: "School of Engineering",
          roster: sUids.map(function (u, i) { return { uid: u, roll: String(i + 1) }; }), studentUids: sUids, created: now } });
        var dates = [], d = new Date();
        while (dates.length < 12) { d.setDate(d.getDate() - 1); if (d.getDay() !== 0) dates.push(d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2)); }
        sUids.forEach(function (u, i) {
          var rec = {}; dates.forEach(function (x) { rec[x] = rnd() < (i === 5 ? 0.35 : 0.85); });
          ops.push({ op: "set", c: "attendance", id: divId + "_" + u, data: { divisionId: divId, studentUid: u, teacherUid: tUid, records: rec } });
        });
        var gid = DB.newId();
        ops.push({ op: "set", c: "gradeItems", id: gid, data: { teacherUid: tUid, divisionId: divId, divisionName: "SY-A", title: "Operating System", finalMax: 70, studentUids: sUids, created: now } });
        sUids.forEach(function (u) {
          var ut1 = 8 + Math.floor(rnd() * 22), ut2 = 8 + Math.floor(rnd() * 22), ok = ut1 + ut2 >= 18;
          ops.push({ op: "set", c: "marks", id: gid + "_" + u, data: { itemId: gid, divisionId: divId, studentUid: u, teacherUid: tUid, ut1: ut1, ut2: ut2, finalExam: ok ? 15 + Math.floor(rnd() * 50) : null } });
        });
        var subs = ["Operating System", "Software Eng.", "Cloud Computing"], slots = [["09:00", "10:00", 0], ["10:00", "11:00", 0], ["11:00", "12:00", 0], ["12:00", "13:00", 1], ["13:00", "14:00", 0], ["14:00", "15:00", 0]].map(function (s, i) {
          return { id: "s" + i, start: s[0], end: s[1], isBreak: !!s[2], name: s[2] ? "LUNCH BREAK" : "" };
        }), cells = {}, n = 0;
        slots.forEach(function (s) { if (!s.isBreak) { for (var k = 0; k < 6; k++) cells[s.id + "_" + k] = subs[(n + k) % 3]; n++; } });
        ops.push({ op: "set", c: "timetables", id: divId, data: { teacherUid: tUid, teacherName: "Prof. Anita Verma", divisionId: divId, divisionName: "SY-A", studentUids: sUids, slots: slots, cells: cells } });
        ops.push({ op: "set", c: "posts", id: DB.newId(), data: { type: "announcement", teacherUid: tUid, teacherName: "Prof. Anita Verma", title: "Welcome to Acadance!", body: "This is a demo announcement. Teachers can post to one division or to everyone.", scope: "ALL", scopeName: "ALL", studentUids: [], created: now } });
        ops.push({ op: "set", c: "posts", id: DB.newId(), data: { type: "announcement", teacherUid: tUid, teacherName: "Prof. Anita Verma", title: "Unit test 2 schedule", body: "Unit test 2 will be held next week. Please bring your ID cards.", scope: divId, scopeName: "SY-A", studentUids: sUids, created: now - 3600000 } });
        var due = new Date(Date.now() + 6 * 86400000), dd = due.getFullYear() + "-" + ("0" + (due.getMonth() + 1)).slice(-2) + "-" + ("0" + due.getDate()).slice(-2);
        ops.push({ op: "set", c: "posts", id: DB.newId(), data: { type: "assignment", teacherUid: tUid, teacherName: "Prof. Anita Verma", title: "Process scheduling worksheet", body: "Solve the FCFS, SJF and Round Robin problems given in class and submit the worksheet.", dueDate: dd, maxMarks: 20, scope: divId, scopeName: "SY-A", studentUids: sUids, created: now - 7200000 } });
        ops.push({ op: "set", c: "messages", id: DB.newId(), data: { fromUid: tUid, toUid: sUids[5], fromName: "Prof. Anita Verma", toName: "Sana Shaikh", body: "Your attendance is low. Please meet me after class.", created: now, read: false } });
        return DB.batch(ops);
      }).then(function () { return AUTH.signOut(); })
      .then(function () { A.seeding = false; A.toast("Sample data loaded. Log in as teacher / Teacher@123 or aarav / Student@123."); A.showAuth(); },
        function (e) { A.seeding = false; A.showAuth(); throw e; });
  };
})();
