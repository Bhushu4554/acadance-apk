/* Local DEMO backend: same interface as the Firebase backend, but data lives in this browser's localStorage.
   Several tabs/windows of the same browser stay in sync (storage events) - handy for trying the app out.
   Used automatically while config.js still contains the PASTE_... placeholders. */
(function () {
  "use strict";
  var A = window.A;

  A.makeLocalBackend = function () {
    var KEY = "acadance-demo-db", AUTHKEY = "acadance-demo-auth", SESSKEY = "acadance-demo-uid";
    var data = load();
    var watchers = [];
    var DELETE = { __delete: true };

    function load() { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } }
    function save() { localStorage.setItem(KEY, JSON.stringify(data)); }
    function clone(x) { return x === undefined ? undefined : JSON.parse(JSON.stringify(x)); }
    function col(c) { return data[c] || (data[c] = {}); }
    function err(code, message) { var e = new Error(message || code); e.code = code; return e; }

    function matches(doc, filters) {
      return (filters || []).every(function (f) {
        var x = f[0] === "__id__" ? doc.id : doc[f[0]];
        if (f[1] === "==") return x === f[2];
        if (f[1] === "array-contains") return Array.isArray(x) && x.indexOf(f[2]) > -1;
        if (f[1] === "in") return f[2].indexOf(x) > -1;
        return false;
      });
    }
    function run(c, filters) {
      var all = col(c);
      return Object.keys(all).map(function (id) { var d = clone(all[id]); d.id = id; return d; })
        .filter(function (d) { return matches(d, filters); });
    }
    function deepMerge(target, patch) {
      Object.keys(patch).forEach(function (k) {
        var v = patch[k];
        if (v === DELETE) { delete target[k]; return; }
        if (v && typeof v === "object" && !Array.isArray(v) && target[k] && typeof target[k] === "object" && !Array.isArray(target[k])) deepMerge(target[k], v);
        else target[k] = clone(v);
      });
    }
    function applyOp(o) {
      var c = col(o.c);
      if (o.op === "delete") { delete c[o.id]; return; }
      if (o.op === "update") {
        if (!c[o.id]) throw err("not-found", "No document to update");
        Object.keys(o.data).forEach(function (k) { if (o.data[k] === DELETE) delete c[o.id][k]; else c[o.id][k] = clone(o.data[k]); });
        return;
      }
      if (o.merge && c[o.id]) deepMerge(c[o.id], o.data);
      else { var d = {}; deepMerge(d, o.data); c[o.id] = d; }
    }
    function notify() { watchers.slice().forEach(function (w) { w.fire(); }); }
    function commit(ops) { ops.forEach(applyOp); save(); setTimeout(notify, 0); return Promise.resolve(); }
    window.addEventListener("storage", function (e) { if (e.key === KEY) { data = load(); notify(); } });

    var DB = {
      DELETE: DELETE,
      newId: function () { return A.newId(); },
      get: function (c, id) { var d = col(c)[id]; if (!d) return Promise.resolve(null); var o = clone(d); o.id = id; return Promise.resolve(o); },
      set: function (c, id, d, opts) { return commit([{ op: "set", c: c, id: id, data: d, merge: !!(opts && opts.merge) }]); },
      create: function (c, id, d) {
        if (col(c)[id]) return Promise.reject(err("permission-denied", "Already exists"));
        return commit([{ op: "set", c: c, id: id, data: d }]);
      },
      update: function (c, id, p) {
        if (!col(c)[id]) return Promise.reject(err("not-found", "No document to update"));
        return commit([{ op: "update", c: c, id: id, data: p }]);
      },
      del: function (c, id) { return commit([{ op: "delete", c: c, id: id }]); },
      query: function (c, f) { return Promise.resolve(run(c, f)); },
      watch: function (c, f, cb) {
        var w = { fire: function () { cb(run(c, f)); } };
        watchers.push(w); setTimeout(w.fire, 0);
        return function () { watchers = watchers.filter(function (x) { return x !== w; }); };
      },
      watchDoc: function (c, id, cb) {
        var w = { fire: function () { var d = col(c)[id]; if (!d) cb(null); else { var o = clone(d); o.id = id; cb(o); } } };
        watchers.push(w); setTimeout(w.fire, 0);
        return function () { watchers = watchers.filter(function (x) { return x !== w; }); };
      },
      batch: function (ops) { return commit(ops); }
    };

    // ---- fake auth (passwords are stored in the clear: this is DEMO mode only)
    function accounts() { try { return JSON.parse(localStorage.getItem(AUTHKEY)) || {}; } catch (e) { return {}; } }
    var listeners = [];
    function current() {
      var uid = sessionStorage.getItem(SESSKEY);
      if (!uid) return null;
      var a = accounts(), mail = Object.keys(a).filter(function (m) { return a[m].uid === uid; })[0];
      return mail ? { uid: uid, email: mail } : null;
    }
    function emit() { var u = current(); listeners.slice().forEach(function (cb) { cb(u); }); }
    var Auth = {
      current: current,
      onChange: function (cb) { listeners.push(cb); setTimeout(function () { cb(current()); }, 0); return function () { listeners = listeners.filter(function (x) { return x !== cb; }); }; },
      signUp: function (email, pw) {
        email = email.toLowerCase();
        if (pw.length < 6) return Promise.reject(err("auth/weak-password"));
        var a = accounts();
        if (a[email]) return Promise.reject(err("auth/email-already-in-use"));
        var uid = A.newId(); a[email] = { uid: uid, password: pw };
        localStorage.setItem(AUTHKEY, JSON.stringify(a));
        sessionStorage.setItem(SESSKEY, uid); emit();
        return Promise.resolve({ uid: uid, email: email });
      },
      signIn: function (email, pw) {
        email = email.toLowerCase();
        var a = accounts()[email];
        if (!a || a.password !== pw) return Promise.reject(err("auth/invalid-credential"));
        sessionStorage.setItem(SESSKEY, a.uid); emit();
        return Promise.resolve({ uid: a.uid, email: email });
      },
      signOut: function () { sessionStorage.removeItem(SESSKEY); emit(); return Promise.resolve(); },
      deleteCurrent: function () {
        var u = current(); if (!u) return Promise.resolve();
        var a = accounts(); delete a[u.email]; localStorage.setItem(AUTHKEY, JSON.stringify(a));
        sessionStorage.removeItem(SESSKEY); emit(); return Promise.resolve();
      },
      changePassword: function (oldPw, newPw) {
        var u = current(), a = accounts();
        if (!u || a[u.email].password !== oldPw) return Promise.reject(err("auth/wrong-password"));
        if (newPw.length < 6) return Promise.reject(err("auth/weak-password"));
        a[u.email].password = newPw; localStorage.setItem(AUTHKEY, JSON.stringify(a));
        return Promise.resolve();
      },
      sendReset: function () { return Promise.resolve(); }
    };
    return { DB: DB, Auth: Auth, cloud: false };
  };
})();
