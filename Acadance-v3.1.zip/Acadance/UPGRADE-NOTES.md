# Acadance 3.1 - bug-fix release

* Sign-up crash fixed: "fullName is not defined" (student and teacher). The name is now saved correctly.
* A failed sign-up no longer leaves a half-made account that blocks your e-mail ("already registered"). Retrying works, and the error message and typed details stay on screen.
* E-mail is validated before the account is created.
* Service worker now loads the newest files first (cache v6), so an updated app/APK never keeps running old code.
* "Turn on notifications" pop-up and other dialogs no longer stay on screen after sign-out.
* Student home empty state no longer shows a literal "<br>".
* Marking messages/posts as read can no longer throw an unhandled error.
* Version 3.1 (versionCode 5) so the new APK installs over the old one.

# Acadance 3.0 - what changed

* New sign-in / sign-up screens (2-step sign-up, full name, PRN, confirm password, live username check, remember me, caps-lock warning, terms, inline errors).
* Responsive layout for phones, foldables, tablets and desktop; bottom-sheet dialogs; safe-area aware; light / dark / system theme with matching status bar.
* Notifications: in-app bell + heads-up banners, Android pop-up notifications (channels, tap opens the right screen), background check about every 15 minutes while the app is closed.
* New Settings page (notifications, appearance, account, about), splash screen, offline bar, double-back-to-exit, new adaptive icon.

## Build
Push the repository to GitHub. `.github/workflows/build-apk.yml` builds a signed APK (Actions > Build Acadance APK > Artifacts).
The folder `Acadance/` must sit at the repository root; if your repository root IS the Acadance folder, change `working-directory: Acadance` to `.`
and the artifact path to `app/build/outputs/apk/release/*.apk`.

The APK is signed with `app/acadance-release.jks`, so every future build installs over the previous one.
The very first time, uninstall the old Acadance APK (it was signed with a different key). Your data is in Firebase, nothing is lost.
