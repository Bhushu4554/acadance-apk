/* Acadance app shell: routing, layout, live re-render, global click / form handling. */
(function () {
  "use strict";
  var A = window.A, html = A.html, icon = A.icon, esc = A.esc;
  A.acts = {};   // click actions:  <button data-act="name">
  A.forms = {};  // form handlers:  <form data-form="name">
  A.routes = [];
  A.dirty = false;
  A.post = null;

  A.route = function (pattern, role, fn) { A.routes.push({ parts: pattern.split("/"), role: role, fn: fn }); };

  function parseRoute() {
    var h = location.hash.replace(/^#\/?/, ""), p = h.split("?"), q = {};
    new URLSearchParams(p[1] || "").forEach(function (v, k) { q[k] = v; });
    return { parts: p[0].split("/").filter(Boolean).map(decodeURIComponent), q: q };
  }
  function match(parts) {
    for (var i = 0; i < A.routes.length; i++) {
      var r = A.routes[i];
      if (r.parts.length !== parts.length) continue;
      var params = {}, ok = true;
      for (var j = 0; j < r.parts.length; j++) {
        if (r.parts[j][0] === ":") params[r.parts[j].slice(1)] = parts[j];
        else if (r.parts[j] !== parts[j]) { ok = false; break; }
      }
      if (ok) return { r: r, params: params };
    }
    return null;
  }
  A.go = function (path) { location.hash = "#/" + path; };
  A.link = function (path) { return "#/" + path; };

  // ------------------------------------------------------------------ navigation model
  var NAV = {
    student: [["home", "Home", "layout", "student/home"], ["attendance", "Attendance", "calendar", "student/attendance"],
      ["gradebook", "Gradebook", "award", "student/gradebook"], ["schedule", "Schedule", "clock", "student/schedule"],
      ["comm", "Comm Hub", "message", "student/comm"], ["comparison", "Comparison", "bar-chart", "student/comparison"],
      ["export", "Export Progress", "download", "student/export"], ["profile", "Manage Profile", "user", "student/profile", 1],
      ["settings", "Settings", "settings", "account/settings", 1], ["password", "Change Password", "lock", "account/password", 1], ["help", "Help", "help-circle", "account/help", 1]],
    teacher: [["home", "Home", "layout", "teacher/home"], ["attendance", "Attendance Sheet", "calendar", "teacher/attendance"],
      ["gradebook", "Gradebook", "award", "teacher/gradebook"], ["schedule", "Schedule & Events", "clock", "teacher/schedule"],
      ["comm", "Comm Hub", "message", "teacher/comm"], ["comparison", "Comparison", "bar-chart", "teacher/comparison"],
      ["export", "Export", "download", "teacher/export"], ["profile", "Manage Profile", "user", "teacher/profile", 1],
      ["settings", "Settings", "settings", "account/settings", 1], ["password", "Change Password", "lock", "account/password", 1], ["help", "Help", "help-circle", "account/help", 1]]
  };
  function sectionOf(parts) { return parts[0] === "account" ? parts[1] : parts[1]; }

  A.avatar = function (p, size) {
    size = size || 40;
    if (p && p.photo) return A.raw('<img class="avatar" style="width:' + size + "px;height:" + size + 'px" src="' + esc(p.photo) + '" alt="">');
    return A.raw('<span class="avatar avatar-fallback" style="width:' + size + "px;height:" + size + "px;font-size:" + Math.round(size * 0.42) + 'px">' + esc(A.initial(p && p.name)) + "</span>");
  };

  function badgeFor(role, key) {
    if (key !== "comm") return 0;
    if (role === "teacher") return A.q.unread().length;
    var unseen = A.q.posts().filter(function (p) { return !A.q.seen(p.id); }).length;
    return unseen + A.q.unread().length;
  }

  function shell(content, section) {
    var p = A.S.profile, role = p.role, nav = NAV[role], label = "";
    nav.forEach(function (n) { if (n[0] === section) label = n[1]; });
    function item(n) {
      var b = badgeFor(role, n[0]);
      return html`<a href="${A.link(n[3])}" class="${n[0] === section ? "active" : ""}">${icon(n[2], 19)}<span>${n[1]}</span>${b ? html`<span class="badge-dot">${b}</span>` : ""}</a>`;
    }
    var bell = A.notify ? A.notify.bell() : "";
    var pill = A.cloud ? html`<button class="sync-pill" id="sync-pill" data-act="sync-info" title="Changes from other devices appear automatically"><i></i><span>Live</span></button>`
      : html`<button class="sync-pill off" id="sync-pill" data-act="sync-info" title="${A.cloudWanted ? "Cloud connection unavailable" : "Device-only demo: data is stored only on this device"}"><i></i><span>${A.cloudWanted ? "Cloud offline" : "Device only"}</span></button>`;
    var mobileNav = html`<nav class="mobile-nav" aria-label="Primary navigation">${nav.filter(function (n) {
      return ["home", "attendance", "gradebook", "schedule", "comm"].indexOf(n[0]) > -1;
    }).map(item)}</nav>`;
    return html`
    <div id="sidebar-overlay" class="sidebar-overlay" data-act="menu-close"></div>
    <aside class="sidebar">
      <div class="brand"><img src="img/logo.png" alt=""><span>Acadance</span></div>
      <div class="me-card">${A.avatar(p, 40)}<div style="min-width:0"><div class="name">${p.name || p.username}</div><div class="sub">${A.S.user.email.slice(-("@" + A.domain).length) === "@" + A.domain ? "@" + p.username : A.S.user.email}</div><span class="role">${role}</span></div></div>
      <nav class="nav"><div class="nav-label">Menu</div>${nav.filter(function (n) { return !n[4]; }).map(item)}
        <div class="nav-label">Account</div>${nav.filter(function (n) { return n[4]; }).map(item)}</nav>
      <div class="sidebar-foot"><button class="btn block" data-act="logout">${icon("log-out", 17)} Sign out</button><div class="sidebar-ver">Acadance v${A.version}</div></div>
    </aside>
    <div class="main">
      <header class="topbar"><div class="flex items-center gap-2" style="min-width:0"><button class="icon-btn" data-act="menu" aria-label="Menu">${icon("menu", 19)}</button>
        <div class="crumbs"><span>${role === "teacher" ? "Teacher" : "Student"}</span><span class="sep">/</span><b>${label}</b></div></div>
        <div class="right-tools">${pill}<button class="icon-btn" data-act="theme" aria-label="Toggle theme">${icon(A.theme.resolved() === "dark" ? "sun" : "moon", 18)}</button>${bell}
          <div class="user-chip">${A.avatar(p, 32)}<div class="who"><b>${p.name || p.username}</b><span class="muted">${role === "teacher" ? "Teacher" : "Student"}</span></div></div></div></header>
      ${!A.cloud ? html`<div class="demo-ribbon">${icon("info", 16)} <span class="grow">${A.cloudFailed ? "Cloud services are unavailable. Your account has not been switched to device-only data." : "Device-only demo: changes stay on this phone. Connect Firebase to share them between devices."}</span>${A.cloudFailed ? html`<button class="link-btn small" data-act="reload-cloud">Try again</button>` : ""}</div>` : ""}
      <main class="content" id="content">${content}</main>
      <footer class="app-foot"><span>© Acadance · Smart Student Academic Management System · v${A.version}</span><span>Signed in as ${p.username}</span></footer>
      ${mobileNav}
    </div>`;
  }

  // ------------------------------------------------------------------ render loop
  A.locked = function () {
    return A.dirty || A.modalOpen() || document.body.classList.contains("tt-editing");
  };
  function showBanner() {
    if (document.getElementById("sync-banner")) return;
    var b = document.createElement("div");
    b.id = "sync-banner"; b.className = "sync-banner";
    b.innerHTML = '<span>New changes are available from another device.</span><button class="btn sm warn" data-act="refresh">Refresh now</button>';
    document.body.appendChild(b);
  }
  function hideBanner() { var b = document.getElementById("sync-banner"); if (b) b.remove(); }

  A.render = function (force) {
    var root = document.getElementById("app");
    if (!A.S.profile) return;
    if (!force && A.locked()) { A.pending = true; showBanner(); return; }
    A.pending = false; hideBanner();
    var rt = parseRoute(), m = match(rt.parts), role = A.S.profile.role;
    if (!m || (m.r.role && m.r.role !== role)) { location.replace("#/" + role + "/home"); return; }
    A.post = null;
    var content;
    try { content = m.r.fn({ params: m.params, q: rt.q }); }
    catch (e) { console.error(e); content = html`<div class="card"><h3>Something went wrong</h3><p class="muted mt-1">${e.message}</p></div>`; }
    var y = window.scrollY;
    root.innerHTML = A.str(shell(content, sectionOf(rt.parts)));
    setPill();
    window.scrollTo(0, y);
    requestAnimationFrame(function () {
      setTimeout(function () {
        document.querySelectorAll("[data-w]").forEach(function (el) { el.style.width = el.getAttribute("data-w") + "%"; });
        document.querySelectorAll("[data-h]").forEach(function (el) { el.style.height = Math.max(3, parseFloat(el.getAttribute("data-h")) || 0) + "px"; });
      }, 40);
    });
    if (A.post) { var f = A.post; A.post = null; setTimeout(f, 50); }
  };
  /** Re-render shortly after a write, once the live listeners have delivered the new data. */
  A.refresh = function () { A.dirty = false; setTimeout(function () { A.render(true); }, 150); };
  var timer = null;
  A.onData = function () { clearTimeout(timer); timer = setTimeout(function () { A.render(false); }, 60); };
  A.onModalClosed = function () { if (A.pending) A.render(false); };

  A.enterApp = function () {
    document.body.classList.remove("auth-body");
    var pend = window.__pendingRoute; window.__pendingRoute = null;
    if (pend && (pend.split("/")[0] === A.S.profile.role || pend.indexOf("account/") === 0)) location.replace("#/" + pend);
    else if (!location.hash || /^#\/?(login)?$/.test(location.hash)) location.replace("#/" + A.S.profile.role + "/home");
    A.dirty = false; A.render(true);
    A.theme.syncBars(); A.hideSplash();
  };
  A.showAuth = function () {
    try { A.dirty = false; document.getElementById("modal-host").innerHTML = ""; document.body.classList.remove("sidebar-open", "tt-editing"); } catch (e) { /* ignore */ }
    document.body.classList.add("auth-body");
    if (A.renderAuth) A.renderAuth();
    A.theme.syncBars(); A.hideSplash();
  };

  // ------------------------------------------------------------------ global events
  window.addEventListener("hashchange", function () { A.dirty = false; document.body.classList.remove("tt-editing"); if (A.S.profile) A.render(true); });

  document.addEventListener("click", function (e) {
    var t = e.target.closest("[data-act]");
    if (t) {
      var fn = A.acts[t.getAttribute("data-act")];
      if (fn) { e.preventDefault(); try { var r = fn(t, e); if (r && r.catch) r.catch(function (err) { A.toast(A.errMsg(err), "error"); }); } catch (err) { A.toast(A.errMsg(err), "error"); } }
      return;
    }
    if (e.target.hasAttribute && e.target.hasAttribute("data-overlay")) A.closeModal();
    if (!e.target.closest(".notif-wrap")) { var p = document.getElementById("notif-panel"); if (p) p.classList.remove("show"); }
  });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && A.modalOpen()) A.closeModal(); });
  document.addEventListener("input", function (e) {
    var f = e.target.closest && e.target.closest("[data-filter]");
    if (f) {
      var q = f.value.trim().toLowerCase();
      document.querySelectorAll(f.getAttribute("data-filter") + " tr").forEach(function (tr) { tr.style.display = !q || tr.textContent.toLowerCase().indexOf(q) > -1 ? "" : "none"; });
      return;
    }
    if (e.target.closest && e.target.closest("#content") && !e.target.hasAttribute("data-nodirty")) A.dirty = true;
  }, true);
  document.addEventListener("change", function (e) {
    var c = e.target.closest && e.target.closest("[data-change]");
    if (c) { var fn = A.acts[c.getAttribute("data-change")]; if (fn) fn(c, e); return; }
    if (e.target.closest && e.target.closest("#content") && !e.target.hasAttribute("data-nodirty")) A.dirty = true;
  }, true);
  document.addEventListener("submit", function (e) {
    var f = e.target.closest("form[data-form]");
    if (!f) return;
    e.preventDefault();
    var fn = A.forms[f.getAttribute("data-form")];
    if (!fn) return;
    var btns = f.querySelectorAll("button[type=submit]");
    btns.forEach(function (b) { b.disabled = true; b.classList.add("loading"); });
    Promise.resolve().then(function () { return fn(f, new FormData(f)); }).then(function () { A.dirty = false; if (A.pending) A.refresh(); })
      .catch(function (err) { if (!(err && err.handled)) A.toast(A.errMsg(err), "error"); })
      .then(function () { btns.forEach(function (b) { b.disabled = false; b.classList.remove("loading"); }); });
  });

  function setPill() {
    var p = document.getElementById("sync-pill");
    if (!p || !A.cloud) return;
    var on = navigator.onLine !== false;
    p.classList.toggle("off", !on); p.lastChild.textContent = on ? "Live" : "Offline";
  }
  window.addEventListener("online", setPill); window.addEventListener("offline", setPill);

  // generic actions
  A.acts.menu = function () { if (window.innerWidth <= 860) document.body.classList.toggle("sidebar-open"); else { document.body.classList.toggle("sidebar-collapsed"); try { localStorage.setItem("acadance-sidebar", document.body.classList.contains("sidebar-collapsed") ? "0" : "1"); } catch (e) {} } };
  A.acts["menu-close"] = function () { document.body.classList.remove("sidebar-open"); };
  A.acts.theme = function () { A.theme.toggle(); };
  A.acts.bell = function (el, e) { e.stopPropagation(); var p = document.getElementById("notif-panel"); if (p) p.classList.toggle("show"); };
  A.acts.logout = function () { return A.confirm("Sign out?", "You will need to sign in again to use your account on this device.", "Sign out").then(function (ok) { if (ok) { A.dirty = false; document.body.classList.remove("sidebar-open"); return A.AUTH.signOut(); } }); };
  A.acts.refresh = function () { A.dirty = false; document.body.classList.remove("tt-editing"); A.render(true); };
  A.acts["sync-info"] = function () {
    if (!A.cloud) {
      A.toast(A.cloudWanted ? "Cloud services are unavailable. Reconnect and reload; device-only data is not being used." : "Device-only demo: changes stay on this phone. Connect Firebase to share them.", A.cloudWanted ? "error" : "success");
      return;
    }
    var online = navigator.onLine !== false;
    A.toast(online ? "Live sync is on. Last update: " + (A.lastSyncAt ? A.tsLong(A.lastSyncAt) : "connecting…") + ". Changes made offline upload automatically after reconnecting." : "You are offline. Saved changes will upload automatically when the connection returns.", online ? "success" : "error");
  };
  A.acts["reload-cloud"] = function () { location.reload(); };
  A.acts["close-modal"] = function () { A.closeModal(); };
  A.acts["confirm-yes"] = function () { if (A._confirmResolve) A._confirmResolve(true); };
  A.acts["confirm-no"] = function () { if (A._confirmResolve) A._confirmResolve(false); };
  A.acts.print = function () { window.print(); };

  // ------------------------------------------------------------------ boot
  A.boot = function () {
    A.theme.apply();
    try { if (innerWidth > 860 && localStorage.getItem("acadance-sidebar") === "0") document.body.classList.add("sidebar-collapsed"); } catch (e) {}
    A.AUTH.onChange(function (u) {
      if (A.registering || A.seeding) return;
      if (u) A.afterAuth(); else { A.S.user = null; A.S.profile = null; A.stopStore(); A.showAuth(); }
    });
    if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost" || location.hostname === "127.0.0.1")) {
      window.addEventListener("load", function () { navigator.serviceWorker.register("sw.js").catch(function () {}); });
    }
  };
})();
