/* Acadance service worker: keeps the app shell available (fast start, installable). Data always comes live from the database. */
const CACHE = "acadance-shell-v9";
const SHELL = ["./", "index.html", "css/app.css", "css/pro.css", "css/theme.css", "css/ui5.css", "js/extras.js", "js/native.js", "js/notify.js", "fonts/Poppins-Medium.woff", "fonts/Poppins-Bold.woff", "img/logo.png", "img/icon-192.png",
  "js/config.js", "js/core.js", "js/icons.js", "js/academic.js", "js/backend-firebase.js", "js/backend-local.js", "js/data.js",
  "js/app.js", "js/ui.js", "js/polish.js", "js/views-v4.js", "js/views-student.js", "js/views-teacher.js", "js/views-auth.js", "js/demo.js",
  "vendor/firebase-app-compat.js", "vendor/firebase-auth-compat.js", "vendor/firebase-firestore-compat.js"];

self.addEventListener("install", (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (e) => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== "GET" || url.origin !== self.location.origin) return;
  // Network first: a new build is used right away. The cache is only an offline fallback.
  e.respondWith(caches.open(CACHE).then((cache) => fetch(req).then((res) => { if (res.ok) cache.put(req, res.clone()); return res; })
    .catch(() => cache.match(req).then((hit) => hit || Response.error()))));
});
