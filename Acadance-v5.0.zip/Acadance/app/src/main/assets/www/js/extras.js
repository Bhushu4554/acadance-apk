/* Acadance 5 extras: accent colour + text size (Settings > Appearance). Saved on this device. */
(function () {
  "use strict";
  var A = window.A, root = document.documentElement, KA = "acadance-accent", KF = "acadance-fs";
  var ACC = [["emerald", "#0b9a6c", "Emerald"], ["ocean", "#1c7ad6", "Ocean"], ["violet", "#7656f0", "Violet"], ["rose", "#e04458", "Rose"], ["amber", "#d98206", "Amber"]];
  var FS = [["s", "A-"], ["m", "A"], ["l", "A+"], ["xl", "A++"]];
  function get(k, d) { try { return localStorage.getItem(k) || d; } catch (e) { return d; } }
  function put(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* private mode */ } }
  function apply() {
    root.setAttribute("data-accent", get(KA, "emerald"));
    root.setAttribute("data-fs", get(KF, "m"));
  }
  apply();
  function block() {
    var a = get(KA, "emerald"), f = get(KF, "m");
    return '<div class="ext-appearance"><p class="xl-label">Accent colour</p><div class="swatches" role="group" aria-label="Accent colour">' +
      ACC.map(function (c) { return '<button type="button" class="swatch" data-accent="' + c[0] + '" style="background:' + c[1] + '" aria-label="' + c[2] + '" aria-pressed="' + (c[0] === a) + '"></button>'; }).join("") +
      '</div><p class="xl-label">Text size</p><div class="fs-row" role="group" aria-label="Text size">' +
      FS.map(function (s) { return '<button type="button" data-fs="' + s[0] + '" aria-pressed="' + (s[0] === f) + '">' + s[1] + '</button>'; }).join("") + '</div></div>';
  }
  function inject(main) {
    if (!main || main.querySelector(".ext-appearance")) return;
    var seg = main.querySelector('[aria-label="Theme"]');
    if (seg && seg.parentNode) seg.parentNode.insertAdjacentHTML("beforeend", block());
  }
  var prev = A.afterRender;
  A.afterRender = function (main) {
    if (prev) prev.apply(this, arguments);
    try { if (/account\/settings/.test(location.hash)) inject(main); } catch (e) { console.error(e); }
  };
  document.addEventListener("click", function (e) {
    var t = e.target.closest && e.target.closest("[data-accent],[data-fs]");
    if (!t || !t.closest(".ext-appearance")) return;
    if (t.hasAttribute("data-accent")) put(KA, t.getAttribute("data-accent")); else put(KF, t.getAttribute("data-fs"));
    apply();
    var wrap = t.closest(".ext-appearance"); wrap.outerHTML = block();
    var m = document.querySelector('meta[name="theme-color"]');
    if (m && !/^#0|dark/.test(root.getAttribute("data-theme") || "")) { /* keep status bar as set by the theme code */ }
  });
})();
