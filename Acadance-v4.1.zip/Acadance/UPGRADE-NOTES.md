# Acadance 4.1 - sign-up fix

* Fixed: "That e-mail address is already registered." when the optional e-mail box was left empty. An old unfinished sign-up could hold the hidden login address; the app now creates a fresh hidden address automatically, so sign-up works.
* Fixed: a failed "resume sign-up" attempt could leave the phone signed in to a different account.
* Version 4.1 (versionCode 7) so the new APK installs over the old one. Nothing else was changed.

# Acadance 4.0 - new design + loading + more features

* New "Emerald Ink" design system (css/theme.css): new colours, type, buttons, cards, tables, dark mode, floating tab bar on phones, icon rail on tablets, large-screen/TV scaling, landscape and foldable rules, print.
* Loading: skeleton screens while data loads (no more flash of "nothing here yet"), top progress bar on every navigation/save, pull-to-refresh, back-to-top, animated rings and counters.
* Student: new dashboard (attendance ring, next-class card, at-risk count, grades passed, latest announcement), attendance filters, monthly attendance calendar, streak, "plan ahead" what-if calculator, grade targets ("you need X/Y in the final"), day-by-day timetable on phones, search + "mark all as seen" in Comm Hub, comparison summary.
* Teacher: division overview cards on the dashboard, sticky roll/name columns on wide sheets.
* Everyone: FAQ in Help, show/hide + strength meter on password fields, skip link and aria-current for accessibility.
* Fixed: 10 icons (Settings, Smartphone, Zap, Shield...) were missing and showed as a generic info icon; malformed links no longer crash the router; timetable words no longer break mid-word.
* Version 4.0 (versionCode 6). New files: css/theme.css, js/polish.js, js/views-v4.js.

# Acadance 3.1 - bug-fix release

* Sign-up crash fixed: "fullName is not defined" (student and teacher). The name is now saved correctly.
* A failed sign-up no longer leaves a half-made account that blocks your e-mail ("already registered"). Retrying works, and the error message and typed details stay on screen.
* E-mail is validated before the account is created.
* Service worker now loads the newest files first (cache v6), so an updated app/APK never keeps running old code.
* "Turn on notifications" pop-up and other dialogs no longer stay on screen after sign-out.
* Student home empty state no longer shows a literal "<br>".
* Marking messages/posts as read can no longer throw an unhandled error.
* Version 3.1 (versionCode 5) so the new APK installs over the old one.

# Acadance 3.0 - what changed

* New sign-in / sign-up screens (2-step sign-up, full name, PRN, confirm password, live username check, remember me, caps-lock warning, terms, inline errors).
* Responsive layout for phones, foldables, tablets and desktop; bottom-sheet dialogs; safe-area aware; light / dark / system theme with matching status bar.
* Notifications: in-app bell + heads-up banners, Android pop-up notifications (channels, tap opens the right screen), background check about every 15 minutes while the app is closed.
* New Settings page (notifications, appearance, account, about), splash screen, offline bar, double-back-to-exit, new adaptive icon.

## Build
Push the repository to GitHub. `.github/workflows/build-apk.yml` builds a signed APK (Actions > Build Acadance APK > Artifacts).
The folder `Acadance/` must sit at the repository root; if your repository root IS the Acadance folder, change `working-directory: Acadance` to `.`
and the artifact path to `app/build/outputs/apk/release/*.apk`.

The APK is signed with `app/acadance-release.jks`, so every future build installs over the previous one.
The very first time, uninstall the old Acadance APK (it was signed with a different key). Your data is in Firebase, nothing is lost.
