/* Student pages. */
(function () {
  "use strict";
  var A = window.A, html = A.html, icon = A.icon, U = A.ui;
  var YEAR_SEMS = ["1st Year SEM-I", "1st Year SEM-II", "2nd Year SEM-III", "2nd Year SEM-IV", "3rd Year SEM-V", "3rd Year SEM-VI", "4th Year SEM-VII", "4th Year SEM-VIII"];
  function P() { return A.S.profile; }

  function rows() {
    var uid = A.q.uid();
    return A.q.divs().map(function (d) {
      var r = A.q.records(d.id, uid), dates = Object.keys(r), present = dates.filter(function (x) { return r[x]; }).length;
      return { d: d, total: dates.length, present: present, absent: dates.length - present, pct: A.pct(present, dates.length), advice: A.advice(present, dates.length) };
    }).filter(function (r) { return r.total > 0; });
  }
  function overall(rs) {
    var t = 0, p = 0; rs.forEach(function (r) { t += r.total; p += r.present; });
    return { total: t, present: p, absent: t - p, pct: A.pct(p, t), advice: A.advice(p, t) };
  }
  function myTimetable() {
    var tts = A.store.timetables, name = (P().division || "").toLowerCase();
    return tts.filter(function (t) { return (t.divisionName || "").toLowerCase() === name; })[0] || tts[0] || null;
  }
  A.todays = function (tt) {
    var idx = A.todayIndex(), now = A.nowHM(), out = [];
    if (!tt || idx < 0) return out;
    (tt.slots || []).forEach(function (s) {
      var subj = s.isBreak ? s.name || "Break" : (tt.cells || {})[s.id + "_" + idx];
      if (!subj) return;
      out.push({ slot: s, subject: subj, isBreak: s.isBreak, isNow: s.start <= now && now < s.end });
    });
    return out;
  };

  // ------------------------------------------------------------------ home
  A.route("student/home", "student", function () {
    var rs = rows(), ov = overall(rs), p = P(), tt = myTimetable(), today = A.todays(tt), today0 = A.today();
    var upcoming = A.q.posts().filter(function (x) { return x.type === "assignment" && x.dueDate >= today0; })
      .sort(function (a, b) { return a.dueDate < b.dueDate ? -1 : 1; }).slice(0, 4);
    return html`
    <div class="grid hero"><div class="card hero-card"><div class="eyebrow" style="color:#fcd34d">Student dashboard</div>
      <h2 style="font-size:24px">Welcome back, ${p.name || p.username}</h2><p class="muted mt-1">Your attendance, grades and timetable at a glance.</p>
      <div class="flex items-center justify-between gap-2 mt-3 wrap"><div><div class="small muted">Overall attendance</div><div style="font-size:44px;font-weight:800;line-height:1;letter-spacing:-.04em">${ov.pct}%</div></div>
        <a class="btn ghost" href="${A.link("student/attendance")}">View details ${icon("chevron-right", 16)}</a></div>
      <div class="progress mt-2" style="background:rgba(255,255,255,.25)"><span style="background:#fff" data-w="${ov.pct.toFixed(1)}"></span></div>
      ${ov.advice ? html`<p class="mt-2 small">${icon("info", 15)} ${ov.advice.text}</p>` : ""}</div>
    <div class="grid cols-3"><div class="stat"><div class="ico">${icon("book", 20)}</div><div class="label">Divisions</div><div class="value">${A.q.divs().length}</div><div class="hint">you are enrolled in</div></div>
      <div class="stat tone-good"><div class="ico">${icon("check-circle", 20)}</div><div class="label">Present</div><div class="value">${ov.present}</div><div class="hint">classes attended</div></div>
      <div class="stat tone-bad"><div class="ico">${icon("x-circle", 20)}</div><div class="label">Absent</div><div class="value">${ov.absent}</div><div class="hint">classes missed</div></div></div></div>
    <div class="grid cols-2 mt-3">
      <div class="card"><div class="card-head"><div><h3>Subjects &amp; attendance</h3><div class="sub">Minimum required: 75%</div></div><a class="btn ghost sm" href="${A.link("student/attendance")}">All subjects</a></div>
        <div class="list">${A.each(rs, function (r) {
          return html`<a class="item clickable" href="${A.link("student/attendance/" + r.d.id)}" style="color:inherit;text-decoration:none;display:block">
            <div class="flex items-center gap-2"><div class="grow"><h4>${r.d.subject} <span class="muted small">· ${r.d.name}</span></h4><div class="progress mt-1"><span class="${A.tone(r.pct)}" data-w="${r.pct.toFixed(1)}"></span></div></div>
              <b class="${r.pct < 75 ? "text-bad" : "text-good"}" style="font-size:16px">${r.pct}%</b></div>
            ${r.advice ? html`<div class="advice ${r.advice.tone}">${icon("info", 14)}<span>${r.advice.text}</span></div>` : ""}</a>`;
        }, U.empty("calendar", "No attendance recorded yet.<br>Add your PRN in your profile so your teacher can enrol you."))}</div></div>
      <div class="grid" style="align-content:start">
        <div class="card"><div class="card-head"><div><h3>Today's classes</h3><div class="sub">${tt ? "From your division timetable" : "Timetable not published yet"}</div></div><a class="btn ghost sm" href="${A.link("student/schedule")}">Full week</a></div>
          ${A.each(today, function (l) {
            return html`<div class="today-row ${l.isNow ? "now" : ""}"><div class="today-time">${A.time12(l.slot.start)} – ${A.time12(l.slot.end)}</div>
              <div class="grow today-subj">${l.isBreak ? html`<span class="muted">${icon("coffee", 14)} ${l.subject}</span>` : l.subject}</div>${l.isNow ? html`<span class="badge info">Now</span>` : ""}</div>`;
          }, html`<p class="muted small">${tt ? "No classes scheduled for today." : "Once your teacher publishes the timetable, today's classes appear here."}</p>`)}</div>
        <div class="card"><div class="card-head"><h3>Upcoming assignments</h3><a class="btn ghost sm" href="${A.link("student/comm?tab=assignments")}">View all</a></div>
          <div class="list">${A.each(upcoming, function (a) {
            return html`<div class="item"><div class="ico-box purple">${icon("clipboard", 19)}</div><div class="grow"><h4>${a.title}</h4><div class="meta">Due ${A.dLong(a.dueDate)} · ${a.maxMarks} marks</div></div></div>`;
          }, html`<p class="muted small">Nothing due - enjoy the breathing room.</p>`)}</div></div></div></div>`;
  });

  // ------------------------------------------------------------------ profile
  function field(label, name, val, extra) { return html`<div class="field"><label>${label}</label><input class="input" name="${name}" value="${val || ""}" ${extra || ""}></div>`; }
  function options(list, cur, ph) { return html`<option value="">${ph}</option>${list.map(function (x) { return html`<option value="${x}" ${x === cur ? "selected" : ""}>${x}</option>`; })}`; }
  A.route("student/profile", "student", function (ctx) {
    var p = P(), tab = ["personal", "academic", "contact"].indexOf(ctx.q.tab) > -1 ? ctx.q.tab : "personal";
    var checks = [["dob", p.dob], ["address", p.address], ["aadhaar", p.aadhaar], ["PRN", p.prn], ["division", p.division], ["year", p.yearSem], ["program", p.program], ["ABC ID", p.abcId], ["mobile", p.mobile], ["parent name", p.parentName], ["parent mobile", p.parentMobile]];
    var missing = checks.filter(function (c) { return !c[1]; }).map(function (c) { return c[0]; });
    var comp = Math.round((100 * (checks.length - missing.length)) / checks.length);
    var progs = p.programLevel && A.ACADEMIC[p.programLevel] ? Object.keys(A.ACADEMIC[p.programLevel]) : [];
    var specs = (p.programLevel && p.program && A.ACADEMIC[p.programLevel] && A.ACADEMIC[p.programLevel][p.program] || []).filter(function (x) { return x !== "-"; });
    var form;
    if (tab === "personal") form = html`<form class="form-grid" data-form="profilePersonal"><div class="field span-2"><label>Name</label><input class="input" name="name" value="${p.name}" required></div>
      ${field("Aadhaar number", "aadhaar", p.aadhaar, 'inputmode="numeric"')}<div class="field"><label>Date of birth</label><input class="input" type="date" name="dob" value="${p.dob || ""}"></div>
      <div class="field span-2"><label>Address</label><textarea class="input" name="address" rows="3">${p.address || ""}</textarea></div>
      <div class="form-actions span-2"><button class="btn success" type="submit">Save changes</button></div></form>`;
    else if (tab === "academic") form = html`<form class="form-grid" data-form="profileAcademic">${field("PRN", "prn", p.prn)}${field("ABC ID", "abcId", p.abcId)}
      <div class="field span-2"><label>Division</label><input class="input" name="division" value="${p.division || ""}" placeholder="e.g. SY-A (for your reference)"></div>
      <div class="field"><label>Level</label><select class="input" name="programLevel" data-change="acad-level" data-nodirty>${options(["UG", "PG"], p.programLevel, "Select level")}</select></div>
      <div class="field"><label>Year &amp; semester</label><select class="input" name="yearSem">${options(YEAR_SEMS, p.yearSem, "Select year & sem")}</select></div>
      <div class="field"><label>Program</label><select class="input" name="program" id="sel-program" data-change="acad-program" data-nodirty>${options(progs, p.program, "Select program")}</select></div>
      <div class="field"><label>Specialization</label><select class="input" name="specialization" id="sel-spec">${options(specs, p.specialization, specs.length ? "Select specialization" : "— none —")}</select></div>
      <div class="form-actions span-2"><button class="btn success" type="submit">Save changes</button></div></form>`;
    else form = html`<form class="form-grid" data-form="profileContact">${field("Mobile number", "mobile", p.mobile)}
      <div class="field"><label>Account e-mail</label><input class="input" value="${A.S.user.email}" disabled></div>
      <div class="span-2 card" style="background:var(--surface-2);box-shadow:none"><h3 class="mb-2">Parent / guardian information</h3><div class="form-grid">
        ${field("Name", "parentName", p.parentName)}${field("Mobile", "parentMobile", p.parentMobile)}<div class="field span-2"><label>E-mail</label><input class="input" type="email" name="parentEmail" value="${p.parentEmail || ""}"></div></div></div>
      <div class="form-actions span-2"><button class="btn success" type="submit">Save changes</button></div></form>`;
    return html`${U.head("Manage profile", "Your PRN lets your teacher add you to a division - then your attendance, grades and timetable appear.")}
      <div class="card mb-3"><div class="meter"><div style="min-width:150px"><div class="bold">Profile completeness</div><div class="muted small">${missing.length ? "Still missing: " + missing.join(", ") : "All details filled in"}</div></div>
        <div class="progress"><span class="${comp >= 80 ? "good" : comp >= 50 ? "warn" : "bad"}" data-w="${comp}"></span></div><b>${comp}%</b></div></div>
      <div class="card"><div class="grid profile-grid" style="grid-template-columns:220px 1fr;gap:28px"><div>${U.picCard(p)}</div><div>
        <div class="tabs"><a class="tab ${tab === "personal" ? "active" : ""}" href="${A.link("student/profile?tab=personal")}">${icon("user", 16)} Personal</a>
          <a class="tab ${tab === "academic" ? "active" : ""}" href="${A.link("student/profile?tab=academic")}">${icon("graduation", 16)} Academic</a>
          <a class="tab ${tab === "contact" ? "active" : ""}" href="${A.link("student/profile?tab=contact")}">${icon("phone", 16)} Contact</a></div>${form}</div></div></div>`;
  });
  function fill(sel, list, ph) {
    sel.innerHTML = '<option value="">' + A.esc(ph) + "</option>" + list.map(function (x) { return '<option value="' + A.esc(x) + '">' + A.esc(x) + "</option>"; }).join("");
  }
  A.acts["acad-level"] = function (el) {
    var progs = el.value && A.ACADEMIC[el.value] ? Object.keys(A.ACADEMIC[el.value]) : [];
    fill(document.getElementById("sel-program"), progs, "Select program"); fill(document.getElementById("sel-spec"), [], "— none —");
    A.dirty = true;
  };
  A.acts["acad-program"] = function (el) {
    var lvl = document.querySelector('[name=programLevel]').value, list = (A.ACADEMIC[lvl] && A.ACADEMIC[lvl][el.value] || []).filter(function (x) { return x !== "-"; });
    fill(document.getElementById("sel-spec"), list, list.length ? "Select specialization" : "— none —");
    A.dirty = true;
  };
  A.forms.profilePersonal = function (f, fd) {
    return A.svc.saveProfile({ name: fd.get("name").trim(), aadhaar: fd.get("aadhaar").trim(), dob: fd.get("dob") || "", address: fd.get("address").trim() }).then(function () { A.toast("Profile saved."); });
  };
  A.forms.profileAcademic = function (f, fd) {
    var lvl = fd.get("programLevel"), prog = fd.get("program"), ok = lvl && prog && A.ACADEMIC[lvl] && A.ACADEMIC[lvl][prog];
    return A.svc.saveProfile({ prn: fd.get("prn").trim(), abcId: fd.get("abcId").trim(), division: fd.get("division").trim(), yearSem: fd.get("yearSem"),
      programLevel: ok ? lvl : "", program: ok ? prog : "", specialization: ok ? fd.get("specialization") : "" }).then(function () { A.toast("Profile saved."); });
  };
  A.forms.profileContact = function (f, fd) {
    return A.svc.saveProfile({ mobile: fd.get("mobile").trim(), parentName: fd.get("parentName").trim(), parentMobile: fd.get("parentMobile").trim(), parentEmail: fd.get("parentEmail").trim() }).then(function () { A.toast("Profile saved."); });
  };

  // ------------------------------------------------------------------ attendance
  A.route("student/attendance", "student", function () {
    var rs = rows(), ov = overall(rs);
    return html`${U.head("My attendance", "Overall " + ov.pct + "% across " + ov.total + " classes. Select a subject for day-by-day details.")}
      ${ov.advice ? html`<div class="hint-box ${ov.advice.tone} mb-3">${icon("info", 18)}<div>${ov.advice.text}</div></div>` : ""}
      <div class="card"><div class="list">${A.each(rs, function (r) {
        return html`<a class="picker-btn" href="${A.link("student/attendance/" + r.d.id)}"><div class="grow"><div class="bold">${r.d.subject}</div><div class="muted small">${r.d.name} · ${r.d.teacherName}</div>
          <div class="progress mt-1" style="max-width:340px"><span class="${A.tone(r.pct)}" data-w="${r.pct.toFixed(1)}"></span></div></div>
          <div class="right"><b style="font-size:18px" class="${r.pct >= 75 ? "text-good" : "text-bad"}">${r.pct}%</b><div class="muted small">${r.present}/${r.total} present</div></div>${icon("chevron-right", 18)}</a>
          ${r.advice ? html`<div class="advice ${r.advice.tone}" style="margin:-4px 0 4px">${icon("info", 14)}<span>${r.advice.text}</span></div>` : ""}`;
      }, U.empty("calendar", "No attendance records found yet."))}</div></div>`;
  });
  A.route("student/attendance/:id", "student", function (ctx) {
    var d = A.q.div(ctx.params.id), r = d ? A.q.records(d.id, A.q.uid()) : {}, dates = Object.keys(r).sort().reverse();
    if (!d || !dates.length) return html`${U.head("Attendance", "")}${U.empty("calendar", "No attendance records found for that subject yet.")}<p class="mt-3"><a class="btn ghost" href="${A.link("student/attendance")}">Back</a></p>`;
    var present = dates.filter(function (x) { return r[x]; }).length, pct = A.pct(present, dates.length), adv = A.advice(present, dates.length);
    return html`<a class="btn ghost sm mb-3" href="${A.link("student/attendance")}">${icon("arrow-left", 16)} Back to subjects</a>
      ${U.head(d.subject, d.name + " · " + d.teacherName)}
      ${adv ? html`<div class="hint-box ${adv.tone} mb-3">${icon("info", 18)}<div>${adv.text}</div></div>` : ""}
      <div class="grid cols-3 mb-3"><div class="stat"><div class="label">Attendance</div><div class="value ${pct < 75 ? "text-bad" : "text-good"}">${pct}%</div></div>
        <div class="stat tone-good"><div class="label">Present</div><div class="value">${present}</div></div><div class="stat tone-bad"><div class="label">Absent</div><div class="value">${dates.length - present}</div></div></div>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Date</th><th>Teacher</th><th class="c">Status</th></tr></thead><tbody>${dates.map(function (x) {
        return html`<tr><td>${A.dow(x)}, ${A.dLong(x)}</td><td>${d.teacherName}</td><td class="c">${r[x] ? html`<span class="badge good">Present</span>` : html`<span class="badge bad">Absent</span>`}</td></tr>`;
      })}</tbody></table></div>`;
  });

  // ------------------------------------------------------------------ gradebook
  A.route("student/gradebook", "student", function () {
    var items = A.store.gradeItems.slice().sort(function (a, b) { return A.natCmp(a.title, b.title); }), uid = A.q.uid();
    return html`${U.head("My subject gradebook", "Unit tests are out of 30 each; UT-1 + UT-2 must reach 18 to be eligible for the final exam (pass: 30%).")}
      <div class="list" style="gap:18px">${A.each(items, function (it) {
        var g = A.grade(A.q.mark(it.id, uid), it.finalMax), tone = g.overall === "PASSED" ? "solid-good" : g.overall === "PENDING" ? "solid-warn" : "solid-bad";
        return html`<div class="card grade-card"><div class="flex justify-between gap-2 wrap"><div><h3 style="font-size:20px">${it.title} <span class="muted small">(${it.divisionName})</span></h3></div>
          <span class="badge ${tone}" style="padding:8px 14px;font-size:13px">${g.overall}</span></div>
          <div class="grade-parts">
            <div class="grade-part"><div class="t">UT-1</div><div class="v">${g.ut1 === null ? "—" : g.ut1} <span class="muted small">/ 30</span></div><div class="progress"><span class="${g.ut1 !== null && g.ut1 < 9 ? "bad" : "good"}" data-w="${Math.round(((g.ut1 || 0) / 30) * 100)}"></span></div></div>
            <div class="grade-part"><div class="t">UT-2</div><div class="v">${g.ut2 === null ? "—" : g.ut2} <span class="muted small">/ 30</span></div><div class="progress"><span class="${g.ut2 !== null && g.ut2 < 9 ? "bad" : "good"}" data-w="${Math.round(((g.ut2 || 0) / 30) * 100)}"></span></div></div>
            <div class="grade-part ${g.cstatus === "PASS" ? "pass" : g.cstatus === "FAIL" ? "fail" : ""}"><div class="t">Combined (pass 18)</div><div class="v">${g.combined} <span class="small">/ 60</span></div><div class="small bold">${g.cstatus}</div></div>
            <div class="grade-part ${g.fstatus === "PASS" ? "pass" : g.fstatus === "FAIL" ? "fail" : ""}"><div class="t">Final exam</div><div class="v">${g.fin === null ? "—" : g.fin} <span class="muted small">/ ${it.finalMax}</span></div><div class="small bold">${g.fstatus}</div></div></div></div>`;
      }, U.empty("award", "No subject grades found for you yet."))}</div>`;
  });

  // ------------------------------------------------------------------ schedule
  A.ttTable = function (tt, edit) {
    var ti = A.todayIndex();
    return html`<div class="table-wrap"><table class="tbl tt"><thead><tr><th style="text-align:left">Time slot</th>${A.DAYS.map(function (d, i) { return html`<th class="${i === ti ? "today" : ""}">${d}</th>`; })}</tr></thead><tbody>
      ${(tt.slots || []).map(function (s) {
        var time = html`${A.time12(s.start)} – ${A.time12(s.end)}`;
        var tools = edit ? html`<div class="slot-tools"><button type="button" class="btn ghost sm" data-act="slot-edit" data-id="${s.id}">${icon("edit", 14)}</button><button type="button" class="btn danger sm" data-act="slot-del" data-id="${s.id}">${icon("trash", 14)}</button></div>` : "";
        if (s.isBreak) return html`<tr class="break"><td class="time">${time}${tools}</td><td colspan="6">${icon("coffee", 16)} ${s.name || "BREAK"}</td></tr>`;
        return html`<tr><td class="time">${time}${tools}</td>${A.DAYS.map(function (d, i) {
          var v = (tt.cells || {})[s.id + "_" + i] || "";
          return html`<td class="${i === ti ? "today" : ""}">${edit ? html`<input class="input tt-input" data-key="${s.id}_${i}" value="${v}" placeholder="Subject / topic" disabled>` : html`<span class="tt-cell-text">${v}</span>`}</td>`;
        })}</tr>`;
      })}</tbody></table></div>`;
  };
  A.route("student/schedule", "student", function () {
    var tt = myTimetable();
    return html`${U.head("My weekly timetable", tt ? html`Division <b class="text-primary">${tt.divisionName}</b> · ${tt.teacherName}` : "Your timetable appears here once your teacher publishes it.")}
      ${tt ? A.ttTable(tt, false) : U.empty("clock", "No timetable found for your division yet. Ask your teacher to add you to a division.")}`;
  });

  // ------------------------------------------------------------------ comm hub
  A.route("student/comm", "student", function (ctx) {
    var tab = ["announcements", "assignments", "directmessage", "history"].indexOf(ctx.q.tab) > -1 ? ctx.q.tab : "announcements";
    var posts = A.q.posts(), notices = posts.filter(function (x) { return x.type === "announcement"; }), asg = posts.filter(function (x) { return x.type === "assignment"; });
    var unseenN = notices.filter(function (x) { return !A.q.seen(x.id); }).length, unseenA = asg.filter(function (x) { return !A.q.seen(x.id); }).length;
    var inbox = A.store.msgIn.slice().sort(function (a, b) { return b.created - a.created; }), unread = inbox.filter(function (m) { return !m.read; });
    var body;
    if (tab === "announcements") body = html`<div class="list">${A.each(notices, function (n) {
      var seen = A.q.seen(n.id);
      return html`<div class="item clickable ${seen ? "" : "unseen"}" data-act="open-post" data-id="${n.id}"><div class="ico-box blue">${icon("megaphone", 20)}</div>
        <div class="grow"><div class="flex justify-between gap-2 wrap"><h4>${n.title}</h4>${seen ? html`<span class="badge good">${icon("check", 12)} Seen</span>` : html`<span class="badge bad">NEW</span>`}</div>
        <div class="meta">${n.teacherName} · ${A.tsLong(n.created)} · ${n.scopeName}</div><p class="body">${n.body.length > 150 ? n.body.slice(0, 150) + "…" : n.body}</p></div></div>`;
    }, U.empty("megaphone", "No announcements have been published for you yet."))}</div>`;
    else if (tab === "assignments") body = html`<div class="list">${A.each(asg.slice().sort(function (a, b) { return a.dueDate < b.dueDate ? -1 : 1; }), function (a) {
      var seen = A.q.seen(a.id), past = a.dueDate < A.today();
      return html`<div class="item clickable ${seen ? "" : "unseen"}" data-act="open-post" data-id="${a.id}"><div class="ico-box purple">${icon("clipboard", 20)}</div>
        <div class="grow"><div class="flex justify-between gap-2 wrap"><h4>${a.title}</h4>${seen ? html`<span class="badge good">${icon("check", 12)} Seen</span>` : html`<span class="badge bad">NEW</span>`}</div>
        <div class="meta">${a.teacherName} · Max marks ${a.maxMarks}</div><p class="mt-1 small">Due <b class="${past ? "text-bad" : "text-good"}">${A.dLong(a.dueDate)}${past ? " (past due)" : ""}</b></p></div></div>`;
    }, U.empty("clipboard", "No assignments have been uploaded for you yet."))}</div>`;
    else if (tab === "directmessage") body = html`<div class="card" style="max-width:640px"><h3 class="mb-2">Send a direct message to a teacher</h3>
      <form data-form="studentDm" class="grid" style="gap:14px"><div class="field"><label>Select teacher</label><select class="input" name="to" required><option value="">Choose a teacher…</option>
        ${A.store.teachers.slice().sort(function (a, b) { return A.natCmp(a.name, b.name); }).map(function (t) { return html`<option value="${t.id}">${t.name} (${t.username})</option>`; })}</select></div>
        <div class="field"><label>Message</label><textarea class="input" name="message" rows="5" placeholder="Your message…" required></textarea></div>
        <div class="form-actions"><button class="btn" type="submit">${icon("send", 16)} Send message</button></div></form></div>`;
    else {
      body = html`<div class="list">${A.each(inbox, function (m) {
        var fresh = !m.read;
        return html`<div class="item ${fresh ? "unseen" : ""}"><div class="ico-box orange">${icon("mail", 20)}</div><div class="grow"><div class="flex justify-between gap-2 wrap"><h4>Message from ${m.fromName}</h4><span class="muted small">${A.tsLong(m.created)}</span></div>
          <p class="body pre-wrap">${m.body}</p>${fresh ? html`<span class="badge info mt-1">NEW MESSAGE</span>` : ""}</div></div>`;
      }, U.empty("inbox", "No direct messages received from teachers yet."))}</div>`;
      if (unread.length) { var ids = unread.map(function (m) { return m.id; }); A.post = function () { A.svc.markRead(ids); }; }
    }
    return html`${U.head("Communication hub", "Announcements, assignments and messages from your teachers.")}
      ${U.tabs("student/comm", [{ key: "announcements", label: "Announcements", icon: "megaphone", badge: unseenN }, { key: "assignments", label: "Assignments", icon: "clipboard", badge: unseenA },
        { key: "directmessage", label: "Direct message", icon: "send" }, { key: "history", label: "Teacher messages", icon: "inbox", badge: tab === "history" ? 0 : unread.length }], tab)}${body}`;
  });
  A.acts["open-post"] = function (el) {
    var p = A.store.postsAll.concat(A.store.postsMine).filter(function (x) { return x.id === el.getAttribute("data-id"); })[0];
    if (!p) return;
    var asg = p.type === "assignment", past = asg && p.dueDate < A.today();
    A.openModal(html`<div class="modal-head"><span class="badge info">${asg ? "Assignment" : "Announcement"}</span><button class="icon-btn" data-act="close-modal" aria-label="Close">${icon("x", 18)}</button></div>
      <h3>${p.title}</h3>
      ${asg ? html`<div class="grid cols-2 mt-2"><div><div class="muted small">Max marks</div><b style="font-size:20px">${p.maxMarks}</b></div><div><div class="muted small">Due date</div><b style="font-size:20px" class="${past ? "text-bad" : "text-good"}">${A.dLong(p.dueDate)}</b></div></div><h4 class="mt-3 mb-1">Description</h4>` : ""}
      <p class="pre-wrap ${asg ? "muted" : "mt-2"}">${p.body}</p>
      <div class="hint-box mt-3"><div><b>Published:</b> ${A.tsLong(p.created)}<br><b>Teacher:</b> ${p.teacherName}<br><b>Scope:</b> ${p.scopeName}</div></div>`, "");
    if (!A.q.seen(p.id)) A.svc.markSeen(p.id);
  };
  A.forms.studentDm = function (f, fd) {
    var t = A.store.teachers.filter(function (x) { return x.id === fd.get("to"); })[0];
    if (!t) throw new Error("Please select a teacher from the list.");
    return A.svc.sendMessage(t.id, t.name, fd.get("message")).then(function () { f.reset(); A.toast("Message sent to " + t.name + "!"); });
  };

  // ------------------------------------------------------------------ comparison & export
  A.route("student/comparison", "student", function () {
    var chart = rows().map(function (r) { return { label: r.d.name, sub: r.d.subject, pct: r.pct, detail: r.present + " / " + r.total + " classes" }; });
    return html`${U.head("Per Division Comparison", "Your attendance percentage in each division. 75% is the minimum requirement.")}${U.bars(chart)}`;
  });
  function allRecords() {
    var uid = A.q.uid(), out = [];
    A.q.divs().forEach(function (d) { var r = A.q.records(d.id, uid); Object.keys(r).forEach(function (x) { out.push({ d: d, date: x, present: r[x] }); }); });
    return out.sort(function (a, b) { return a.date < b.date ? 1 : a.date > b.date ? -1 : A.natCmp(a.d.name, b.d.name); });
  }
  A.route("student/export", "student", function () {
    var recs = allRecords(), p = P(), present = recs.filter(function (r) { return r.present; }).length, pct = A.pct(present, recs.length);
    return html`<div class="page-head no-print"><div><h2>Export my attendance report</h2><p>Download a detailed PDF of all your attendance — handy for submissions.</p></div>
      <div class="flex gap-2 wrap"><button class="btn ghost" data-act="student-csv">${icon("download", 16)} Download CSV</button><button class="btn warn" data-act="print">${icon("printer", 17)} Generate PDF</button></div></div>
      <p class="muted small mb-2 no-print">Tip: in the print dialog choose <b>Save as PDF</b> as the destination.</p>
      <div class="report"><h1>Attendance report</h1>
        <div class="rep-box">${A.avatar(p, 70)}<div><div style="font-size:19px;font-weight:700">${p.name}</div><div style="color:#6b7280">PRN: ${p.prn || "Not set"} · Division: ${p.division || "Not set"}</div></div>
          <div style="margin-left:auto;text-align:right"><div style="color:#6b7280;font-size:12px">Overall attendance</div><div style="font-size:34px;font-weight:800;color:#2563eb">${pct}%</div></div></div>
        <table><thead><tr><th>Division</th><th>Date</th><th>Subject</th><th>Teacher</th><th>Status</th></tr></thead><tbody>${A.each(recs, function (r) {
          return html`<tr><td>${r.d.name}</td><td>${A.dmy(r.date)}</td><td>${r.d.subject}</td><td>${r.d.teacherName}</td><td class="${r.present ? "P" : "A"}">${r.present ? "Present" : "Absent"}</td></tr>`;
        }, html`<tr><td colspan="5" class="D">No attendance records yet.</td></tr>`)}</tbody></table>
        <p style="margin-top:18px;font-size:11.5px;color:#9ca3af;text-align:center">Generated on ${A.tsLong(Date.now())} · Acadance</p></div>`;
  });
  A.acts["student-csv"] = function () {
    var rows2 = [["Date", "Division", "Subject", "Teacher", "Status"]].concat(allRecords().map(function (r) { return [r.date, r.d.name, r.d.subject, r.d.teacherName, r.present ? "Present" : "Absent"]; }));
    A.download("my_attendance.csv", A.csv(rows2));
  };
})();
