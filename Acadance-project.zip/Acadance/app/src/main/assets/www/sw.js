/* Acadance service worker: keeps the app shell available (fast start, installable). Data always comes live from the database. */
const CACHE = "acadance-shell-v3";
const SHELL = ["./", "index.html", "css/app.css", "img/logo.png", "img/icon-192.png",
  "js/config.js", "js/core.js", "js/icons.js", "js/academic.js", "js/backend-firebase.js", "js/backend-local.js", "js/data.js",
  "js/app.js", "js/ui.js", "js/views-student.js", "js/views-teacher.js", "js/views-auth.js", "js/demo.js",
  "vendor/firebase-app-compat.js", "vendor/firebase-auth-compat.js", "vendor/firebase-firestore-compat.js"];

self.addEventListener("install", (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (e) => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== "GET" || url.origin !== self.location.origin) return;
  e.respondWith(caches.open(CACHE).then((cache) => cache.match(req).then((hit) => {
    const fresh = fetch(req).then((res) => { if (res.ok) cache.put(req, res.clone()); return res; }).catch(() => hit);
    return hit || fresh;
  })));
});
