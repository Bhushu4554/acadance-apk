package com.acadance.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_ROUTE = "route";

    /** True while the app is on screen. The background worker stays quiet then (the web layer notifies live). */
    public static volatile boolean foreground = false;

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/www/index.html";

    private WebView web;
    private WebViewAssetLoader loader;
    private ValueCallback<Uri[]> filePathCallback;
    private ActivityResultLauncher<Intent> fileLauncher;
    private ActivityResultLauncher<String> notifPermLauncher;
    private String pendingRoute = null;
    private boolean pageReady = false;
    private long lastBack = 0L;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NotifHelper.createChannels(this);

        loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        fileLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (filePathCallback == null) return;
            Uri[] uris = WebChromeClient.FileChooserParams.parseResult(result.getResultCode(), result.getData());
            filePathCallback.onReceiveValue(uris);
            filePathCallback = null;
        });

        notifPermLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted ->
                js("window.A&&A.native&&A.native.onPermission&&A.native.onPermission(" + (granted ? "true" : "false") + ")"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#04281E"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        // Follow the phone's font size, but cap it so the layout never breaks on very large settings.
        s.setTextZoom(Math.min(s.getTextZoom(), 115));
        s.setUserAgentString(s.getUserAgentString() + " AcadanceApp/3.0");
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, false); // the app has its own dark theme
        }
        WebView.setWebContentsDebuggingEnabled(false);

        // Let the service worker (sw.js) load its files from the same local asset origin.
        ServiceWorkerController.getInstance().setServiceWorkerClient(new ServiceWorkerClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                // window.print() does nothing inside a WebView, so route it to Android's print dialog.
                view.evaluateJavascript("window.print=function(){AndroidBridge.printPage();};", null);
                pageReady = true;
                flushRoute();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try {
                    fileLauncher.launch(params.createIntent());
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (web == null) { finish(); return; }
                // 1) let the web app close sheets, menus and sub-screens first
                web.evaluateJavascript("(function(){try{return !!(window.A&&A.nativeBack&&A.nativeBack());}catch(e){return false;}})()", value -> {
                    if ("true".equals(value)) return;
                    // 2) then normal page history
                    if (web != null && web.canGoBack()) { web.goBack(); return; }
                    // 3) finally "press back again to exit"
                    long now = System.currentTimeMillis();
                    if (now - lastBack < 2000L) {
                        finish();
                    } else {
                        lastBack = now;
                        Toast.makeText(MainActivity.this, R.string.exit_hint, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        handleIntent(getIntent());

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(START_URL);
    }

    // ------------------------------------------------------------------ lifecycle
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        foreground = true;
        NotifHelper.cancelAll(this); // the person is looking at the app, so clear delivered notifications
        js("window.A&&A.native&&A.native.onResume&&A.native.onResume()");
    }

    @Override
    protected void onPause() {
        foreground = false;
        js("window.A&&A.native&&A.native.onPause&&A.native.onPause()");
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null) web.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        foreground = false;
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    // ------------------------------------------------------------------ helpers
    private void handleIntent(Intent i) {
        if (i == null) return;
        String r = i.getStringExtra(EXTRA_ROUTE);
        if (r != null && r.length() > 0) {
            i.removeExtra(EXTRA_ROUTE);
            pendingRoute = r;
            if (pageReady) flushRoute();
        }
    }

    private void flushRoute() {
        if (pendingRoute == null) return;
        String r = pendingRoute;
        pendingRoute = null;
        js("window.A&&A.openRoute&&A.openRoute(" + JSONObject.quote(r) + ")");
    }

    private void js(final String code) {
        if (web == null) return;
        web.post(() -> {
            if (web != null) web.evaluateJavascript(code, null);
        });
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    private void applyBars(String status, String nav, boolean lightIcons) {
        try {
            int sc = Color.parseColor(status);
            int nc = Color.parseColor(nav);
            Window w = getWindow();
            w.setStatusBarColor(sc);
            w.setNavigationBarColor(nc);
            WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
            c.setAppearanceLightStatusBars(!lightIcons);
            c.setAppearanceLightNavigationBars(!lightIcons);
        } catch (Exception ignored) {
            // bad colour string: keep the current bars
        }
    }

    private void openNotificationSettings() {
        try {
            Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {
                // nothing else we can open
            }
        }
    }

    // ------------------------------------------------------------------ JavaScript bridge (window.AndroidBridge)
    private class Bridge {

        /** Called from the web app (js/core.js: A.download). */
        @JavascriptInterface
        public void saveFile(String name, String mime, String base64) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    v.put(MediaStore.Downloads.MIME_TYPE, mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) throw new Exception("Could not create file");
                    try (OutputStream o = getContentResolver().openOutputStream(uri)) { o.write(data); }
                    toast("Saved to Downloads: " + name);
                } else {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    if (dir == null) dir = getFilesDir();
                    dir.mkdirs();
                    File f = new File(dir, name);
                    try (FileOutputStream o = new FileOutputStream(f)) { o.write(data); }
                    toast("Saved: " + f.getAbsolutePath());
                }
            } catch (Exception e) {
                toast("Could not save file: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                try {
                    PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                    pm.print("Acadance", web.createPrintDocumentAdapter("Acadance"), new PrintAttributes.Builder().build());
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Printing is not available", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public String appInfo() {
            try {
                PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
                JSONObject o = new JSONObject();
                o.put("version", pi.versionName);
                long code = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
                o.put("build", code);
                o.put("android", Build.VERSION.RELEASE);
                o.put("device", Build.MANUFACTURER + " " + Build.MODEL);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public boolean isForeground() {
            return foreground;
        }

        // ---- notifications
        @JavascriptInterface
        public String notifStatus() {
            return NotifHelper.canNotify(MainActivity.this) ? "granted" : "denied";
        }

        @JavascriptInterface
        public void requestNotifPermission() {
            runOnUiThread(() -> {
                if (NotifHelper.canNotify(MainActivity.this)) {
                    js("window.A&&A.native&&A.native.onPermission&&A.native.onPermission(true)");
                    return;
                }
                if (Build.VERSION.SDK_INT >= 33
                        && ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
                } else {
                    openNotificationSettings(); // notifications switched off for the app in system settings
                }
            });
        }

        @JavascriptInterface
        public void openNotifSettings() {
            runOnUiThread(() -> openNotificationSettings());
        }

        /**
         * Announces an event. Returns true when a system (pop-up) notification was shown.
         * While the app is open it returns false and the web layer shows its own in-app banner instead.
         */
        @JavascriptInterface
        public boolean showNotification(String id, String type, String title, String text, String route) {
            NotifHelper.claim(MainActivity.this, id);
            if (foreground) return false;
            NotifHelper.show(MainActivity.this, id, NotifHelper.channelFor(type), title, text, route);
            return NotifHelper.canNotify(MainActivity.this);
        }

        /** Always shows a system notification (used by "Send test notification"). */
        @JavascriptInterface
        public boolean showNow(String id, String type, String title, String text, String route) {
            if (!NotifHelper.canNotify(MainActivity.this)) return false;
            NotifHelper.show(MainActivity.this, id + System.currentTimeMillis(), NotifHelper.channelFor(type), title, text, route);
            return true;
        }

        /** Marks an event as already seen so the background check does not repeat it. */
        @JavascriptInterface
        public void claim(String id) {
            NotifHelper.claim(MainActivity.this, id);
        }

        @JavascriptInterface
        public void setSession(String json) {
            try {
                JSONObject o = new JSONObject(json);
                String uid = o.getString("uid");
                SharedPreferences sp = NotifHelper.prefs(MainActivity.this);
                SharedPreferences.Editor ed = sp.edit();
                ed.putString("session", json);
                if (sp.getLong("baseline_" + uid, 0L) == 0L) ed.putLong("baseline_" + uid, System.currentTimeMillis());
                ed.apply();
                if (sp.getBoolean("bg_enabled", true)) PollWorker.schedule(MainActivity.this);
            } catch (Exception ignored) {
                // malformed session: background alerts simply stay off
            }
        }

        @JavascriptInterface
        public void clearSession() {
            try {
                SharedPreferences sp = NotifHelper.prefs(MainActivity.this);
                String raw = sp.getString("session", null);
                SharedPreferences.Editor ed = sp.edit();
                ed.remove("session");
                if (raw != null) {
                    String uid = new JSONObject(raw).optString("uid");
                    if (uid.length() > 0) { ed.remove("baseline_" + uid); ed.remove("primed_" + uid); }
                }
                ed.apply();
            } catch (Exception ignored) {
                // nothing to clear
            }
            PollWorker.cancel(MainActivity.this);
            NotifHelper.cancelAll(MainActivity.this);
        }

        @JavascriptInterface
        public void setPrefs(String json) {
            try {
                JSONObject o = new JSONObject(json);
                boolean bg = o.optBoolean("bg", true);
                SharedPreferences sp = NotifHelper.prefs(MainActivity.this);
                sp.edit().putString("bg_prefs", json).putBoolean("bg_enabled", bg).apply();
                if (!bg) PollWorker.cancel(MainActivity.this);
                else if (sp.contains("session")) PollWorker.schedule(MainActivity.this);
            } catch (Exception ignored) {
                // keep previous preferences
            }
        }

        // ---- look & feel
        @JavascriptInterface
        public void setBars(final String status, final String nav, final boolean lightIcons) {
            runOnUiThread(() -> applyBars(status, nav, lightIcons));
        }
    }
}
