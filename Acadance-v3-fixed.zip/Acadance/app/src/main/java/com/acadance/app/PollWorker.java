package com.acadance.app;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Background check (about every 15 minutes) so notifications also arrive while the app is closed.
 * Works on the free Firebase plan: it signs in with the saved refresh token and reads Firestore over REST.
 * While the app is open, the web layer delivers notifications instantly, so this worker stays quiet.
 */
public class PollWorker extends Worker {

    static final String WORK_PERIODIC = "acadance_poll";
    static final String WORK_NOW = "acadance_poll_now";

    public PollWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        try {
            poll(getApplicationContext());
        } catch (Exception ignored) {
            // network or auth problem: simply try again at the next period
        }
        return Result.success();
    }

    // ------------------------------------------------------------------ scheduling
    public static void schedule(Context ctx) {
        Constraints cons = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        WorkManager wm = WorkManager.getInstance(ctx.getApplicationContext());
        PeriodicWorkRequest periodic = new PeriodicWorkRequest.Builder(PollWorker.class, 15, TimeUnit.MINUTES)
                .setConstraints(cons).build();
        wm.enqueueUniquePeriodicWork(WORK_PERIODIC, ExistingPeriodicWorkPolicy.KEEP, periodic);
        OneTimeWorkRequest now = new OneTimeWorkRequest.Builder(PollWorker.class).setConstraints(cons).build();
        wm.enqueueUniqueWork(WORK_NOW, ExistingWorkPolicy.REPLACE, now);
    }

    public static void cancel(Context ctx) {
        WorkManager wm = WorkManager.getInstance(ctx.getApplicationContext());
        wm.cancelUniqueWork(WORK_PERIODIC);
        wm.cancelUniqueWork(WORK_NOW);
    }

    // ------------------------------------------------------------------ the check
    private static void poll(Context ctx) throws Exception {
        SharedPreferences sp = NotifHelper.prefs(ctx);
        if (!sp.getBoolean("bg_enabled", true)) return;
        String raw = sp.getString("session", null);
        if (raw == null) return;

        JSONObject s = new JSONObject(raw);
        String apiKey = s.getString("apiKey");
        String project = s.getString("projectId");
        String uid = s.getString("uid");
        String role = s.optString("role", "student");
        String refresh = s.getString("refreshToken");

        // 1) trade the saved refresh token for a short-lived ID token
        String tokRes = http("POST",
                "https://securetoken.googleapis.com/v1/token?key=" + URLEncoder.encode(apiKey, "UTF-8"),
                "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(refresh, "UTF-8"),
                null, "application/x-www-form-urlencoded");
        JSONObject tok = new JSONObject(tokRes);
        String idToken = tok.getString("id_token");
        String newRefresh = tok.optString("refresh_token", refresh);
        if (!newRefresh.equals(refresh)) {
            s.put("refreshToken", newRefresh);
            sp.edit().putString("session", s.toString()).apply();
        }

        JSONObject pr = new JSONObject(sp.getString("bg_prefs", "{}"));
        boolean wantPosts = pr.optBoolean("posts", true);
        boolean wantMsg = pr.optBoolean("messages", true);
        boolean wantAcad = pr.optBoolean("academic", true);

        long baseline = sp.getLong("baseline_" + uid, 0L);
        if (baseline == 0L) {
            baseline = System.currentTimeMillis();
            sp.edit().putLong("baseline_" + uid, baseline).apply();
        }
        boolean prime = !sp.getBoolean("primed_" + uid, false);
        if (!prime && MainActivity.foreground) return; // the open app already delivers everything live
        boolean teacher = "teacher".equals(role);

        // 2) messages (both roles)
        if (wantMsg) {
            List<JSONObject> msgs = query(project, idToken, "messages", "toUid", "EQUAL", str(uid));
            for (JSONObject m : msgs) {
                if (m.optBoolean("read", false) || m.optLong("created", 0L) <= baseline) continue;
                String id = m.optString("_id");
                if (!NotifHelper.claim(ctx, id)) continue;
                emit(ctx, id, NotifHelper.CH_MESSAGES,
                        "Message from " + m.optString("fromName", "Acadance"),
                        snip(m.optString("body"), 160),
                        teacher ? "teacher/comm?tab=inbox" : "student/comm?tab=history");
            }
        }

        if (teacher) {
            // 3a) teacher: alerts stored in the feed document (e.g. consecutive absences)
            if (wantAcad) {
                try {
                    String res = http("GET", "https://firestore.googleapis.com/v1/projects/" + project
                            + "/databases/(default)/documents/feed/" + URLEncoder.encode(uid, "UTF-8"), null, idToken, null);
                    JSONObject doc = new JSONObject(res);
                    JSONObject plain = plainMap(doc.optJSONObject("fields"));
                    JSONArray notes = plain.optJSONArray("notifications");
                    if (notes != null) {
                        for (int i = 0; i < notes.length(); i++) {
                            JSONObject n = notes.optJSONObject(i);
                            if (n == null || n.optLong("ts", 0L) <= baseline) continue;
                            String id = "feed:" + n.optString("id");
                            if (!NotifHelper.claim(ctx, id)) continue;
                            emit(ctx, id, NotifHelper.CH_ACADEMIC, n.optString("title", "Acadance alert"),
                                    snip(n.optString("text"), 160), "teacher/home");
                        }
                    }
                } catch (IOException ignored) {
                    // no feed document yet
                }
            }
        } else {
            // 3b) student: announcements & assignments
            if (wantPosts) {
                List<JSONObject> posts = query(project, idToken, "posts", "scope", "EQUAL", str("ALL"));
                posts.addAll(query(project, idToken, "posts", "studentUids", "ARRAY_CONTAINS", str(uid)));
                for (JSONObject p : posts) {
                    if (p.optLong("created", 0L) <= baseline) continue;
                    String id = p.optString("_id");
                    if (!NotifHelper.claim(ctx, id)) continue;
                    boolean asg = "assignment".equals(p.optString("type"));
                    String teacherName = p.optString("teacherName", "Your teacher");
                    String text = asg
                            ? p.optString("title") + " - due " + dmy(p.optString("dueDate")) + " - " + p.optLong("maxMarks", 0L) + " marks (" + teacherName + ")"
                            : p.optString("title") + ": " + snip(p.optString("body"), 130);
                    emit(ctx, id, NotifHelper.CH_POSTS, asg ? "New assignment" : "New announcement", text,
                            "student/comm?tab=" + (asg ? "assignments" : "announcements"));
                }
            }
            // 3c) student: attendance + marks
            if (wantAcad) {
                SharedPreferences.Editor ed = sp.edit();
                List<JSONObject> att = query(project, idToken, "attendance", "studentUid", "EQUAL", str(uid));
                for (JSONObject d : att) {
                    String docId = d.optString("_id");
                    JSONObject rec = d.optJSONObject("records");
                    int total = 0, present = 0;
                    String newest = "";
                    boolean newestVal = false;
                    if (rec != null) {
                        Iterator<String> it = rec.keys();
                        while (it.hasNext()) {
                            String k = it.next();
                            total++;
                            boolean v = rec.optBoolean(k, false);
                            if (v) present++;
                            if (k.compareTo(newest) > 0) { newest = k; newestVal = v; }
                        }
                    }
                    String cur = total + ":" + present;
                    String prev = sp.getString("att_" + docId, null);
                    ed.putString("att_" + docId, cur);
                    if (prime || cur.equals(prev)) continue;
                    int prevTotal = 0;
                    if (prev != null) {
                        try { prevTotal = Integer.parseInt(prev.substring(0, prev.indexOf(':'))); } catch (Exception ignored) { }
                    }
                    String text;
                    if (total > prevTotal) {
                        int added = total - prevTotal;
                        text = added == 1
                                ? "You were marked " + (newestVal ? "present" : "absent") + " on " + dmy(newest) + "."
                                : added + " new attendance entries were added.";
                    } else {
                        text = "Your attendance record was updated.";
                    }
                    if (total > 0) text += " Attendance in this class: " + (Math.round(present * 1000.0 / total) / 10.0) + "%.";
                    String id = "att:" + docId + ":" + total + ":" + present;
                    if (NotifHelper.claim(ctx, id)) {
                        emit(ctx, id, NotifHelper.CH_ACADEMIC, "Attendance updated", text, "student/attendance");
                    }
                }
                List<JSONObject> marks = query(project, idToken, "marks", "studentUid", "EQUAL", str(uid));
                for (JSONObject m : marks) {
                    String docId = m.optString("_id");
                    String sig = val(m, "ut1") + "|" + val(m, "ut2") + "|" + val(m, "finalExam");
                    String prev = sp.getString("mk_" + docId, null);
                    ed.putString("mk_" + docId, sig);
                    if (prime || sig.equals(prev) || "||".equals(sig)) continue;
                    String id = "mk:" + docId + ":" + sig;
                    if (NotifHelper.claim(ctx, id)) {
                        emit(ctx, id, NotifHelper.CH_ACADEMIC, "Marks updated",
                                "New marks were posted in your gradebook.", "student/gradebook");
                    }
                }
                ed.apply();
            }
        }

        if (prime) sp.edit().putBoolean("primed_" + uid, true).apply();
    }

    /** Shows a notification unless the app is open (the web layer shows an in-app banner then). */
    private static void emit(Context ctx, String id, String channel, String title, String text, String route) {
        if (MainActivity.foreground) return;
        NotifHelper.show(ctx, id, channel, title, text, route);
    }

    // ------------------------------------------------------------------ Firestore REST helpers
    private static JSONObject str(String v) throws Exception {
        return new JSONObject().put("stringValue", v);
    }

    private static List<JSONObject> query(String project, String token, String collection, String field, String op, JSONObject value) throws Exception {
        JSONObject filter = new JSONObject()
                .put("field", new JSONObject().put("fieldPath", field))
                .put("op", op)
                .put("value", value);
        JSONObject sq = new JSONObject()
                .put("from", new JSONArray().put(new JSONObject().put("collectionId", collection)))
                .put("where", new JSONObject().put("fieldFilter", filter));
        String res = http("POST", "https://firestore.googleapis.com/v1/projects/" + project
                + "/databases/(default)/documents:runQuery", new JSONObject().put("structuredQuery", sq).toString(), token, "application/json");
        JSONArray arr = new JSONArray(res);
        List<JSONObject> out = new ArrayList<JSONObject>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject row = arr.optJSONObject(i);
            if (row == null) continue;
            JSONObject doc = row.optJSONObject("document");
            if (doc == null) continue;
            JSONObject plain = plainMap(doc.optJSONObject("fields"));
            String name = doc.optString("name");
            plain.put("_id", name.substring(name.lastIndexOf('/') + 1));
            out.add(plain);
        }
        return out;
    }

    private static JSONObject plainMap(JSONObject fields) throws Exception {
        JSONObject out = new JSONObject();
        if (fields == null) return out;
        Iterator<String> it = fields.keys();
        while (it.hasNext()) {
            String k = it.next();
            out.put(k, plainValue(fields.getJSONObject(k)));
        }
        return out;
    }

    private static Object plainValue(JSONObject v) throws Exception {
        if (v.has("stringValue")) return v.getString("stringValue");
        if (v.has("integerValue")) return Long.valueOf(Long.parseLong(v.getString("integerValue")));
        if (v.has("doubleValue")) return Double.valueOf(v.getDouble("doubleValue"));
        if (v.has("booleanValue")) return Boolean.valueOf(v.getBoolean("booleanValue"));
        if (v.has("timestampValue")) return v.getString("timestampValue");
        if (v.has("mapValue")) return plainMap(v.getJSONObject("mapValue").optJSONObject("fields"));
        if (v.has("arrayValue")) {
            JSONArray out = new JSONArray();
            JSONArray vals = v.getJSONObject("arrayValue").optJSONArray("values");
            if (vals != null) {
                for (int i = 0; i < vals.length(); i++) out.put(plainValue(vals.getJSONObject(i)));
            }
            return out;
        }
        return JSONObject.NULL;
    }

    private static String val(JSONObject o, String key) {
        Object v = o.opt(key);
        if (v == null || v == JSONObject.NULL) return "";
        return String.valueOf(v);
    }

    private static String dmy(String d) {
        if (d == null || d.length() < 10) return d == null ? "" : d;
        return d.substring(8, 10) + "-" + d.substring(5, 7) + "-" + d.substring(2, 4);
    }

    private static String snip(String s, int max) {
        if (s == null) return "";
        s = s.trim();
        return s.length() <= max ? s : s.substring(0, max - 1).trim() + "...";
    }

    private static String http(String method, String url, String body, String bearer, String contentType) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod(method);
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setRequestProperty("Accept", "application/json");
            if (bearer != null) c.setRequestProperty("Authorization", "Bearer " + bearer);
            if (body != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", contentType);
                OutputStream o = c.getOutputStream();
                try { o.write(body.getBytes("UTF-8")); } finally { o.close(); }
            }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String text = in == null ? "" : readAll(in);
            if (code >= 400) throw new IOException("HTTP " + code + " " + text);
            return text;
        } finally {
            c.disconnect();
        }
    }

    private static String readAll(InputStream in) throws IOException {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } finally {
            in.close();
        }
    }
}
