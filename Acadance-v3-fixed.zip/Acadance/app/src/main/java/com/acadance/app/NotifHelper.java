package com.acadance.app;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;

/** Creates the notification channels and shows system (pop-up) notifications. */
public final class NotifHelper {

    public static final String CH_POSTS = "acadance_posts";
    public static final String CH_MESSAGES = "acadance_messages";
    public static final String CH_ACADEMIC = "acadance_academic";

    private static final String PREFS = "acadance_native";
    private static final String KEY_NOTIFIED = "notified_ids";
    private static final int MAX_NOTIFIED = 300;

    private NotifHelper() { }

    public static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // ------------------------------------------------------------------ channels
    public static void createChannels(Context c) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        nm.createNotificationChannel(channel(c, CH_POSTS, R.string.ch_posts, R.string.ch_posts_desc));
        nm.createNotificationChannel(channel(c, CH_MESSAGES, R.string.ch_messages, R.string.ch_messages_desc));
        nm.createNotificationChannel(channel(c, CH_ACADEMIC, R.string.ch_academic, R.string.ch_academic_desc));
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private static NotificationChannel channel(Context c, String id, int nameRes, int descRes) {
        NotificationChannel ch = new NotificationChannel(id, c.getString(nameRes), NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription(c.getString(descRes));
        ch.enableVibration(true);
        ch.setShowBadge(true);
        ch.enableLights(true);
        ch.setLightColor(0xFF059669);
        return ch;
    }

    public static String channelFor(String type) {
        if ("message".equals(type)) return CH_MESSAGES;
        if ("attendance".equals(type) || "marks".equals(type) || "alert".equals(type)) return CH_ACADEMIC;
        return CH_POSTS;
    }

    // ------------------------------------------------------------------ permission state
    public static boolean canNotify(Context c) {
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        return NotificationManagerCompat.from(c).areNotificationsEnabled();
    }

    // ------------------------------------------------------------------ de-duplication (JS + background worker)
    /** Remembers that an event was already announced. Returns true if this is the first time. */
    public static synchronized boolean claim(Context c, String id) {
        if (id == null || id.length() == 0) return true;
        SharedPreferences p = prefs(c);
        JSONArray arr;
        try { arr = new JSONArray(p.getString(KEY_NOTIFIED, "[]")); } catch (Exception e) { arr = new JSONArray(); }
        for (int i = 0; i < arr.length(); i++) {
            if (id.equals(arr.optString(i))) return false;
        }
        JSONArray out = new JSONArray();
        int start = Math.max(0, arr.length() - (MAX_NOTIFIED - 1));
        for (int i = start; i < arr.length(); i++) out.put(arr.optString(i));
        out.put(id);
        p.edit().putString(KEY_NOTIFIED, out.toString()).apply();
        return true;
    }

    // ------------------------------------------------------------------ show
    public static void show(Context c, String id, String channel, String title, String text, String route) {
        if (!canNotify(c)) return;
        createChannels(c);

        Intent i = new Intent(c, MainActivity.class);
        i.setAction(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (route != null && route.length() > 0) i.putExtra(MainActivity.EXTRA_ROUTE, route);

        int code = (id == null ? 0 : id.hashCode());
        PendingIntent pi = PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Bitmap large = null;
        try { large = BitmapFactory.decodeResource(c.getResources(), R.drawable.notif_large); } catch (Throwable ignored) { }

        NotificationCompat.Builder b = new NotificationCompat.Builder(c, channel)
                .setSmallIcon(R.drawable.ic_stat_notify)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setColor(0xFF059669)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setCategory(CH_MESSAGES.equals(channel) ? NotificationCompat.CATEGORY_MESSAGE : NotificationCompat.CATEGORY_EVENT)
                .setGroup("acadance_group")
                .setContentIntent(pi);
        if (large != null) b.setLargeIcon(large);

        try {
            NotificationManagerCompat.from(c).notify(code, b.build());
        } catch (SecurityException ignored) {
            // permission revoked between the check and the call
        }
    }

    public static void cancelAll(Context c) {
        try { NotificationManagerCompat.from(c).cancelAll(); } catch (Throwable ignored) { }
    }
}
