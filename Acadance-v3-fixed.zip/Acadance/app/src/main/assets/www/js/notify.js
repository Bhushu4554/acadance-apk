/* Acadance notifications:
   - notices new announcements, assignments, messages, attendance and marks from the live data
   - shows an in-app heads-up banner while the app is open, and an Android system pop-up while it is in the background
   - keeps a notification centre (bell) and the Settings page. The background check while the app is closed lives in PollWorker.java. */
(function () {
  "use strict";
  var A = window.A, html = A.html, icon = A.icon, NB = A.native;
  var N = (A.notify = {});

  // ------------------------------------------------------------------ extra icons used by the new screens
  var X = {
    "settings": '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    "bell-off": '<path d="M13.73 21a2 2 0 0 1-3.46 0"/><path d="M18.63 13A17.89 17.89 0 0 1 18 8"/><path d="M6.26 6.26A5.86 5.86 0 0 0 6 8c0 7-3 9-3 9h14"/><path d="M18 8a6 6 0 0 0-9.33-5"/><line x1="1" y1="1" x2="23" y2="23"/>',
    "smartphone": '<rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/>',
    "shield": '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    "zap": '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
    "monitor": '<rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>',
    "wifi": '<path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/>',
    "hash": '<line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/>',
    "at-sign": '<circle cx="12" cy="12" r="4"/><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-3.92 7.94"/>',
    "check-all": '<polyline points="1 13 5 17 12 8"/><polyline points="9 17 11 19 22 7"/>'
  };
  Object.keys(X).forEach(function (k) { if (!A.ICONS[k]) A.ICONS[k] = X[k]; });

  // ------------------------------------------------------------------ event kinds
  var CAT = { announcement: "posts", assignment: "posts", message: "messages", attendance: "academic", marks: "academic", alert: "academic" };
  var LOOK = { announcement: ["megaphone", "teal"], assignment: ["clipboard", "indigo"], message: ["message", "blue"], attendance: ["calendar", "green"], marks: ["award", "amber"], alert: ["alert", "red"] };
  var DAY = 864e5;

  var st = null, bootAt = 0, started = false, tokenHooked = false;

  // ------------------------------------------------------------------ per-user state (kept on this device)
  function key() { return "acadance-notif-" + A.S.user.uid; }
  function load() {
    try { st = JSON.parse(localStorage.getItem(key())) || {}; } catch (e) { st = {}; }
    st.items = st.items || [];
    st.known = st.known || {};
    st.att = st.att || {};
    st.prefs = st.prefs || {};
    ["posts", "messages", "academic", "bg"].forEach(function (k) { if (st.prefs[k] === undefined) st.prefs[k] = true; });
    st.prevOpen = st.lastOpen || 0;
    st.lastOpen = Date.now();
  }
  function save() {
    if (!st) return;
    var ks = Object.keys(st.known);
    if (ks.length > 700) ks.slice(0, ks.length - 600).forEach(function (k) { delete st.known[k]; });
    try { localStorage.setItem(key(), JSON.stringify(st)); } catch (e) { /* storage full or blocked */ }
  }

  // ------------------------------------------------------------------ start / stop
  N.start = function () {
    if (!A.S.user || !A.S.profile) return;
    if (started && st && st.uid === A.S.user.uid) return;
    load();
    st.uid = A.S.user.uid;
    started = true;
    bootAt = Date.now();
    N.pushPrefs();
    N.pushSession();
    if (A.AUTH.onToken && !tokenHooked) { tokenHooked = true; A.AUTH.onToken(function () { N.pushSession(); }); }
    setTimeout(N.maybePrompt, 3200);
    setTimeout(N.paint, 7200); // refresh once the quiet start-up window is over
  };
  N.stop = function () {
    if (started) NB.clearSession();
    started = false; st = null;
  };
  N.pushSession = function () {
    if (!NB.app || !A.cloud || !A.AUTH.session || !A.S.profile) return;
    var s = A.AUTH.session(), cfg = (window.ACADANCE_CONFIG || {}).firebase || {};
    if (!s || !s.refreshToken) return;
    NB.setSession(JSON.stringify({ apiKey: cfg.apiKey, projectId: cfg.projectId, uid: s.uid, role: A.S.profile.role, refreshToken: s.refreshToken }));
  };
  N.pushPrefs = function () {
    if (!st) return;
    NB.setPrefs(JSON.stringify({ posts: st.prefs.posts, messages: st.prefs.messages, academic: st.prefs.academic, bg: st.prefs.bg }));
  };
  NB.hooks.pause.push(function () { if (st) { st.lastOpen = Date.now(); save(); } });
  NB.hooks.resume.push(function () { if (st) { st.lastOpen = Date.now(); save(); N.paint(); } });

  // ------------------------------------------------------------------ permission
  N.permission = function () {
    var asked = false;
    try { asked = localStorage.getItem("acadance-notif-asked") === "1"; } catch (e) { /* ignore */ }
    if (NB.app) { var s = NB.status(); return s === "granted" ? "granted" : asked ? "denied" : "default"; }
    if (!("Notification" in window)) return "unsupported";
    return Notification.permission;
  };
  N.askPermission = function () {
    try { localStorage.setItem("acadance-notif-asked", "1"); } catch (e) { /* ignore */ }
    if (NB.app) { NB.requestPermission(); return; }
    if (!("Notification" in window)) return;
    try {
      var r = Notification.requestPermission(function (p) { N.afterPermission(p === "granted"); });
      if (r && r.then) r.then(function (p) { N.afterPermission(p === "granted"); });
    } catch (e) { /* old browsers */ }
  };
  N.afterPermission = function (granted) {
    if (granted) A.toast("Notifications are on. You will get a pop-up for new updates.");
    else A.toast("Notifications are off. You can turn them on in your phone's settings.", "warning");
    if (/account\/settings/.test(location.hash) && A.render) A.render(true);
  };
  N.maybePrompt = function () {
    if (!st || !A.S.profile || document.body.classList.contains("auth-body")) return;
    var p = N.permission();
    if (p === "granted" || p === "unsupported" || p === "denied") return;
    if (A.modalOpen()) return;
    var last = 0;
    try { last = +localStorage.getItem("acadance-notif-later") || 0; } catch (e) { /* ignore */ }
    if (Date.now() - last < 3 * DAY) return;
    A.openModal(html`<div class="sheet-hero"><div class="sheet-ico">${icon("bell", 30)}</div></div>
      <h3 class="center">Turn on notifications</h3>
      <p class="muted center mt-1">Get a pop-up as soon as a teacher posts an announcement, assignment or message, or when your attendance and marks are updated.</p>
      <div class="sheet-actions mt-3"><button class="btn block" data-act="notif-enable-close">Allow notifications</button>
      <button class="btn ghost block" data-act="notif-later">Not now</button></div>`, "small sheet");
  };
  A.acts["notif-enable-close"] = function () { A.closeModal(); N.askPermission(); };
  A.acts["notif-later"] = function () { try { localStorage.setItem("acadance-notif-later", String(Date.now())); } catch (e) { /* ignore */ } A.closeModal(); };
  A.acts["notif-enable"] = function () { N.askPermission(); };
  A.acts["notif-system"] = function () { NB.openSettings(); };

  // ------------------------------------------------------------------ collect events from the live store
  function collect() {
    var out = [], role = A.S.profile.role, S = A.store, Q = A.q, now = Date.now();
    S.msgIn.forEach(function (m) {
      if (m.read) return;
      out.push({ id: m.id, type: "message", title: "Message from " + (m.fromName || "Acadance"), text: m.body || "", ts: m.created || now,
        route: role + "/comm?tab=" + (role === "teacher" ? "inbox" : "history") });
    });
    if (role === "teacher") {
      ((A.S.feed && A.S.feed.notifications) || []).forEach(function (n) {
        out.push({ id: "feed:" + n.id, type: "alert", title: n.title || "Alert", text: n.text || "", ts: n.ts || now, route: "teacher/home" });
      });
      return out;
    }
    Q.posts().forEach(function (p) {
      var asg = p.type === "assignment";
      out.push({ id: p.id, type: asg ? "assignment" : "announcement", title: asg ? "New assignment" : "New announcement", ts: p.created || now,
        text: asg ? p.title + " - due " + A.dmy(p.dueDate) + " - " + p.maxMarks + " marks (" + (p.teacherName || "Teacher") + ")" : p.title + ": " + (p.body || ""),
        route: "student/comm?tab=" + (asg ? "assignments" : "announcements") });
    });
    S.attendance.forEach(function (d) {
      var r = d.records || {}, ks = Object.keys(r), total = ks.length, present = ks.filter(function (k) { return r[k]; }).length;
      var prev = st.att[d.id] || { t: 0, p: 0 };
      st.att[d.id] = { t: total, p: present };
      if (prev.t === total && prev.p === present) return;
      var text, added = total - prev.t, newest = ks.sort().pop();
      if (added === 1) text = "You were marked " + (r[newest] ? "present" : "absent") + " on " + A.dmy(newest) + ".";
      else if (added > 1) text = added + " new attendance entries were added.";
      else text = "Your attendance record was updated.";
      if (total) text += " Attendance in this class: " + A.pct(present, total) + "%.";
      var dv = Q.div(d.divisionId);
      out.push({ id: "att:" + d.id + ":" + total + ":" + present, type: "attendance", title: "Attendance updated" + (dv && dv.subject ? " · " + dv.subject : ""),
        text: text, ts: now, route: "student/attendance" });
    });
    S.marks.forEach(function (m) {
      function v(x) { return x === null || x === undefined ? "" : String(x); }
      var sig = v(m.ut1) + "|" + v(m.ut2) + "|" + v(m.finalExam);
      if (sig === "||") return;
      var item = Q.item(m.itemId);
      out.push({ id: "mk:" + m.id + ":" + sig, type: "marks", title: "Marks updated" + (item ? " · " + item.title : ""),
        text: "New marks were posted in your gradebook.", ts: now, route: "student/gradebook" });
    });
    return out;
  }

  function addItem(e) {
    st.items.unshift({ id: e.id, type: e.type, title: e.title, text: e.text, ts: e.ts, route: e.route, read: false });
    st.items = st.items.slice(0, 60);
  }

  N.scan = function () {
    if (!st || !A.S.profile || !A.S.user) return;
    var silent = Date.now() - bootAt < 7000, changed = false;
    collect().forEach(function (e) {
      if (st.known[e.id]) return;
      st.known[e.id] = 1;
      if (silent) {
        // start-up: show what arrived while the app was closed in the centre, without popping anything
        if (st.prevOpen && e.ts > st.prevOpen) { addItem(e); changed = true; NB.claim(e.id); }
        return;
      }
      if (Date.now() - e.ts > 3 * DAY) return; // stale
      addItem(e); changed = true;
      deliver(e);
    });
    save();
    if (changed) N.paint();
  };
  var prevOnData = A.onData;
  A.onData = function () { if (prevOnData) prevOnData(); N.scan(); };

  function deliver(e) {
    if (st.prefs[CAT[e.type]] === false) return;
    var shown = false;
    if (NB.app) shown = NB.show(e.id, e.type, e.title, e.text, e.route || "");
    else if ("Notification" in window && Notification.permission === "granted" && document.hidden) {
      try { new Notification(e.title, { body: e.text, icon: "img/icon-192.png", tag: e.id }); shown = true; } catch (x) { /* ignore */ }
    }
    if (!shown) N.banner(e);
  }

  // ------------------------------------------------------------------ heads-up banner (app open)
  N.banner = function (e) {
    var host = document.getElementById("heads-up");
    if (!host) { host = document.createElement("div"); host.id = "heads-up"; host.setAttribute("aria-live", "assertive"); document.body.appendChild(host); }
    while (host.children.length >= 3) host.removeChild(host.firstChild);
    var look = LOOK[e.type] || LOOK.announcement, el = document.createElement("div");
    el.className = "headsup tone-" + look[1];
    el.setAttribute("role", "alert");
    el.innerHTML = A.str(html`<span class="nt-ico tone-${look[1]}">${icon(look[0], 20)}</span>
      <span class="hu-body"><b>${e.title}</b><span>${e.text}</span></span><span class="hu-time">now</span>`);
    host.appendChild(el);
    requestAnimationFrame(function () { el.classList.add("in"); });
    var timer = setTimeout(close, 6500), y0 = null;
    function close() { clearTimeout(timer); el.classList.remove("in"); setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 320); }
    el.addEventListener("click", function () { close(); N.open(e.id); });
    el.addEventListener("touchstart", function (t) { y0 = t.touches[0].clientY; clearTimeout(timer); }, { passive: true });
    el.addEventListener("touchend", function (t) { if (y0 !== null && y0 - t.changedTouches[0].clientY > 24) close(); else timer = setTimeout(close, 3000); y0 = null; }, { passive: true });
  };

  // ------------------------------------------------------------------ notification centre (bell)
  function find(id) { return st ? st.items.filter(function (i) { return i.id === id; })[0] : null; }
  function ago(ts) {
    var s = (Date.now() - ts) / 1000;
    if (s < 60) return "Just now";
    if (s < 3600) return Math.floor(s / 60) + " min ago";
    if (s < 86400) return Math.floor(s / 3600) + " h ago";
    if (s < 172800) return "Yesterday";
    return A.ts(ts);
  }
  N.unread = function () { return st ? st.items.filter(function (i) { return !i.read; }).length : 0; };
  N.bell = function () {
    var items = st ? st.items : [], unread = N.unread();
    return html`<div class="notif-wrap" id="notif-wrap"><button class="icon-btn" data-act="bell" aria-label="Notifications${unread ? ", " + unread + " unread" : ""}">${icon("bell", 19)}${unread ? html`<span class="count">${unread > 9 ? "9+" : unread}</span>` : ""}</button>
      <div class="notif-panel" id="notif-panel" role="dialog" aria-label="Notifications">
        <div class="notif-head"><b>Notifications</b><span class="nh-actions">${unread ? html`<button class="link-btn small" data-act="notif-readall">Mark all read</button>` : ""}${items.length ? html`<button class="link-btn small" data-act="notif-clear">Clear</button>` : ""}</span></div>
        <div class="notif-list">${A.each(items.slice(0, 30), function (it) {
          var look = LOOK[it.type] || LOOK.announcement;
          return html`<button type="button" class="notif-row ${it.read ? "" : "unread"}" data-act="notif-open" data-id="${it.id}"><span class="nt-ico tone-${look[1]}">${icon(look[0], 18)}</span>
            <span class="nt-body"><b>${it.title}</b><span class="nt-text">${it.text}</span><span class="nt-time">${ago(it.ts)}</span></span>${it.read ? "" : html`<i class="nt-dot"></i>`}</button>`;
        }, html`<div class="notif-empty">${icon("bell-off", 30)}<b>You are all caught up</b><span>Announcements, messages and updates will appear here.</span></div>`)}</div>
        <div class="notif-foot"><a href="${A.link("account/settings")}">${icon("settings", 15)} Notification settings</a></div></div></div>`;
  };
  /** Re-draws just the bell so an open panel is not disturbed by a full page render. */
  N.paint = function () {
    var w = document.getElementById("notif-wrap");
    if (!w || !A.S.profile) return;
    var open = w.querySelector(".notif-panel.show"), tmp = document.createElement("div");
    tmp.innerHTML = A.str(N.bell());
    var n = tmp.firstElementChild;
    if (open) n.querySelector(".notif-panel").classList.add("show");
    w.parentNode.replaceChild(n, w);
  };
  N.open = function (id) {
    var it = find(id);
    if (it) { it.read = true; save(); }
    var p = document.getElementById("notif-panel");
    if (p) p.classList.remove("show");
    N.paint();
    if (it && it.route) A.go(it.route);
  };
  A.acts["notif-open"] = function (el) { N.open(el.getAttribute("data-id")); };
  A.acts["notif-readall"] = function () { if (!st) return; st.items.forEach(function (i) { i.read = true; }); save(); N.paint(); };
  A.acts["notif-clear"] = function () {
    if (!st) return;
    st.items = []; save(); N.paint();
    if (A.S.profile.role === "teacher" && A.S.feed && (A.S.feed.notifications || []).length) return A.svc.clearNotifications();
  };

  // ------------------------------------------------------------------ settings page
  function sw(pref, on) {
    return html`<span class="switch"><input type="checkbox" data-change="pref" data-pref="${pref}" data-nodirty ${on ? "checked" : ""}><i></i></span>`;
  }
  function row(ic, title, sub, ctl, attrs) {
    return html`<div class="set-row" ${attrs || ""}><span class="set-ico">${icon(ic, 19)}</span><span class="set-txt"><b>${title}</b><span>${sub}</span></span><span class="set-ctl">${ctl}</span></div>`;
  }
  function toggleRow(ic, title, sub, pref) {
    return html`<label class="set-row"><span class="set-ico">${icon(ic, 19)}</span><span class="set-txt"><b>${title}</b><span>${sub}</span></span><span class="set-ctl">${sw(pref, st.prefs[pref] !== false)}</span></label>`;
  }
  A.acts.pref = function (el) {
    if (!st) return;
    st.prefs[el.getAttribute("data-pref")] = !!el.checked;
    save(); N.pushPrefs();
  };
  A.acts["theme-set"] = function (el) { A.theme.set(el.getAttribute("data-mode")); };
  A.acts["notif-test"] = function () {
    var e = { id: "test:", type: "announcement", title: "Test notification", text: "Notifications are working on this device.", route: "account/settings" };
    var p = N.permission();
    if (NB.app && p === "granted") { if (NB.showNow(e.id, e.type, e.title, e.text, e.route)) return; }
    else if (!NB.app && "Notification" in window && p === "granted") { try { new Notification(e.title, { body: e.text, icon: "img/icon-192.png" }); return; } catch (x) { /* fall through */ } }
    N.banner(e);
    A.toast("Turn on notifications to receive these as pop-ups outside the app.", "warning");
  };
  A.acts["legal"] = function (el) { A.showLegal(el.getAttribute("data-kind")); };

  A.route("account/settings", null, function () {
    if (!st) { load(); st.uid = A.S.user.uid; }
    var p = A.S.profile, role = p.role, perm = N.permission(), mode = A.theme.mode(), info = NB.info();
    var permCtl = perm === "granted" ? html`<span class="badge good">${icon("check", 12)} On</span>`
      : perm === "unsupported" ? html`<span class="badge">Not supported</span>`
      : perm === "denied" ? (NB.app ? html`<button class="btn sm" data-act="notif-system">Open settings</button>` : html`<span class="badge bad">Blocked</span>`)
      : html`<button class="btn sm" data-act="notif-enable">Turn on</button>`;
    var permSub = perm === "granted" ? "Pop-ups are enabled on this device."
      : perm === "denied" ? (NB.app ? "Notifications are blocked. Open your phone's settings to allow them." : "Blocked in the browser. Allow notifications for this site in its settings.")
      : perm === "unsupported" ? "This browser cannot show notifications." : "Allow pop-ups for new announcements, messages and updates.";
    var seg = function (m, label, ic) { return html`<button type="button" class="seg ${mode === m ? "active" : ""}" data-act="theme-set" data-mode="${m}">${icon(ic, 16)}<span>${label}</span></button>`; };
    var cloudText = A.cloud ? "Live sync is on" : A.cloudWanted ? "Cloud unavailable" : "Device only";
    return html`${A.ui.head("Settings", "Notifications, appearance and app information.")}
      <div class="settings">
        <div class="card set-card"><div class="set-title">${icon("bell", 18)}<h3>Notifications</h3></div>
          ${row("smartphone", "Pop-up notifications", permSub, permCtl)}
          ${role === "student" ? toggleRow("megaphone", "Announcements & assignments", "When a teacher posts something new.", "posts") : ""}
          ${toggleRow("message", "Messages", "Direct messages sent to you.", "messages")}
          ${toggleRow(role === "teacher" ? "alert" : "calendar", role === "teacher" ? "Alerts" : "Attendance & marks", role === "teacher" ? "Consecutive-absence alerts for your students." : "When your attendance or marks are updated.", "academic")}
          ${NB.app && A.cloud ? toggleRow("zap", "Check while the app is closed", "Looks for updates about every 15 minutes in the background.", "bg") : ""}
          <div class="set-actions"><button class="btn ghost sm" data-act="notif-test">${icon("send", 15)} Send test notification</button>${NB.app ? html`<button class="btn ghost sm" data-act="notif-system">${icon("settings", 15)} Sound &amp; vibration</button>` : ""}</div></div>

        <div class="card set-card"><div class="set-title">${icon("monitor", 18)}<h3>Appearance</h3></div>
          <div class="seg-group" role="group" aria-label="Theme">${seg("system", "System", "smartphone")}${seg("light", "Light", "sun")}${seg("dark", "Dark", "moon")}</div>
          <p class="muted small mt-2">System follows your phone's light or dark setting. The layout adjusts automatically to your screen size.</p></div>

        <div class="card set-card"><div class="set-title">${icon("user", 18)}<h3>Account</h3></div>
          <a class="set-row link" href="${A.link(role + "/profile")}"><span class="set-ico">${icon("user", 19)}</span><span class="set-txt"><b>Manage profile</b><span>Name, photo and personal details.</span></span><span class="set-ctl">${icon("chevron-right", 18)}</span></a>
          <a class="set-row link" href="${A.link("account/password")}"><span class="set-ico">${icon("lock", 19)}</span><span class="set-txt"><b>Change password</b><span>Keep your account secure.</span></span><span class="set-ctl">${icon("chevron-right", 18)}</span></a>
          <a class="set-row link" href="${A.link("account/help")}"><span class="set-ico">${icon("help-circle", 19)}</span><span class="set-txt"><b>Help &amp; support</b><span>Contact us or learn how to install the app.</span></span><span class="set-ctl">${icon("chevron-right", 18)}</span></a>
          <div class="set-actions"><button class="btn danger sm" data-act="logout">${icon("log-out", 15)} Sign out</button></div></div>

        <div class="card set-card"><div class="set-title">${icon("info", 18)}<h3>About Acadance</h3></div>
          <dl class="kv">
            <dt>Version</dt><dd>${info && info.version ? info.version : A.version}${info && info.build ? " (build " + info.build + ")" : ""}</dd>
            <dt>Sync</dt><dd>${cloudText}</dd>
            ${info && info.device ? html`<dt>Device</dt><dd>${info.device}, Android ${info.android}</dd>` : ""}
            <dt>Signed in as</dt><dd>${p.name || p.username} (${role})</dd>
          </dl>
          <div class="set-actions"><button class="btn ghost sm" data-act="legal" data-kind="privacy">${icon("shield", 15)} Privacy policy</button><button class="btn ghost sm" data-act="legal" data-kind="terms">${icon("file-text", 15)} Terms of use</button></div>
          <p class="muted small mt-2">Acadance · Smart Student Academic Management System</p></div>
      </div>`;
  });

  // ------------------------------------------------------------------ hook into app start / sign-out
  var prevEnter = A.enterApp;
  A.enterApp = function () { var r = prevEnter ? prevEnter.apply(this, arguments) : undefined; N.start(); return r; };
  var prevAuth = A.showAuth;
  A.showAuth = function () { N.stop(); return prevAuth ? prevAuth.apply(this, arguments) : undefined; };
})();
