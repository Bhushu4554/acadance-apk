/* Firebase backend (free Spark plan): Authentication + Firestore with real-time listeners.
   Exposes the same small interface as backend-local.js so the app code does not care which one is used. */
(function () {
  "use strict";
  var A = window.A;

  A.makeFirebaseBackend = function (cfg) {
    firebase.initializeApp(cfg.firebase);
    var auth = firebase.auth();
    var fs = firebase.firestore();
    try { fs.settings({ experimentalAutoDetectLongPolling: true, ignoreUndefinedProperties: true, merge: true }); } catch (e) { /* already set */ }
    // Keep a local cache and queue writes while offline. Firestore automatically replays
    // the queue and resumes every listener when the phone reconnects.
    fs.enablePersistence({ synchronizeTabs: true }).catch(function (e) {
      console.warn("Offline persistence unavailable", e && e.code);
    });
    var FV = firebase.firestore.FieldValue;
    var DELETE = FV.delete();

    function ref(c, filters) {
      var r = fs.collection(c);
      (filters || []).forEach(function (f) {
        r = r.where(f[0] === "__id__" ? firebase.firestore.FieldPath.documentId() : f[0], f[1], f[2]);
      });
      return r;
    }
    function unwrap(d) { var o = d.data(); o.id = d.id; return o; }

    var DB = {
      DELETE: DELETE,
      newId: function () { return fs.collection("_ids").doc().id; },
      get: function (c, id) { return fs.collection(c).doc(id).get().then(function (d) { return d.exists ? unwrap(d) : null; }); },
      set: function (c, id, data, opts) { return fs.collection(c).doc(id).set(data, opts && opts.merge ? { merge: true } : undefined); },
      create: function (c, id, data) { return fs.collection(c).doc(id).set(data); }, // security rules refuse to overwrite
      update: function (c, id, patch) { return fs.collection(c).doc(id).update(patch); },
      del: function (c, id) { return fs.collection(c).doc(id).delete(); },
      query: function (c, filters) { return ref(c, filters).get().then(function (s) { return s.docs.map(unwrap); }); },
      watch: function (c, filters, cb, onErr) {
        return ref(c, filters).onSnapshot(function (s) { cb(s.docs.map(unwrap)); },
          function (e) { console.error("watch " + c, e); if (onErr) onErr(e); });
      },
      watchDoc: function (c, id, cb, onErr) {
        return fs.collection(c).doc(id).onSnapshot(function (d) { cb(d.exists ? unwrap(d) : null); },
          function (e) { console.error("watchDoc " + c, e); if (onErr) onErr(e); });
      },
      batch: function (ops) {
        var chunks = [];
        for (var i = 0; i < ops.length; i += 400) chunks.push(ops.slice(i, i + 400));
        return chunks.reduce(function (p, chunk) {
          return p.then(function () {
            var b = fs.batch();
            chunk.forEach(function (o) {
              var r = fs.collection(o.c).doc(o.id);
              if (o.op === "delete") b.delete(r);
              else if (o.op === "update") b.update(r, o.data);
              else b.set(r, o.data, o.merge ? { merge: true } : undefined);
            });
            return b.commit();
          });
        }, Promise.resolve());
      }
    };

    function wrap(u) { return u ? { uid: u.uid, email: u.email } : null; }
    var Auth = {
      current: function () { return wrap(auth.currentUser); },
      onChange: function (cb) { return auth.onAuthStateChanged(function (u) { cb(wrap(u)); }); },
      signUp: function (email, pw) { return auth.createUserWithEmailAndPassword(email, pw).then(function (c) { return wrap(c.user); }); },
      signIn: function (email, pw) { return auth.signInWithEmailAndPassword(email, pw).then(function (c) { return wrap(c.user); }); },
      signOut: function () { return auth.signOut(); },
      deleteCurrent: function () { return auth.currentUser ? auth.currentUser.delete() : Promise.resolve(); },
      changePassword: function (oldPw, newPw) {
        var u = auth.currentUser;
        var cred = firebase.auth.EmailAuthProvider.credential(u.email, oldPw);
        return u.reauthenticateWithCredential(cred).then(function () { return u.updatePassword(newPw); });
      },
      session: function () { var u = auth.currentUser; return u ? { uid: u.uid, refreshToken: u.refreshToken } : null; },
      onToken: function (cb) { return auth.onIdTokenChanged(function (u) { if (u) cb(); }); },
      sendReset: function (email) { return auth.sendPasswordResetEmail(email); }
    };
    return { DB: DB, Auth: Auth, cloud: true };
  };
})();
