/* Acadance native layer: Android bridge wrapper, theme (system / light / dark), status-bar colours,
   splash screen, offline bar, back-button handling and the legal pages. Works in the APK and in a browser. */
(function () {
  "use strict";
  var A = (window.A = window.A || {});
  var nb = window.AndroidBridge || null;
  var N = (A.native = { app: !!nb, hooks: { resume: [], pause: [] } });
  A.version = (window.ACADANCE_CONFIG && window.ACADANCE_CONFIG.version) || "3.0";

  document.documentElement.classList.add(nb ? "is-app" : "is-web");
  try { if (window.matchMedia && matchMedia("(display-mode: standalone)").matches) document.documentElement.classList.add("is-standalone"); } catch (e) { /* ignore */ }

  // ------------------------------------------------------------------ safe wrappers (fixed arity: the bridge needs exact arguments)
  N.info = function () { try { return nb ? JSON.parse(nb.appInfo()) : null; } catch (e) { return null; } };
  N.status = function () { try { return nb ? nb.notifStatus() : "unsupported"; } catch (e) { return "unsupported"; } };
  N.requestPermission = function () { try { nb.requestNotifPermission(); } catch (e) { /* ignore */ } };
  N.openSettings = function () { try { nb.openNotifSettings(); } catch (e) { /* ignore */ } };
  N.show = function (id, type, title, text, route) { try { return !!nb.showNotification(id, type, title, text, route || ""); } catch (e) { return false; } };
  N.showNow = function (id, type, title, text, route) { try { return !!nb.showNow(id, type, title, text, route || ""); } catch (e) { return false; } };
  N.claim = function (id) { try { if (nb) nb.claim(id); } catch (e) { /* ignore */ } };
  N.setSession = function (json) { try { if (nb) nb.setSession(json); } catch (e) { /* ignore */ } };
  N.clearSession = function () { try { if (nb) nb.clearSession(); } catch (e) { /* ignore */ } };
  N.setPrefs = function (json) { try { if (nb) nb.setPrefs(json); } catch (e) { /* ignore */ } };
  N.setBars = function (status, nav, light) { try { if (nb) nb.setBars(status, nav, !!light); } catch (e) { /* ignore */ } };

  // lifecycle callbacks (called from MainActivity, and from visibilitychange in a browser)
  function run(list) { list.forEach(function (fn) { try { fn(); } catch (e) { console.error(e); } }); }
  N.onResume = function () { run(N.hooks.resume); };
  N.onPause = function () { run(N.hooks.pause); };
  N.onPermission = function (granted) { if (A.notify && A.notify.afterPermission) A.notify.afterPermission(!!granted); };
  if (!nb) document.addEventListener("visibilitychange", function () { document.hidden ? N.onPause() : N.onResume(); });

  // ------------------------------------------------------------------ theme: system | light | dark
  var T = (A.theme = {});
  T.mode = function () { try { var m = localStorage.getItem("acadance-theme"); return m === "light" || m === "dark" ? m : "system"; } catch (e) { return "system"; } };
  T.resolved = function () {
    var m = T.mode();
    if (m !== "system") return m;
    return window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  };
  T.syncBars = function () {
    var auth = document.body && document.body.classList.contains("auth-body"), dark = T.resolved() === "dark", st, nav, light;
    if (auth) { st = "#04281e"; nav = "#04281e"; light = true; }
    else if (dark) { st = "#0c1f17"; nav = "#06130e"; light = true; }
    else { st = "#ffffff"; nav = "#f4faf7"; light = false; }
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", st);
    N.setBars(st, nav, light);
  };
  T.apply = function () { document.documentElement.setAttribute("data-theme", T.resolved()); T.syncBars(); };
  T.set = function (m) { try { localStorage.setItem("acadance-theme", m); } catch (e) { /* ignore */ } T.apply(); if (A.S && A.S.profile && A.render) A.render(true); };
  T.toggle = function () { T.set(T.resolved() === "dark" ? "light" : "dark"); };
  try {
    var mq = window.matchMedia("(prefers-color-scheme: dark)");
    var onMq = function () { if (T.mode() === "system") { T.apply(); if (A.S && A.S.profile && A.render) A.render(false); } };
    if (mq.addEventListener) mq.addEventListener("change", onMq); else if (mq.addListener) mq.addListener(onMq);
  } catch (e) { /* ignore */ }

  // ------------------------------------------------------------------ greeting
  A.greet = function () {
    var h = new Date().getHours();
    return h < 5 ? "Good night" : h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : h < 21 ? "Good evening" : "Good night";
  };
  A.firstName = function (p) { return String((p && (p.name || p.username)) || "there").trim().split(/\s+/)[0]; };

  // ------------------------------------------------------------------ splash
  A.hideSplash = function () {
    var s = document.getElementById("splash");
    if (!s || s._hiding) return;
    s._hiding = true;
    var wait = Math.max(0, 1000 - (window.performance && performance.now ? performance.now() : 1000));
    setTimeout(function () { s.classList.add("hide"); setTimeout(function () { if (s.parentNode) s.parentNode.removeChild(s); }, 460); }, wait);
  };
  setTimeout(function () { A.hideSplash(); }, 8000); // never trap the person behind the splash

  // ------------------------------------------------------------------ offline / online bar
  var netTimer = null, wasOffline = false;
  function netBar() {
    var el = document.getElementById("net-bar");
    if (!el) { el = document.createElement("div"); el.id = "net-bar"; el.className = "net-bar"; el.setAttribute("role", "status"); document.body.appendChild(el); }
    return el;
  }
  function netUpdate() {
    var el = netBar(), on = navigator.onLine !== false;
    clearTimeout(netTimer);
    if (!on) {
      wasOffline = true;
      el.className = "net-bar off show";
      el.textContent = "You are offline. Saved changes upload when you reconnect.";
    } else if (wasOffline) {
      wasOffline = false;
      el.className = "net-bar on show";
      el.textContent = "Back online. Syncing…";
      netTimer = setTimeout(function () { el.className = "net-bar"; }, 2600);
    }
  }
  window.addEventListener("online", netUpdate);
  window.addEventListener("offline", netUpdate);
  document.addEventListener("DOMContentLoaded", function () { if (navigator.onLine === false) netUpdate(); });

  // ------------------------------------------------------------------ keep the focused field visible above the keyboard
  document.addEventListener("focusin", function (e) {
    var t = e.target;
    if (!t || !/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) || window.innerWidth > 900) return;
    if (t.type === "checkbox" || t.type === "radio" || t.type === "file") return;
    setTimeout(function () { try { t.scrollIntoView({ block: "center", behavior: "smooth" }); } catch (x) { /* ignore */ } }, 320);
  });

  // ------------------------------------------------------------------ back button + notification deep links
  A.nativeBack = function () {
    if (A.modalOpen && A.modalOpen()) { A.closeModal(); return true; }
    var p = document.getElementById("notif-panel");
    if (p && p.classList.contains("show")) { p.classList.remove("show"); return true; }
    if (document.body.classList.contains("sidebar-open")) { document.body.classList.remove("sidebar-open"); return true; }
    if (document.body.classList.contains("auth-body") && A.authBack && A.authBack()) return true;
    return false;
  };
  A.openRoute = function (route) {
    route = String(route || "").replace(/^#?\/?/, "");
    if (!route) return;
    if (A.S && A.S.profile) {
      if (route.split("/")[0] === A.S.profile.role || route.indexOf("account/") === 0) A.go(route);
    } else {
      window.__pendingRoute = route;
    }
  };

  // ------------------------------------------------------------------ legal pages (sign-up, settings)
  var LEGAL = {
    terms: {
      title: "Terms of use",
      body: [
        ["Using Acadance", "Acadance is a study-management tool for students and teachers. Use it only for academic purposes and only with your own account."],
        ["Your account", "Keep your password private. You are responsible for activity on your account. Teacher accounts need an Admin Key issued by your institution."],
        ["Accuracy of records", "Attendance, marks, timetables and announcements are entered by teachers. Acadance shows them as entered and does not replace official institutional records."],
        ["Respectful use", "Do not post unlawful, abusive or misleading content, and do not try to access another person's data or disrupt the service."],
        ["Availability", "We work to keep Acadance available, but it is provided as is, without a guarantee of uninterrupted service. These terms may be updated; continued use means you accept the update."]
      ]
    },
    privacy: {
      title: "Privacy policy",
      body: [
        ["What we store", "Your name, username, mobile number, optional e-mail and PRN, profile picture, and the academic records created for you: attendance, marks, messages, announcements and assignments."],
        ["Where it is stored", "Data is stored in Google Firebase (Authentication and Cloud Firestore) so it can sync across your devices. Access is limited by security rules to the people who need to see it."],
        ["How it is used", "Only to run Acadance: showing your records, sending in-app and phone notifications, and letting teachers manage their divisions. Your data is not sold or used for advertising."],
        ["Notifications", "If you allow notifications, Acadance shows alerts for new announcements, assignments, messages, attendance and marks. You can switch each type off in Settings, or turn notifications off in your phone's settings."],
        ["Your choices", "You can edit your details in Manage Profile and change your password at any time. To remove your account, contact your teacher or administrator through Help & support."]
      ]
    }
  };
  A.showLegal = function (kind) {
    var d = LEGAL[kind] || LEGAL.terms, html = A.html;
    A.openModal(html`<div class="modal-head"><h3>${d.title}</h3><button class="icon-btn" data-act="close-modal" aria-label="Close">${A.icon("x", 18)}</button></div>
      <div class="legal">${d.body.map(function (s) { return html`<h4>${s[0]}</h4><p>${s[1]}</p>`; })}<p class="muted small">Last updated: 30 October 2026</p></div>`, "wide sheet");
  };
  A.acts = A.acts || {};
})();
