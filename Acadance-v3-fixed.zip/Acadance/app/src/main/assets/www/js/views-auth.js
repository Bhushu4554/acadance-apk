/* Sign in, two-step sign-up (student / teacher) and forgot password. */
(function () {
  "use strict";
  var A = window.A, html = A.html, icon = A.icon;
  var REMEMBER = "acadance-remember";

  var CRIT = html`<div class="crit-grid"><div class="crit" data-crit="length">8+ characters</div><div class="crit" data-crit="case">Upper &amp; lowercase</div><div class="crit" data-crit="number">A number</div><div class="crit" data-crit="special">A special character</div></div>
    <div class="strength"><div></div></div><div class="strength-text"></div>`;
  var CAPTCHA = html`<div class="flabel">Security check</div>
    <div class="captcha" data-captcha><input type="hidden" name="captcha_ok" value="0"><div class="hint">Slide the key to the lock</div>
      <div class="key">${icon("key", 22)}</div><div class="lock">${icon("lock", 22)}</div><div class="done">${icon("shield-check", 24)} Verified</div></div>`;

  function field(label, ic, input, extra) {
    return html`<div class="field-block"><label class="flabel">${label}</label><div class="input-icon">${icon(ic, 18)}${input}</div>${extra || ""}</div>`;
  }
  function passField(label, name, ph, auto, extra) {
    return html`<div class="field-block"><label class="flabel">${label}</label><div class="input-icon has-toggle">${icon("lock", 18)}<input class="input" type="password" name="${name}" placeholder="${ph}" required autocomplete="${auto}">
      <button type="button" class="toggle-pass" data-act="toggle-pass" aria-label="Show password">${icon("eye", 18)}</button></div>${extra || ""}</div>`;
  }
  function terms() {
    return html`<label class="check"><input type="checkbox" name="terms" required><span class="box">${icon("check", 13)}</span>
      <span>I agree to the <button type="button" class="link-btn" data-act="legal" data-kind="terms">Terms</button> and <button type="button" class="link-btn" data-act="legal" data-kind="privacy">Privacy Policy</button></span></label>`;
  }
  function steps(a, b) {
    return html`<div class="steps"><div class="steps-bar"><i></i></div><span class="steps-text" data-s1="${a}" data-s2="${b}">Step 1 of 2 · ${a}</span></div>`;
  }
  function back(to) { return html`<button type="button" class="back-btn" data-goto="${to}">${icon("arrow-left", 18)} Back</button>`; }
  function errBox() { return html`<div class="form-error" role="alert" hidden></div>`; }

  A.renderAuth = function () {
    var banner = A.cloudFailed ? html`<div class="hint-box bad mb-2">${icon("alert", 18)}<div class="grow"><b>Cloud unavailable.</b> Check your connection. Your account has not been switched to demo data.<button class="link-btn small" data-act="reload-cloud" style="display:block;margin-top:5px">Try again</button></div></div>`
      : !A.cloud ? html`<div class="hint-box warn mb-2">${icon("info", 18)}<div><b>Device-only demo.</b> Data stays on this phone. A Firebase configuration is required for live sharing.</div></div>` : "";
    var demoBox = !A.cloud && !A.cloudWanted ? html`<div class="demo-box"><button class="btn ghost sm" type="button" data-act="seed">Load sample data</button>
      <div class="mt-1">Creates teacher <b>teacher</b> / <b>Teacher@123</b> and students <b>aarav</b>, <b>diya</b>, <b>sana</b>… / <b>Student@123</b>.</div></div>` : "";
    var remembered = ""; try { remembered = localStorage.getItem(REMEMBER) || ""; } catch (e) { /* ignore */ }

    var page = html`
    <div class="auth-bg" aria-hidden="true"><i></i><i></i><i></i></div>
    <div class="auth-shell">
      <section class="auth-art">
        <div class="panel" id="panel-login"><div class="brandline"><img src="img/logo.png" alt=""><span>Acadance</span></div>
          <h1>One place for every class, mark and message.</h1>
          <p class="lead">A secure academic portal for students and teachers, always in sync across all your devices.</p>
          <div class="feature-list">
            <div class="f"><div class="fi">${icon("calendar", 19)}</div><div><b>Smart attendance</b><span>Daily sheets, 75% tracking and instant alerts.</span></div></div>
            <div class="f"><div class="fi">${icon("award", 19)}</div><div><b>Gradebook</b><span>Unit tests and finals with automatic pass rules.</span></div></div>
            <div class="f"><div class="fi">${icon("bell", 19)}</div><div><b>Instant notifications</b><span>Pop-ups for announcements, assignments and messages.</span></div></div></div>
          <div class="art-badges"><span>${icon("shield-check", 15)} Secure sign-in</span><span>${icon("zap", 15)} Live sync</span><span>${icon("smartphone", 15)} Works on any screen</span></div></div>
        <div class="panel" id="panel-choice"><div class="art-ico">${icon("users", 42)}</div><h2>Create your account</h2><p class="lead">Join Acadance as a student or as a teacher in under a minute.</p></div>
        <div class="panel" id="panel-student"><div class="art-ico">${icon("graduation", 42)}</div><h2>Student registration</h2><p class="lead">Track your attendance, grades, timetable and announcements in one place.</p></div>
        <div class="panel" id="panel-teacher"><div class="art-ico">${icon("user-plus", 42)}</div><h2>Teacher registration</h2><p class="lead">Manage divisions, take attendance, grade students and keep everyone informed.</p></div>
        <div class="panel" id="panel-forgot"><div class="art-ico">${icon("key", 42)}</div><h2>Forgot your password?</h2><p class="lead">We will e-mail you a link to choose a new one.</p></div>
      </section>
      <section class="auth-form-side">
        <div class="auth-hero"><div class="hero-tile"><img src="img/logo.png" alt=""></div><div class="hero-name">Acadance</div><div class="hero-tag">Smart Student Academic Management</div></div>
        <div class="auth-card">
          ${banner}
          <div class="auth-view" id="view-login"><h2>Welcome back</h2><p class="lead">Sign in to continue to your dashboard.</p>
            ${errBox()}
            <form class="auth-form" data-form="login">
              <div class="field-block"><label class="flabel">Username or PRN</label><div class="input-icon">${icon("user", 18)}<input class="input" name="username" value="${remembered}" placeholder="Your username or PRN" required autocomplete="username" autocapitalize="none" autocorrect="off" spellcheck="false" enterkeyhint="next"></div></div>
              ${passField("Password", "password", "Enter your password", "current-password", html`<div class="caps-warn" hidden>${icon("alert", 14)} Caps Lock is on</div>`)}
              <div class="row-between"><label class="check"><input type="checkbox" name="remember" ${remembered ? "checked" : ""}><span class="box">${icon("check", 13)}</span><span>Remember me</span></label>
                <button type="button" class="link-btn" data-goto="forgot">Forgot password?</button></div>
              <button class="btn block lg" type="submit"><span>Sign in</span></button></form>
            <div class="or-sep"><span>New to Acadance?</span></div>
            <button class="btn ghost block" type="button" data-goto="choice">${icon("user-plus", 18)} Create an account</button>${demoBox}</div>

          <div class="auth-view" id="view-choice">${back("login")}<h2>Create your account</h2><p class="lead">Choose how you will use Acadance.</p>
            <div class="role-grid">
              <button class="role-card" type="button" data-goto="student"><span class="rc-ico">${icon("graduation", 26)}</span><span class="rc-txt"><b>I am a student</b><span>Attendance, marks, timetable and announcements.</span></span>${icon("chevron-right", 18)}</button>
              <button class="role-card teal" type="button" data-goto="teacher"><span class="rc-ico">${icon("users", 26)}</span><span class="rc-txt"><b>I am a teacher</b><span>Manage divisions, attendance and grades. Needs an Admin Key.</span></span>${icon("chevron-right", 18)}</button></div></div>

          <div class="auth-view" id="view-student">${back("choice")}<h2>Student registration</h2>${steps("Your details", "Secure your account")}${errBox()}
            <form class="auth-form" data-form="signupStudent" data-wizard>
              <div class="auth-step active" data-step="1">
                ${field("Full name", "user", html`<input class="input" name="name" placeholder="As on your ID card" required autocomplete="name" minlength="2" enterkeyhint="next">`)}
                ${field("Username", "at-sign", html`<input class="input" name="username" placeholder="Choose a username" required autocomplete="username" autocapitalize="none" autocorrect="off" spellcheck="false" minlength="3" data-avail enterkeyhint="next">`, html`<div class="hint-line" data-avail-hint></div>`)}
                ${field("Mobile number", "phone", html`<input class="input" type="tel" inputmode="tel" name="mobile" placeholder="10-digit mobile number" required autocomplete="tel" pattern="[0-9+ \\-]{10,15}" enterkeyhint="next">`)}
                ${field("PRN (optional)", "hash", html`<input class="input" name="prn" inputmode="numeric" placeholder="Your PRN" autocomplete="off" maxlength="20" enterkeyhint="next">`, html`<div class="hint-line">Your teacher uses your PRN to add you to a division.</div>`)}
                ${field("E-mail (optional)", "mail", html`<input class="input" type="email" name="email" placeholder="you@example.com" autocomplete="email" enterkeyhint="next">`, html`<div class="hint-line">Only used to reset your password.</div>`)}
                <button type="button" class="btn block lg" data-act="step-next"><span>Continue</span>${icon("chevron-right", 18)}</button></div>
              <div class="auth-step" data-step="2">
                <div data-pw-block>${passField("Password", "password", "Create a password", "new-password")}${CRIT}</div>
                ${passField("Confirm password", "confirm", "Re-enter your password", "new-password", html`<div class="hint-line" data-match></div>`)}
                ${CAPTCHA}${terms()}
                <div class="two-btns"><button type="button" class="btn ghost" data-act="step-back">${icon("arrow-left", 17)} Back</button><button class="btn success lg grow" type="submit"><span>Create account</span></button></div></div>
            </form>
            <p class="auth-switch">Already have an account? <button type="button" class="link-btn" data-goto="login">Sign in</button></p></div>

          <div class="auth-view" id="view-teacher">${back("choice")}<h2>Teacher registration</h2>${steps("Your details", "Secure your account")}${errBox()}
            <form class="auth-form" data-form="signupTeacher" data-wizard>
              <div class="auth-step active" data-step="1">
                ${field("Full name", "user", html`<input class="input" name="name" placeholder="Your full name" required autocomplete="name" minlength="2" enterkeyhint="next">`)}
                ${field("Username", "at-sign", html`<input class="input" name="username" placeholder="Choose a username" required autocomplete="username" autocapitalize="none" autocorrect="off" spellcheck="false" minlength="3" data-avail enterkeyhint="next">`, html`<div class="hint-line" data-avail-hint></div>`)}
                ${field("E-mail (optional)", "mail", html`<input class="input" type="email" name="email" placeholder="you@example.com" autocomplete="email" enterkeyhint="next">`, html`<div class="hint-line">Only used to reset your password.</div>`)}
                <button type="button" class="btn block lg" data-act="step-next"><span>Continue</span>${icon("chevron-right", 18)}</button></div>
              <div class="auth-step" data-step="2">
                <div data-pw-block>${passField("Password", "password", "Create a password", "new-password")}${CRIT}</div>
                ${passField("Confirm password", "confirm", "Re-enter your password", "new-password", html`<div class="hint-line" data-match></div>`)}
                ${field("Admin key", "key", html`<input class="input" type="password" name="adminKey" placeholder="Issued by your institution" required autocomplete="off">`)}
                ${CAPTCHA}${terms()}
                <div class="two-btns"><button type="button" class="btn ghost" data-act="step-back">${icon("arrow-left", 17)} Back</button><button class="btn purple lg grow" type="submit"><span>Create account</span></button></div></div>
            </form>
            <p class="auth-switch">Already have an account? <button type="button" class="link-btn" data-goto="login">Sign in</button></p></div>

          <div class="auth-view" id="view-forgot">${back("login")}<h2>Reset password</h2><p class="lead">Enter your username or PRN. If your account has an e-mail, we send a reset link.</p>${errBox()}
            <form class="auth-form" data-form="forgot">
              ${field("Username or PRN", "user", html`<input class="input" name="username" placeholder="Your username or PRN" required autocapitalize="none" autocorrect="off" spellcheck="false">`)}
              <button class="btn block lg" type="submit"><span>Send reset link</span></button></form></div>

          <p class="auth-legal"><button type="button" class="link-btn" data-act="legal" data-kind="privacy">Privacy</button><i></i><button type="button" class="link-btn" data-act="legal" data-kind="terms">Terms</button><i></i><span>v${A.version}</span></p>
        </div></section>
    </div>`;
    document.getElementById("app").innerHTML = A.str(page);
    initAuth();
  };

  // ------------------------------------------------------------------ behaviour
  function strongEnough(pw) { return pw.replace(/\s/g, "").length >= 8 && /[a-z]/.test(pw) && /[A-Z]/.test(pw) && /\d/.test(pw) && /[^a-zA-Z\d\s]/.test(pw); }
  function activeView() { var v = document.querySelector(".auth-view.active"); return v ? v.id.replace("view-", "") : "login"; }
  function showView(name) {
    document.querySelectorAll(".auth-view").forEach(function (v) { v.classList.toggle("active", v.id === "view-" + name); });
    document.querySelectorAll(".auth-art .panel").forEach(function (p) { p.classList.toggle("active", p.id === "panel-" + name); });
    document.querySelectorAll("[data-captcha]").forEach(function (c) { if (c._reset) c._reset(); });
    document.querySelectorAll(".form-error").forEach(function (b) { b.hidden = true; });
    var card = document.querySelector(".auth-card"); if (card) card.scrollTop = 0;
    window.scrollTo(0, 0);
  }
  function setStep(form, n) {
    form.querySelectorAll(".auth-step").forEach(function (s) { s.classList.toggle("active", +s.getAttribute("data-step") === n); });
    var view = form.closest(".auth-view"), txt = view.querySelector(".steps-text"), bar = view.querySelector(".steps-bar > i");
    txt.textContent = "Step " + n + " of 2 · " + txt.getAttribute("data-s" + n);
    bar.style.width = n === 1 ? "50%" : "100%";
    var f = form.querySelector(".auth-step.active input:not([type=hidden]):not([type=checkbox])");
    if (f && window.innerWidth > 900) f.focus();
    window.scrollTo(0, 0);
  }
  A.authBack = function () {
    var v = activeView();
    if (v === "login") return false;
    var form = document.querySelector("#view-" + v + " form[data-wizard]");
    if (form && form.querySelector('.auth-step[data-step="2"].active')) { setStep(form, 1); return true; }
    showView(v === "student" || v === "teacher" ? "choice" : "login");
    return true;
  };
  function showErr(form, e) {
    var box = form.closest(".auth-view").querySelector(".form-error");
    if (box) {
      box.hidden = false;
      box.innerHTML = A.str(icon("alert", 17)) + "<span>" + A.esc(A.errMsg(e)) + "</span>";
      box.classList.remove("shake"); void box.offsetWidth; box.classList.add("shake");
    }
    e.handled = true;
    return e;
  }
  var attempts = 0;

  A.acts["step-next"] = function (el) {
    var form = el.closest("form"), step = el.closest(".auth-step"), ok = true;
    var u = form.elements.username;
    if (/\s/.test(u.value)) u.setCustomValidity("Username cannot contain spaces."); else if (u.validationMessage === "Username cannot contain spaces.") u.setCustomValidity("");
    step.querySelectorAll("input").forEach(function (i) { if (ok && !i.checkValidity()) { i.reportValidity(); ok = false; } });
    if (ok) setStep(form, 2);
  };
  A.acts["step-back"] = function (el) { setStep(el.closest("form"), 1); };
  A.acts["toggle-pass"] = function (el) {
    var input = el.parentElement.querySelector("input"), show = input.type === "password";
    input.type = show ? "text" : "password";
    el.innerHTML = A.str(icon(show ? "eye-off" : "eye", 18));
    el.setAttribute("aria-label", show ? "Hide password" : "Show password");
  };

  var bound = false;
  function initAuth() {
    if (!bound) {
      bound = true;
      document.addEventListener("click", function (e) {
        var g = e.target.closest && e.target.closest("[data-goto]");
        if (g && document.body.classList.contains("auth-body")) { e.preventDefault(); showView(g.getAttribute("data-goto")); }
      });
      document.addEventListener("keydown", function (e) {
        if (!document.body.classList.contains("auth-body")) return;
        if (e.key === "Enter" && e.target.tagName === "INPUT") {
          var step = e.target.closest('.auth-step[data-step="1"]');
          if (step) { e.preventDefault(); var b = step.querySelector('[data-act="step-next"]'); if (b) b.click(); }
        }
        if (e.target.type === "password" && e.getModifierState) {
          var fb = e.target.closest(".field-block"), w = fb && fb.querySelector(".caps-warn"); if (w) w.hidden = !e.getModifierState("CapsLock");
        }
      });
      document.addEventListener("input", function (e) {
        if (!document.body.classList.contains("auth-body")) return;
        var v = e.target.closest && e.target.closest(".auth-view"), er = v && v.querySelector(".form-error"); if (er) er.hidden = true;
      });
    }
    // password strength + confirm match
    document.querySelectorAll("[data-pw-block]").forEach(function (block) {
      var input = block.querySelector("input"), bar = block.querySelector(".strength > div"), text = block.querySelector(".strength-text");
      var form = block.closest("form"), lv = [["0%", "transparent", ""], ["25%", "#ef4444", "Weak"], ["50%", "#f59e0b", "Medium"], ["75%", "#10b981", "Good"], ["100%", "#22c55e", "Strong"]];
      function match() {
        var c = form.elements.confirm, h = form.querySelector("[data-match]");
        if (!c || !h) return;
        if (!c.value) { h.textContent = ""; h.className = "hint-line"; return; }
        var ok = c.value === input.value;
        h.textContent = ok ? "Passwords match" : "Passwords do not match yet";
        h.className = "hint-line " + (ok ? "good" : "bad");
      }
      input.addEventListener("input", function () {
        var v = input.value, ck = { length: v.replace(/\s/g, "").length >= 8, case: /[a-z]/.test(v) && /[A-Z]/.test(v), number: /\d/.test(v), special: /[^a-zA-Z\d\s]/.test(v) }, s = 0;
        Object.keys(ck).forEach(function (k) { if (ck[k]) s++; var el = block.querySelector('[data-crit="' + k + '"]'); if (el) el.classList.toggle("ok", ck[k]); });
        var l = lv[v ? s : 0]; bar.style.width = l[0]; bar.style.background = l[1]; text.textContent = l[2];
        match();
      });
      if (form.elements.confirm) form.elements.confirm.addEventListener("input", match);
    });
    // live username availability
    document.querySelectorAll("input[data-avail]").forEach(function (input) {
      var hint = input.closest(".field-block").querySelector("[data-avail-hint]"), timer = null;
      input.addEventListener("input", function () {
        clearTimeout(timer);
        input.setCustomValidity("");
        var v = input.value.trim();
        hint.className = "hint-line";
        if (!v) { hint.textContent = ""; return; }
        if (!/^[A-Za-z0-9._-]+$/.test(v)) { hint.className += " bad"; hint.textContent = "Use letters, numbers, dot, dash or underscore only."; input.setCustomValidity("Use letters, numbers, dot, dash or underscore only."); return; }
        if (v.length < 3) { hint.textContent = "At least 3 characters."; return; }
        hint.textContent = "Checking…";
        timer = setTimeout(function () {
          A.DB.get("logins", "u_" + v.toLowerCase()).then(function (x) {
            if (input.value.trim() !== v) return;
            hint.className = "hint-line " + (x ? "bad" : "good");
            hint.textContent = x ? "That username is already taken." : "Username is available.";
            input.setCustomValidity(x ? "That username is already taken." : "");
          }, function () { hint.textContent = ""; });
        }, 450);
      });
    });
    // slide-to-verify
    document.querySelectorAll("[data-captcha]").forEach(function (box) {
      var key = box.querySelector(".key"), lock = box.querySelector(".lock"), flag = box.querySelector("input[name=captcha_ok]"), drag = false, sx = 0, sl = 4;
      function maxLeft() { return box.clientWidth - key.offsetWidth - 4; }
      box._reset = function () { box.classList.remove("verified"); flag.value = "0"; key.style.left = "4px"; };
      key.addEventListener("pointerdown", function (e) { if (box.classList.contains("verified")) return; drag = true; key.classList.add("dragging"); sx = e.clientX; sl = key.offsetLeft; key.setPointerCapture(e.pointerId); e.preventDefault(); });
      key.addEventListener("pointermove", function (e) { if (drag) key.style.left = Math.min(maxLeft(), Math.max(4, sl + e.clientX - sx)) + "px"; });
      function end() {
        if (!drag) return; drag = false; key.classList.remove("dragging");
        if (key.offsetLeft + key.offsetWidth >= lock.offsetLeft + 6) { box.classList.add("verified"); flag.value = "1"; }
        else { key.style.left = "4px"; A.toast("Slide the key all the way to the lock.", "error"); }
      }
      key.addEventListener("pointerup", end); key.addEventListener("pointercancel", end);
    });
    showView("login");
  }

  // ------------------------------------------------------------------ forms
  function requireCloud() {
    if (A.cloudFailed) throw new Error("Cloud services are unavailable. Reconnect and tap Try again; no device-only account was created.");
  }
  function validateSignup(fd) {
    var pw = fd.get("password");
    if (/\s/.test(fd.get("username"))) throw new Error("Username cannot contain spaces.");
    if (/\s/.test(pw)) throw new Error("Spaces are not allowed in the password.");
    if (!strongEnough(pw)) throw new Error("Please use a strong password that meets all criteria.");
    if (pw !== fd.get("confirm")) throw new Error("The two passwords do not match.");
    if (fd.get("captcha_ok") !== "1") throw new Error("Please slide the key to the lock to verify.");
  }
  function guard(f, fn) {
    try { return Promise.resolve(fn()).catch(function (e) { throw showErr(f, e); }); }
    catch (e) { throw showErr(f, e); }
  }
  A.forms.login = function (f, fd) {
    return guard(f, function () {
      requireCloud();
      return A.svc.login(fd.get("username"), fd.get("password")).then(function () {
        try { if (fd.get("remember")) localStorage.setItem(REMEMBER, fd.get("username").trim()); else localStorage.removeItem(REMEMBER); } catch (e) { /* ignore */ }
        A.toast("Signed in. Welcome back!");
      }, function (e) {
        attempts++;
        if (attempts >= 3 && /invalid username or password/i.test(A.errMsg(e))) e.message = "Invalid username or password. Forgot it? Use \u201cForgot password?\u201d below the password field.";
        throw e;
      });
    });
  };
  A.forms.signupStudent = function (f, fd) {
    return guard(f, function () {
      requireCloud(); validateSignup(fd);
      var prn = (fd.get("prn") || "").trim();
      return A.svc.register("student", { name: fd.get("name"), username: fd.get("username"), mobile: fd.get("mobile"), email: fd.get("email"), password: fd.get("password") })
        .then(function () { return prn ? A.svc.saveProfile({ prn: prn }).catch(function (e) { A.toast(A.errMsg(e), "error"); }) : null; })
        .then(function () { A.toast("Account created. Welcome to Acadance!"); });
    });
  };
  A.forms.signupTeacher = function (f, fd) {
    return guard(f, function () {
      requireCloud(); validateSignup(fd);
      return A.svc.register("teacher", { name: fd.get("name"), username: fd.get("username"), email: fd.get("email"), password: fd.get("password"), adminKey: fd.get("adminKey") })
        .then(function () { A.toast("Teacher account created. Welcome to Acadance!"); });
    });
  };
  A.forms.forgot = function (f, fd) {
    return guard(f, function () {
      requireCloud();
      return A.svc.forgot(fd.get("username")).then(function (masked) { A.toast("Reset link sent to " + masked + ". Check your inbox."); showView("login"); });
    });
  };
})();
