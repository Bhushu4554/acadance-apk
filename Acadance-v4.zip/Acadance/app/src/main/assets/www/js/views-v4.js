/* Acadance 4 - upgraded screens. Re-registers or wraps existing routes so the original files stay untouched.
   Adds: ring dashboards, next-class card, attendance calendar + "what if" planner, grade targets,
   day-by-day timetable for phones, search + mark-all-seen, comparison summary, division overview, FAQ. */
(function () {
  "use strict";
  var A = window.A, html = A.html, icon = A.icon, U = A.ui;
  function P() { return A.S.profile; }

  // ---- route helpers
  function find(pattern) { for (var i = 0; i < A.routes.length; i++) if (A.routes[i].parts.join("/") === pattern) return A.routes[i]; return null; }
  function replace(pattern, fn) { var r = find(pattern); if (r) r.fn = fn; }
  function wrap(pattern, fn) { var r = find(pattern); if (!r) return; var o = r.fn; r.fn = function (ctx) { return fn(o, ctx); }; }

  // ---- shared student data helpers (same rules as views-student.js)
  function rows() {
    var uid = A.q.uid();
    return A.q.divs().map(function (d) {
      var r = A.q.records(d.id, uid), dates = Object.keys(r), present = dates.filter(function (x) { return r[x]; }).length;
      return { d: d, total: dates.length, present: present, absent: dates.length - present, pct: A.pct(present, dates.length), advice: A.advice(present, dates.length) };
    }).filter(function (r) { return r.total > 0; });
  }
  function overall(rs) { var t = 0, p = 0; rs.forEach(function (r) { t += r.total; p += r.present; }); return { total: t, present: p, absent: t - p, pct: A.pct(p, t), advice: A.advice(p, t) }; }
  function myTimetable() {
    var tts = A.store.timetables, name = (P().division || "").toLowerCase();
    return tts.filter(function (t) { return (t.divisionName || "").toLowerCase() === name; })[0] || tts[0] || null;
  }
  function mins(hhmm) { var x = (hhmm || "0:0").split(":").map(Number); return x[0] * 60 + x[1]; }
  function nextClass(tt) {
    var list = A.todays(tt).filter(function (l) { return !l.isBreak; }), now = mins(A.nowHM());
    for (var i = 0; i < list.length; i++) {
      var l = list[i];
      if (l.isNow) return { now: true, l: l, left: mins(l.slot.end) - now };
      if (mins(l.slot.start) > now) return { now: false, l: l, left: mins(l.slot.start) - now };
    }
    return null;
  }
  function human(m) { return m >= 60 ? Math.floor(m / 60) + " h " + (m % 60 ? (m % 60) + " min" : "") : m + " min"; }
  function dueChip(dateStr) {
    var d = Math.round((A.parseD(dateStr) - A.parseD(A.today())) / 86400000);
    if (d < 0) return html`<span class="due late">${icon("alert", 12)} Past due</span>`;
    if (d === 0) return html`<span class="due soon">${icon("clock", 12)} Due today</span>`;
    if (d === 1) return html`<span class="due soon">${icon("clock", 12)} Due tomorrow</span>`;
    return html`<span class="due ${d <= 3 ? "soon" : ""}">${icon("calendar", 12)} ${A.dShort(dateStr)} · ${d} days</span>`;
  }
  function unreadCounts() {
    var posts = A.q.posts(), unseen = posts.filter(function (p) { return !A.q.seen(p.id); }).length;
    return { posts: unseen, msgs: A.q.unread().length };
  }

  // ================================================================== STUDENT HOME
  replace("student/home", function () {
    var rs = rows(), ov = overall(rs), p = P(), tt = myTimetable(), today = A.todays(tt), today0 = A.today(), nc = nextClass(tt), uc = unreadCounts();
    var atRisk = rs.filter(function (r) { return r.pct < 75; }), classesToday = today.filter(function (l) { return !l.isBreak; }).length;
    var items = A.store.gradeItems.map(function (it) { return A.grade(A.q.mark(it.id, A.q.uid()), it.finalMax); });
    var passed = items.filter(function (g) { return g.overall === "PASSED"; }).length, pending = items.filter(function (g) { return g.overall === "PENDING"; }).length;
    var upcoming = A.q.posts().filter(function (x) { return x.type === "assignment" && x.dueDate >= today0; }).sort(function (a, b) { return a.dueDate < b.dueDate ? -1 : 1; }).slice(0, 4);
    var latest = A.q.posts().filter(function (x) { return x.type === "announcement"; })[0];
    var lead = ov.total ? ov.advice.text : (p.prn ? "Your attendance will appear here as soon as your teacher records your first class." : "Add your PRN in your profile so your teacher can enrol you in a division.");
    return html`
    <div class="card hero-card mb-3"><div class="hero-split"><div>
        <div class="eyebrow">Student dashboard</div>
        <h2 class="mt-1">${A.greet()}, ${A.firstName(p)}</h2>
        <p class="muted mt-1" style="max-width:46ch">${lead}</p>
        <div class="hero-meta">
          <a class="hero-chip" href="${A.link("student/schedule")}">${icon("clock", 14)} ${classesToday} class${classesToday === 1 ? "" : "es"} today</a>
          ${atRisk.length ? html`<a class="hero-chip warn" href="${A.link("student/attendance")}">${icon("alert", 14)} ${atRisk.length} subject${atRisk.length === 1 ? "" : "s"} below 75%</a>` : ""}
          ${uc.posts + uc.msgs ? html`<a class="hero-chip" href="${A.link("student/comm")}">${icon("bell", 14)} ${uc.posts + uc.msgs} new</a>` : ""}
        </div>
        ${nc ? html`<div class="next-class"><div class="nc-ico">${icon(nc.now ? "zap" : "clock", 22)}</div><div><small>${nc.now ? "In progress · ends in " + human(nc.left) : "Up next · starts in " + human(nc.left)}</small><b>${nc.l.subject}</b> <span style="opacity:.8;font-size:.85rem">· ${A.time12(nc.l.slot.start)} – ${A.time12(nc.l.slot.end)}</span></div></div>` : ""}
      </div>${U.ring(ov.pct, { size: 158, label: "attendance" })}</div></div>

    ${!p.prn ? html`<div class="hint-box warn mb-3">${icon("info", 18)}<div class="grow"><b>Finish setting up.</b> Add your PRN so your teacher can enrol you.</div><a class="btn sm warn" href="${A.link("student/profile?tab=academic")}">Add PRN</a></div>` : ""}

    <div class="grid cols-4 home-stats mb-3">
      <div class="stat tone-good"><div class="ico">${icon("check-circle", 20)}</div><div class="label">Present</div><div class="value">${ov.present}</div><div class="hint">classes attended</div></div>
      <div class="stat tone-bad"><div class="ico">${icon("x-circle", 20)}</div><div class="label">Absent</div><div class="value">${ov.absent}</div><div class="hint">classes missed</div></div>
      <div class="stat ${atRisk.length ? "tone-warn" : "tone-good"}"><div class="ico">${icon("target", 20)}</div><div class="label">At risk</div><div class="value">${atRisk.length}</div><div class="hint">of ${rs.length} subject${rs.length === 1 ? "" : "s"}</div></div>
      <div class="stat violet"><div class="ico">${icon("award", 20)}</div><div class="label">Subjects passed</div><div class="value">${passed}</div><div class="hint">${pending ? pending + " pending" : "of " + items.length + " graded"}</div></div>
    </div>

    <div class="split-2">
      <div class="card"><div class="card-head"><div><h3>Subjects &amp; attendance</h3><div class="sub">Minimum required: 75%</div></div><a class="btn ghost sm" href="${A.link("student/attendance")}">All subjects</a></div>
        <div class="list">${A.each(rs, function (r) {
          return html`<a class="item clickable" href="${A.link("student/attendance/" + r.d.id)}" style="color:inherit;text-decoration:none;align-items:center">${U.ring(r.pct, { size: 54, stroke: 6, tick: false, text: Math.round(r.pct) + "" })}
            <div class="grow"><h4>${r.d.subject}</h4><div class="meta">${r.d.name} · ${r.present}/${r.total} present</div>${r.advice ? html`<div class="advice ${r.advice.tone}">${icon("info", 14)}<span>${r.advice.text}</span></div>` : ""}</div>${icon("chevron-right", 18)}</a>`;
        }, U.empty("calendar", "No attendance recorded yet. Once your teacher adds you to a division, your subjects appear here."))}</div></div>
      <div class="grid" style="align-content:start">
        <div class="card"><div class="card-head"><div><h3>Today's classes</h3><div class="sub">${tt ? "From your division timetable" : "Timetable not published yet"}</div></div><a class="btn ghost sm" href="${A.link("student/schedule")}">Full week</a></div>
          ${A.each(today, function (l) {
            return html`<div class="today-row ${l.isNow ? "now" : ""}"><div class="today-time">${A.time12(l.slot.start)} – ${A.time12(l.slot.end)}</div>
              <div class="grow today-subj">${l.isBreak ? html`<span class="muted">${icon("coffee", 14)} ${l.subject}</span>` : l.subject}</div>${l.isNow ? html`<span class="badge info">Now</span>` : ""}</div>`;
          }, html`<p class="muted small">${tt ? "No classes scheduled for today. Enjoy the day." : "Once your teacher publishes the timetable, today's classes appear here."}</p>`)}</div>
        <div class="card"><div class="card-head"><h3>Upcoming assignments</h3><a class="btn ghost sm" href="${A.link("student/comm?tab=assignments")}">View all</a></div>
          <div class="list">${A.each(upcoming, function (a) {
            return html`<div class="item clickable" data-act="open-post" data-id="${a.id}" style="align-items:center"><div class="ico-box purple">${icon("clipboard", 19)}</div><div class="grow"><h4>${a.title}</h4><div class="meta">${a.maxMarks} marks</div></div>${dueChip(a.dueDate)}</div>`;
          }, html`<p class="muted small">Nothing due. Enjoy the breathing room.</p>`)}</div></div>
        ${latest ? html`<div class="card clickable" data-act="open-post" data-id="${latest.id}" style="cursor:pointer"><div class="card-head"><h3>Latest announcement</h3>${A.q.seen(latest.id) ? "" : html`<span class="badge bad">NEW</span>`}</div>
          <h4>${latest.title}</h4><p class="muted small mt-1">${latest.teacherName} · ${A.tsLong(latest.created)}</p><p class="mt-1 small">${latest.body.length > 120 ? latest.body.slice(0, 120) + "…" : latest.body}</p></div>` : ""}
      </div></div>`;
  });

  // ================================================================== STUDENT ATTENDANCE (list)
  replace("student/attendance", function () {
    var rs = rows(), ov = overall(rs), risk = rs.filter(function (r) { return r.pct < 75; }).length;
    return html`${U.head("My attendance", ov.total ? "Overall " + ov.pct + "% across " + ov.total + " classes. Open a subject for the calendar and planner." : "No classes recorded yet.")}
      <div class="card mb-3"><div class="sub-ring-row">${U.ring(ov.pct, { size: 112, label: "overall" })}
        <div class="grow"><div class="grid cols-3" style="gap:10px"><div><div class="muted small">Present</div><b style="font-size:1.4rem" class="text-good">${ov.present}</b></div><div><div class="muted small">Absent</div><b style="font-size:1.4rem" class="text-bad">${ov.absent}</b></div><div><div class="muted small">Total</div><b style="font-size:1.4rem">${ov.total}</b></div></div>
        ${ov.advice ? html`<div class="advice ${ov.advice.tone}">${icon("info", 14)}<span>${ov.advice.text}</span></div>` : ""}</div></div></div>
      ${rs.length ? html`<div class="filters" role="group" aria-label="Filter subjects"><button class="fchip on" data-act="att-filter" data-f="all">All <span class="n">${rs.length}</span></button>
        <button class="fchip" data-act="att-filter" data-f="bad">${icon("alert", 14)} Needs attention <span class="n">${risk}</span></button><button class="fchip" data-act="att-filter" data-f="good">${icon("check-circle", 14)} On track <span class="n">${rs.length - risk}</span></button></div>` : ""}
      <div class="cards-auto">${A.each(rs, function (r) {
        return html`<a class="att-card" data-tone="${r.pct < 75 ? "bad" : "good"}" href="${A.link("student/attendance/" + r.d.id)}">${U.ring(r.pct, { size: 76, stroke: 8, text: Math.round(r.pct) + "%" })}
          <div class="grow"><h4>${r.d.subject}</h4><div class="meta">${r.d.name} · ${r.d.teacherName}</div><div class="meta">${r.present}/${r.total} present</div>${r.advice ? html`<div class="advice ${r.advice.tone}">${icon("info", 14)}<span>${r.advice.text}</span></div>` : ""}</div></a>`;
      }, html`<div style="grid-column:1/-1">${U.empty("calendar", "No attendance records found yet.")}</div>`)}</div>`;
  });
  A.acts["att-filter"] = function (el) {
    var f = el.getAttribute("data-f");
    document.querySelectorAll(".fchip").forEach(function (c) { c.classList.toggle("on", c === el); });
    document.querySelectorAll(".att-card").forEach(function (c) { c.style.display = f === "all" || c.getAttribute("data-tone") === f ? "" : "none"; });
  };

  // ================================================================== STUDENT ATTENDANCE (one subject)
  function ymOf(d) { return d.slice(0, 7); }
  function calHTML(rec, ym) {
    var y = +ym.slice(0, 4), m = +ym.slice(5, 7) - 1, first = new Date(y, m, 1), startDow = (first.getDay() + 6) % 7, days = new Date(y, m + 1, 0).getDate();
    var names = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"], today = A.today(), cells = "";
    for (var i = 0; i < startDow; i++) cells += '<div class="cal-d out"></div>';
    for (var d = 1; d <= days; d++) {
      var key = ym + "-" + (d < 10 ? "0" : "") + d, v = rec[key], cls = v === true ? "P" : v === false ? "A" : "";
      cells += '<div class="cal-d ' + cls + (key === today ? " today" : "") + '" ' + (cls ? 'title="' + (cls === "P" ? "Present" : "Absent") + '"' : "") + ">" + d + "</div>";
    }
    return '<div class="cal-head"><button class="icon-btn" data-act="cal-nav" data-dir="-1" aria-label="Previous month">' + A.str(icon("chevron-left", 18)) + "</button><b>" + names[m] + " " + y + '</b><button class="icon-btn" data-act="cal-nav" data-dir="1" aria-label="Next month">' + A.str(icon("chevron-right", 18)) +
      '</button></div><div class="cal-grid">' + ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map(function (x) { return '<div class="cal-dow">' + x + "</div>"; }).join("") + cells + "</div>" +
      '<div class="cal-legend"><span><i style="background:var(--good)"></i>Present</span><span><i style="background:var(--bad)"></i>Absent</span><span><i style="background:var(--accent)"></i>Today</span></div>';
  }
  A.acts["cal-nav"] = function (el) {
    var box = el.closest("[data-cal]"), rec = JSON.parse(box.getAttribute("data-rec")), ym = box.getAttribute("data-ym"), y = +ym.slice(0, 4), m = +ym.slice(5, 7) - 1 + (+el.getAttribute("data-dir"));
    var nd = new Date(y, m, 1), nym = nd.getFullYear() + "-" + (nd.getMonth() < 9 ? "0" : "") + (nd.getMonth() + 1);
    box.setAttribute("data-ym", nym); box.innerHTML = calHTML(rec, nym);
  };
  function whatIf(box) {
    var pr = +box.getAttribute("data-p"), tot = +box.getAttribute("data-t"), mode = box.getAttribute("data-mode"), n = +box.querySelector(".wi-range").value;
    var np = mode === "miss" ? pr : pr + n, nt = tot + n, pct = A.pct(np, nt), out = box.querySelector(".wi-out");
    out.innerHTML = "<b class=\"" + (pct < 75 ? "text-bad" : "text-good") + "\">" + pct + "%</b><span class=\"muted\">" + (pct < 75 ? "below the 75% minimum" : "still at or above 75%") + "</span>";
    box.querySelector(".wi-n").textContent = n;
  }
  A.acts["wi-mode"] = function (el) {
    var box = el.closest(".whatif"); box.setAttribute("data-mode", el.getAttribute("data-m"));
    box.querySelectorAll(".fchip").forEach(function (c) { c.classList.toggle("on", c === el); });
    box.querySelector(".wi-verb").textContent = el.getAttribute("data-m") === "miss" ? "miss" : "attend"; whatIf(box);
  };
  document.addEventListener("input", function (e) { if (e.target.classList && e.target.classList.contains("wi-range")) whatIf(e.target.closest(".whatif")); });

  replace("student/attendance/:id", function (ctx) {
    var d = A.q.div(ctx.params.id), r = d ? A.q.records(d.id, A.q.uid()) : {}, dates = Object.keys(r).sort().reverse();
    if (!d || !dates.length) return html`${U.head("Attendance", "")}${U.empty("calendar", "No attendance records found for that subject yet.")}<p class="mt-3"><a class="btn ghost" href="${A.link("student/attendance")}">Back</a></p>`;
    var present = dates.filter(function (x) { return r[x]; }).length, pct = A.pct(present, dates.length), adv = A.advice(present, dates.length);
    var streak = 0; for (var i = 0; i < dates.length && r[dates[i]]; i++) streak++;
    var last = dates.slice(0, 14).reverse();
    return html`<a class="btn ghost sm mb-3" href="${A.link("student/attendance")}">${icon("arrow-left", 16)} Back to subjects</a>
      ${U.head(d.subject, d.name + " · " + d.teacherName)}
      ${adv ? html`<div class="hint-box ${adv.tone} mb-3">${icon("info", 18)}<div>${adv.text}</div></div>` : ""}
      <div class="grid cols-4 mb-3"><div class="stat"><div class="ico">${icon("target", 20)}</div><div class="label">Attendance</div><div class="value ${pct < 75 ? "text-bad" : "text-good"}">${pct}%</div></div>
        <div class="stat tone-good"><div class="ico">${icon("check-circle", 20)}</div><div class="label">Present</div><div class="value">${present}</div></div>
        <div class="stat tone-bad"><div class="ico">${icon("x-circle", 20)}</div><div class="label">Absent</div><div class="value">${dates.length - present}</div></div>
        <div class="stat amber"><div class="ico">${icon("flame", 20)}</div><div class="label">Current streak</div><div class="value">${streak}</div><div class="hint">class${streak === 1 ? "" : "es"} in a row</div></div></div>
      <div class="split-2 mb-3">
        <div class="card"><div class="cal" data-cal data-ym="${ymOf(dates[0])}" data-rec="${JSON.stringify(r)}">${A.raw(calHTML(r, ymOf(dates[0])))}</div></div>
        <div class="grid" style="align-content:start">
          <div class="card"><h3 class="mb-2">Last ${last.length} classes</h3><div class="dots">${last.map(function (x) { return html`<i class="${r[x] ? "P" : "A"}" title="${A.dLong(x)}"></i>`; })}</div><p class="muted small mt-2">Oldest on the left, most recent on the right.</p></div>
          <div class="card"><h3 class="mb-1">Plan ahead</h3><p class="muted small mb-2">See how your percentage changes over the next classes.</p>
            <div class="whatif" data-p="${present}" data-t="${dates.length}" data-mode="miss"><div class="filters" style="margin:0"><button class="fchip on" data-act="wi-mode" data-m="miss">If I miss</button><button class="fchip" data-act="wi-mode" data-m="attend">If I attend</button></div>
              <div>Next <b class="wi-n">3</b> classes - I <span class="wi-verb">miss</span></div><input class="wi-range" type="range" min="1" max="15" value="3" data-nodirty aria-label="Number of classes">
              <div class="wi-out">${A.raw('<b class="' + (A.pct(present, dates.length + 3) < 75 ? "text-bad" : "text-good") + '">' + A.pct(present, dates.length + 3) + '%</b><span class="muted">' + (A.pct(present, dates.length + 3) < 75 ? "below the 75% minimum" : "still at or above 75%") + "</span>")}</div></div></div>
        </div></div>
      <h3 class="mb-2">Day-by-day record</h3>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Date</th><th>Teacher</th><th class="c">Status</th></tr></thead><tbody>${dates.map(function (x) {
        return html`<tr><td>${A.dow(x)}, ${A.dLong(x)}</td><td>${d.teacherName}</td><td class="c">${r[x] ? html`<span class="badge good">Present</span>` : html`<span class="badge bad">Absent</span>`}</td></tr>`;
      })}</tbody></table></div>`;
  });

  // ================================================================== STUDENT GRADEBOOK
  replace("student/gradebook", function () {
    var items = A.store.gradeItems.slice().sort(function (a, b) { return A.natCmp(a.title, b.title); }), uid = A.q.uid();
    var gs = items.map(function (it) { return { it: it, g: A.grade(A.q.mark(it.id, uid), it.finalMax) }; });
    var cnt = function (k) { return gs.filter(function (x) { return x.g.overall === k; }).length; };
    var inel = gs.filter(function (x) { return /^INELIGIBLE|^FAILED/.test(x.g.overall); }).length;
    return html`${U.head("My subject gradebook", "Unit tests are out of 30 each. UT-1 + UT-2 must reach 18 to sit the final exam; the final pass mark is 30%.")}
      ${gs.length ? html`<div class="sum-strip"><div class="stat tone-good"><div class="label">Passed</div><div class="value">${cnt("PASSED")}</div></div><div class="stat tone-warn"><div class="label">Pending</div><div class="value">${cnt("PENDING")}</div></div><div class="stat tone-bad"><div class="label">Needs attention</div><div class="value">${inel}</div></div><div class="stat"><div class="label">Subjects</div><div class="value">${gs.length}</div></div></div>` : ""}
      <div class="list" style="gap:18px">${A.each(gs, function (x) {
        var it = x.it, g = x.g, st = g.overall === "PASSED" ? "pass" : g.overall === "PENDING" ? "pending" : "fail", tone = st === "pass" ? "solid-good" : st === "pending" ? "solid-warn" : "solid-bad";
        var need = Math.ceil(it.finalMax * A.FINAL_RATIO), msg, mt = "info";
        if (!g.entered) msg = "Waiting for your unit test marks.";
        else if (!g.cpass && (g.ut1 === null || g.ut2 === null)) msg = "You need " + Math.max(0, A.COMBINED_PASS - g.combined) + " more mark" + (A.COMBINED_PASS - g.combined === 1 ? "" : "s") + " across the remaining unit test to reach 18.";
        else if (!g.cpass) { msg = "Unit tests total " + g.combined + " of the 18 needed, so the final exam is locked."; mt = "bad"; }
        else if (g.fin === null) msg = "Eligible for the final exam. You need at least " + need + " out of " + it.finalMax + " to pass.";
        else msg = g.fin >= need ? "Passed. You scored " + g.fin + " and the pass mark was " + need + "." : "You scored " + g.fin + "; the pass mark was " + need + ".";
        return html`<div class="card grade-card is-${st}"><div class="flex justify-between gap-2 wrap items-center"><h3 style="font-size:1.2rem">${it.title} <span class="muted small">(${it.divisionName})</span></h3><span class="badge ${tone}" style="padding:7px 14px;font-size:.8rem">${g.overall}</span></div>
          <div class="grade-parts">
            <div class="grade-part"><div class="t">UT-1</div><div class="v">${g.ut1 === null ? "—" : g.ut1} <span class="muted small">/ 30</span></div><div class="progress"><span class="${g.ut1 !== null && g.ut1 < 9 ? "bad" : "good"}" data-w="${g.ut1 === null ? 0 : (g.ut1 / 30 * 100).toFixed(1)}"></span></div></div>
            <div class="grade-part"><div class="t">UT-2</div><div class="v">${g.ut2 === null ? "—" : g.ut2} <span class="muted small">/ 30</span></div><div class="progress"><span class="${g.ut2 !== null && g.ut2 < 9 ? "bad" : "good"}" data-w="${g.ut2 === null ? 0 : (g.ut2 / 30 * 100).toFixed(1)}"></span></div></div>
            <div class="grade-part ${g.cstatus === "PASS" ? "pass" : g.cstatus === "FAIL" ? "fail" : ""}"><div class="t">Combined (pass 18)</div><div class="v">${g.combined} <span class="small">/ 60</span></div><div class="small bold">${g.cstatus}</div></div>
            <div class="grade-part ${g.fstatus === "PASS" ? "pass" : g.fstatus === "FAIL" ? "fail" : ""}"><div class="t">Final exam</div><div class="v">${g.fin === null ? "—" : g.fin} <span class="muted small">/ ${it.finalMax}</span></div><div class="small bold">${g.fstatus}</div></div></div>
          <div class="need-line" ${mt === "bad" ? A.raw('style="background:var(--bad-bg);color:var(--bad)"') : ""}>${icon("target", 16)}<span>${msg}</span></div></div>`;
      }, U.empty("award", "No subject grades found for you yet. They appear here once your teacher creates a grade sheet."))}</div>`;
  });

  // ================================================================== TIMETABLE: table on big screens, day-by-day on phones
  var origTT = A.ttTable;
  A.ttTable = function (tt, edit) {
    if (edit) return origTT(tt, edit);
    var ti = A.todayIndex(), sel, now = A.nowHM(), monday = new Date(); monday.setDate(monday.getDate() - ((monday.getDay() + 6) % 7));
    sel = ti < 0 ? 0 : ti;
    var chips = A.DAYS.map(function (day, i) {
      var dt = new Date(monday); dt.setDate(monday.getDate() + i);
      return html`<button class="day-chip ${i === sel ? "on" : ""} ${i === ti ? "today" : ""}" data-act="tt-day" data-i="${i}" aria-label="${day}">${day.slice(0, 3)}<b>${dt.getDate()}</b></button>`;
    });
    var panels = A.DAYS.map(function (day, i) {
      var slots = (tt.slots || []).map(function (s) {
        var v = s.isBreak ? (s.name || "Break") : (tt.cells || {})[s.id + "_" + i], isNow = i === ti && s.start <= now && now < s.end;
        return html`<div class="ag-slot ${s.isBreak ? "brk" : !v ? "free" : ""} ${isNow ? "now" : ""}"><div class="t"><b>${A.time12(s.start)}</b>${A.time12(s.end)}</div><div class="s">${s.isBreak ? html`${icon("coffee", 15)} ${v}` : v || html`<span class="muted" style="font-weight:500">Free period</span>`}</div></div>`;
      });
      return html`<div class="agenda-day ${i === sel ? "on" : ""}" data-day="${i}">${slots.length ? slots : html`<div class="ag-empty">No time slots defined yet.</div>`}</div>`;
    });
    return html`<div class="tt-desktop">${origTT(tt, false)}</div><div class="agenda"><div class="day-chips" role="tablist">${chips}</div>${panels}</div>`;
  };
  A.acts["tt-day"] = function (el) {
    var i = el.getAttribute("data-i");
    document.querySelectorAll(".day-chip").forEach(function (c) { c.classList.toggle("on", c === el); });
    document.querySelectorAll(".agenda-day").forEach(function (p) { p.classList.toggle("on", p.getAttribute("data-day") === i); });
  };

  // ================================================================== COMM HUB: search + mark all as seen
  wrap("student/comm", function (orig, ctx) {
    var out = A.str(orig(ctx)), tab = ctx.q.tab || "announcements";
    if (tab === "announcements" || tab === "assignments") {
      var unseen = A.q.posts().filter(function (p) { return !A.q.seen(p.id) && (tab === "announcements" ? p.type === "announcement" : p.type === "assignment"); }).length;
      var bar = '<div class="toolbar"><div class="search">' + A.str(icon("search", 18)) + '<input class="input" type="search" placeholder="Search ' + tab + '…" data-filter-items=".list .item" data-nodirty aria-label="Search"></div>' +
        (unseen ? '<button class="btn ghost sm" data-act="mark-all-seen">' + A.str(icon("check-circle", 16)) + " Mark all as seen (" + unseen + ")</button>" : "") + "</div>";
      out = out.replace('</div><div class="list">', "</div>" + bar + '<div class="list">');
    }
    return A.raw(out);
  });
  A.acts["mark-all-seen"] = function () {
    var ids = A.q.posts().filter(function (p) { return !A.q.seen(p.id); }).map(function (p) { return p.id; });
    return Promise.all(ids.map(function (id) { return A.svc.markSeen(id); })).then(function () { A.toast("Everything marked as seen."); A.refresh(); });
  };

  // ================================================================== COMPARISON with summary
  replace("student/comparison", function () {
    var rs = rows(), chart = rs.map(function (r) { return { label: r.d.name, sub: r.d.subject, pct: r.pct, detail: r.present + " / " + r.total + " classes" }; });
    var best = rs.slice().sort(function (a, b) { return b.pct - a.pct; })[0], low = rs.slice().sort(function (a, b) { return a.pct - b.pct; })[0];
    var avg = rs.length ? Math.round(rs.reduce(function (s, r) { return s + r.pct; }, 0) / rs.length * 10) / 10 : 0;
    return html`${U.head("Per Division Comparison", "Your attendance percentage in each division. The amber line is the 75% minimum.")}
      ${rs.length ? html`<div class="sum-strip"><div class="stat"><div class="label">Average</div><div class="value">${avg}%</div></div><div class="stat tone-good"><div class="label">Strongest</div><div class="value" style="font-size:1.15rem">${best.d.subject}</div><div class="hint">${best.pct}%</div></div>
        <div class="stat ${low.pct < 75 ? "tone-bad" : "tone-warn"}"><div class="label">Needs most work</div><div class="value" style="font-size:1.15rem">${low.d.subject}</div><div class="hint">${low.pct}%</div></div></div>` : ""}${U.bars(chart)}`;
  });

  // ================================================================== TEACHER HOME: division overview
  wrap("teacher/home", function (orig, ctx) {
    var divs = A.q.divs();
    var cards = divs.map(function (d) {
      var p = 0, t = 0; d.roster.forEach(function (r) { var s = A.q.attStats(r.uid, [d.id]); p += s.present; t += s.total; });
      return { d: d, pct: A.pct(p, t), t: t };
    });
    if (!divs.length) return orig(ctx);
    return html`${orig(ctx)}<div class="card mt-3"><div class="card-head"><div><h3>Division overview</h3><div class="sub">Average attendance per division</div></div><a class="btn ghost sm" href="${A.link("teacher/attendance")}">Manage</a></div>
      <div class="cards-auto">${cards.map(function (c) {
        return html`<a class="att-card" href="${A.link("teacher/attendance/" + c.d.id)}">${U.ring(c.t ? c.pct : 0, { size: 64, stroke: 7, tick: false, text: c.t ? Math.round(c.pct) + "%" : "—", tone: c.t ? undefined : "brand" })}<div class="grow"><h4>${c.d.name}</h4><div class="meta">${c.d.subject}</div><div class="meta">${c.d.roster.length} student${c.d.roster.length === 1 ? "" : "s"}</div></div></a>`;
      })}</div></div>`;
  });

  // ================================================================== HELP: FAQ
  wrap("account/help", function (orig, ctx) {
    var teacher = P().role === "teacher";
    var faq = teacher ? [
      ["How do I take attendance?", "Open Attendance Sheet, choose a division, tick “Record a new date”, mark who was present and press Save all attendance data."],
      ["How do students join my division?", "Open the division and add the student by PRN and roll number. They must have the same PRN saved in their profile."],
      ["Can I fix a wrong mark?", "Yes. In the attendance sheet tap any P or A to flip it, then save. Marks in the gradebook can be edited the same way."],
      ["How do the unit test rules work?", "UT-1 and UT-2 are out of 30. Their total must reach 18 before a student can sit the final exam, which has a 30% pass mark."]
    ] : [
      ["How is the 75% attendance rule calculated?", "Present classes divided by total classes in each subject. Acadance also tells you how many classes you can still miss, or how many you must attend, to stay at 75%."],
      ["Why can't I see any subjects?", "Your teacher adds you to a division using your PRN. Make sure your PRN is saved in Manage Profile, then ask your teacher to enrol you."],
      ["Why is the final exam locked?", "The final exam opens only after UT-1 + UT-2 reaches 18 out of 60."],
      ["Will I get notifications when the app is closed?", "Yes, on the Android app. Allow notifications in Settings and the app checks for new announcements about every 15 minutes."]
    ];
    faq = faq.concat([
      ["Does the app work offline?", "You can open the app and see the last data it loaded. Changes you make offline upload automatically when you reconnect."],
      ["I forgot my password.", "On the sign-in screen choose Forgot password. If you signed up without an e-mail address, ask your teacher or administrator for help."]
    ]);
    return html`${orig(ctx)}<h3 class="mt-3 mb-2">${icon("life-buoy", 18)} Frequently asked questions</h3>
      <div class="faq">${faq.map(function (f) { return html`<details><summary>${f[0]}</summary><div class="ans">${f[1]}</div></details>`; })}</div>`;
  });

  // ================================================================== PASSWORD: tips
  wrap("account/password", function (orig, ctx) {
    return html`${orig(ctx)}<div class="card mt-3" style="max-width:560px"><h3 class="mb-2">${icon("shield-check", 18)} Keep your account safe</h3>
      <ul class="small muted" style="margin:0;padding-left:18px;line-height:1.9"><li>Use at least 8 characters with upper and lowercase letters and a number.</li><li>Never share your password, even with a teacher.</li><li>Sign out on shared or public devices.</li></ul></div>`;
  });
})();
