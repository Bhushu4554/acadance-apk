/* ============================================================================
   ACADANCE SETTINGS  -  the only file you need to edit.

   1) Create a FREE Firebase project (see README.md, step 2) and paste the values of its
      "firebaseConfig" below, replacing every PASTE_... text.
   2) Leave everything else as it is.

   While PASTE_... values are present, Acadance runs in DEMO MODE: it works, but the data
   stays on this one device (nothing is shared between devices).
   ============================================================================ */
window.ACADANCE_CONFIG = {
  firebase: {
    apiKey: "AIzaSyB01KDTw-x-qt-8zpEBDmcqMVpnfwUScFY",
    authDomain: "acadance-9b30b.firebaseapp.com",
    projectId: "acadance-9b30b",
    storageBucket: "acadance-9b30b.firebasestorage.app",
    messagingSenderId: "695496653950",
    appId: "1:695496653950:web:b1417b055af04d99d16c2f"
  },
  // Students/teachers log in with a username. Firebase needs an e-mail, so we build  username@<this domain>.
  // (Users who type their own e-mail at sign-up use that instead.)
  version: "4.0",
  loginDomain: "acadance.app"
};
