/* Acadance data layer: picks the backend, keeps a live in-memory copy of everything the signed-in
   user may see (Firestore real-time listeners), and holds all the actions (sign-up, attendance, grades ...). */
(function () {
  "use strict";
  var A = window.A;
  var cfg = window.ACADANCE_CONFIG || {};

  var cfgOk = !!(cfg.firebase && cfg.firebase.apiKey && !/^PASTE/.test(cfg.firebase.apiKey));
  var fbLoaded = typeof window.firebase !== "undefined";
  A.cloudWanted = cfgOk;
  A.cloudFailed = cfgOk && !fbLoaded; // configured, but the Firebase scripts could not be loaded (offline?)
  var B = cfgOk && fbLoaded ? A.makeFirebaseBackend(cfg) : A.makeLocalBackend();
  A.cloud = B.cloud;
  var DB = (A.DB = B.DB);
  var AUTH = (A.AUTH = B.Auth);
  A.domain = cfg.loginDomain || "acadance.app";

  A.S = { user: null, profile: null, feed: null };
  A.ver = 0;
  A.lastSyncAt = 0;
  A.store = emptyStore();
  function emptyStore() {
    return { divisions: [], attendance: [], marks: [], gradeItems: [], timetables: [], posts: [], postsAll: [], postsMine: [],
      seen: [], msgIn: [], msgOut: [], teachers: [], students: {} };
  }

  // ------------------------------------------------------------------ messages for errors
  A.errMsg = function (e) {
    var code = (e && e.code) || "";
    var map = {
      "auth/wrong-password": "Invalid username or password.",
      "auth/invalid-credential": "Invalid username or password.",
      "auth/invalid-login-credentials": "Invalid username or password.",
      "auth/user-not-found": "Invalid username or password.",
      "auth/email-already-in-use": "That e-mail address is already registered.",
      "auth/weak-password": "Password is too weak (minimum 6 characters).",
      "auth/too-many-requests": "Too many attempts. Please wait a few minutes and try again.",
      "auth/network-request-failed": "No internet connection.",
      "auth/invalid-email": "Please enter a valid e-mail address.",
      "auth/requires-recent-login": "Please log in again and retry.",
      "permission-denied": "You do not have permission to do that.",
      "unavailable": "The cloud database is unreachable. Check your internet connection."
    };
    if (map[code]) return map[code];
    var m = (e && e.message) || String(e);
    if (/Missing or insufficient permissions/i.test(m)) return map["permission-denied"];
    return m;
  };

  // ------------------------------------------------------------------ live store
  var subs = [], dirSubs = [], dirKey = "", warned = false;
  function onErr(e) {
    if (warned) return; warned = true;
    A.toast("Cloud database error: " + A.errMsg(e) + " - check the Firestore rules (README step 4).", "error");
  }
  // A.ready turns true once every live listener has delivered its first snapshot (or after a safety timeout),
  // so screens can show skeleton loaders instead of flashing "nothing here yet" while data is still arriving.
  A.ready = false; var pendingFirst = {}, readyTimer = null;
  function markFirst(key) {
    if (A.ready || !pendingFirst[key]) return;
    delete pendingFirst[key];
    if (!Object.keys(pendingFirst).length) setReady();
  }
  function setReady() { clearTimeout(readyTimer); if (A.ready) return; A.ready = true; if (A.onReady) A.onReady(); }
  function changed() { A.ver++; A.lastSyncAt = Date.now(); if (A.onData) A.onData(); }

  A.stopStore = function () {
    subs.forEach(function (u) { if (u) u(); }); subs = [];
    dirSubs.forEach(function (u) { if (u) u(); }); dirSubs = []; dirKey = "";
    A.store = emptyStore(); A.S.feed = null;
    A.ready = false; pendingFirst = {}; clearTimeout(readyTimer);
  };

  function syncDirectory() {
    var all = [];
    A.store.divisions.forEach(function (d) { all = all.concat(d.studentUids || []); });
    var uids = A.uniq(all).sort(), key = uids.join(",");
    if (key === dirKey) return;
    dirKey = key;
    dirSubs.forEach(function (u) { if (u) u(); }); dirSubs = [];
    A.store.students = {};
    for (var i = 0; i < uids.length; i += 30) {
      (function (chunk) {
        dirSubs.push(DB.watch("directory", [["__id__", "in", chunk]], function (docs) {
          docs.forEach(function (d) { A.store.students[d.id] = d; });
          changed();
        }, onErr));
      })(uids.slice(i, i + 30));
    }
  }

  A.startStore = function () {
    A.stopStore();
    var uid = A.S.user.uid, role = A.S.profile.role;
    A.ready = false; pendingFirst = {};
    clearTimeout(readyTimer); readyTimer = setTimeout(setReady, 7000);
    function W(name, c, f) {
      pendingFirst[name] = 1;
      subs.push(DB.watch(c, f, function (docs) {
        A.store[name] = docs;
        markFirst(name);
        if (name === "divisions" && role === "teacher") syncDirectory();
        changed();
      }, onErr));
    }
    pendingFirst.profile = 1; pendingFirst.feed = 1;
    subs.push(DB.watchDoc("users", uid, function (d) { if (d) A.S.profile = d; markFirst("profile"); changed(); }, onErr));
    subs.push(DB.watchDoc("feed", uid, function (d) { A.S.feed = d || { activity: [], notifications: [] }; markFirst("feed"); changed(); }, onErr));
    W("msgIn", "messages", [["toUid", "==", uid]]);
    W("msgOut", "messages", [["fromUid", "==", uid]]);
    if (role === "teacher") {
      W("divisions", "divisions", [["teacherUid", "==", uid]]);
      W("attendance", "attendance", [["teacherUid", "==", uid]]);
      W("marks", "marks", [["teacherUid", "==", uid]]);
      W("gradeItems", "gradeItems", [["teacherUid", "==", uid]]);
      W("timetables", "timetables", [["teacherUid", "==", uid]]);
      W("posts", "posts", [["teacherUid", "==", uid]]);
    } else {
      W("divisions", "divisions", [["studentUids", "array-contains", uid]]);
      W("attendance", "attendance", [["studentUid", "==", uid]]);
      W("marks", "marks", [["studentUid", "==", uid]]);
      W("gradeItems", "gradeItems", [["studentUids", "array-contains", uid]]);
      W("timetables", "timetables", [["studentUids", "array-contains", uid]]);
      W("postsAll", "posts", [["scope", "==", "ALL"]]);
      W("postsMine", "posts", [["studentUids", "array-contains", uid]]);
      W("seen", "seen", [["uid", "==", uid]]);
      W("teachers", "directory", [["role", "==", "teacher"]]);
    }
  };

  // ------------------------------------------------------------------ read helpers over the store
  var cache = { ver: -1 };
  function idx() {
    if (cache.ver === A.ver) return cache;
    cache = { ver: A.ver, att: {}, marks: {}, seen: {} };
    A.store.attendance.forEach(function (d) { cache.att[d.id] = d.records || {}; });
    A.store.marks.forEach(function (d) { cache.marks[d.id] = d; });
    A.store.seen.forEach(function (d) { cache.seen[d.postId] = true; });
    return cache;
  }
  var Q = (A.q = {});
  Q.uid = function () { return A.S.user.uid; };
  Q.div = function (id) { return A.store.divisions.filter(function (d) { return d.id === id; })[0] || null; };
  Q.divs = function () { return A.store.divisions.slice().sort(function (a, b) { return A.natCmp(a.name, b.name); }); };
  Q.records = function (divId, uid) { return idx().att[divId + "_" + uid] || {}; };
  Q.mark = function (itemId, uid) { return idx().marks[itemId + "_" + uid] || null; };
  Q.seen = function (postId) { return !!idx().seen[postId]; };
  Q.item = function (id) { return A.store.gradeItems.filter(function (d) { return d.id === id; })[0] || null; };
  Q.timetable = function (divId) { return A.store.timetables.filter(function (d) { return d.id === divId; })[0] || null; };
  Q.posts = function () {
    var seen = {}, out = [];
    (A.S.profile.role === "teacher" ? A.store.posts : A.store.postsAll.concat(A.store.postsMine)).forEach(function (p) {
      if (!seen[p.id]) { seen[p.id] = 1; out.push(p); }
    });
    return out.sort(function (a, b) { return (b.created || 0) - (a.created || 0); });
  };
  Q.stu = function (uid) { return A.store.students[uid] || { name: "Student", prn: "" }; };
  /** attendance totals of one student in one division (or across the given divisions) */
  Q.attStats = function (uid, divIds) {
    var present = 0, total = 0;
    divIds.forEach(function (id) {
      var r = Q.records(id, uid);
      Object.keys(r).forEach(function (d) { total++; if (r[d]) present++; });
    });
    return { present: present, total: total, pct: A.pct(present, total) };
  };
  Q.unread = function () { return A.store.msgIn.filter(function (m) { return !m.read; }); };

  // ------------------------------------------------------------------ grade rules (same as the original app)
  A.UT_MAX = 30; A.COMBINED_PASS = 18; A.FINAL_RATIO = 0.3;
  A.grade = function (m, finalMax) {
    var ut1 = m && m.ut1 !== null && m.ut1 !== undefined ? m.ut1 : null;
    var ut2 = m && m.ut2 !== null && m.ut2 !== undefined ? m.ut2 : null;
    var fin = m && m.finalExam !== null && m.finalExam !== undefined ? m.finalExam : null;
    var entered = ut1 !== null || ut2 !== null, combined = (ut1 || 0) + (ut2 || 0), cpass = combined >= A.COMBINED_PASS;
    var fpass = fin !== null && fin >= finalMax * A.FINAL_RATIO;
    return {
      ut1: ut1, ut2: ut2, fin: fin, entered: entered, combined: combined, cpass: cpass, canFinal: entered && cpass,
      cstatus: !entered ? "PENDING" : cpass ? "PASS" : "FAIL",
      fstatus: !entered ? "PENDING" : !cpass ? "N/A" : fin === null ? "PENDING" : fpass ? "PASS" : "FAIL",
      overall: !entered ? "PENDING" : !cpass ? "INELIGIBLE (UT Fail)" : fin === null ? "PENDING" : fpass ? "PASSED" : "FAILED"
    };
  };

  // ------------------------------------------------------------------ feed (activity + notifications)
  function feed() { return A.S.feed || (A.S.feed = { activity: [], notifications: [] }); }
  A.svc = {};
  function me() { return A.S.profile; }
  function uid() { return A.S.user.uid; }
  function pushActivity(text) {
    var f = feed();
    f.activity = [{ ts: Date.now(), text: text }].concat(f.activity || []).slice(0, 30);
    return DB.set("feed", uid(), { activity: f.activity }, { merge: true });
  }
  function pushNotify(title, text) {
    var f = feed();
    f.notifications = [{ id: A.newId(), ts: Date.now(), title: title, text: text }].concat(f.notifications || []).slice(0, 40);
    return DB.set("feed", uid(), { notifications: f.notifications }, { merge: true });
  }
  A.svc.clearNotifications = function () { feed().notifications = []; return DB.set("feed", uid(), { notifications: [] }, { merge: true }); };

  // ------------------------------------------------------------------ accounts
  A.svc.register = function (role, o) {
    var uname = (o.username || "").trim();
    if (!/^[A-Za-z0-9._-]+$/.test(uname)) return Promise.reject(new Error("Username may only contain letters, numbers, dot, dash and underscore."));
    var key = "u_" + uname.toLowerCase();
    var email = ((o.email || "").trim() || uname.toLowerCase() + "@" + A.domain).toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return Promise.reject(new Error("Please enter a valid e-mail address."));
    // declared here (not inside a .then) so every step below can use it
    var fullName = ((o.name || "").trim()) || uname;
    var cred = null;
    return DB.get("logins", key).then(function (exists) {
      if (exists) throw new Error("This username is already taken.");
      A.registering = true;
      return AUTH.signUp(email, o.password).catch(function (e) {
        // An earlier attempt may have created the e-mail account but not finished.
        // If the same e-mail + password signs in and no login record exists, resume it.
        if (!e || e.code !== "auth/email-already-in-use") throw e;
        return AUTH.signIn(email, o.password).then(function (c) {
          return DB.get("logins", "u_" + uname.toLowerCase()).then(function (l) {
            if (l) throw e;
            return c;
          });
        }, function () { throw e; });
      });
    }).then(function (c) {
      cred = c;
      var base = { role: role, username: uname, name: fullName, mobile: o.mobile || "", createdAt: Date.now() };
      if (role === "teacher") base.adminKey = o.adminKey;
      return DB.set("users", cred.uid, base).catch(function (e) {
        return AUTH.deleteCurrent().catch(function () {}).then(function () {
          throw role === "teacher" ? new Error("Invalid Admin Key.") : e;
        });
      });
    }).then(function () {
      return role === "teacher" ? DB.update("users", cred.uid, { adminKey: DB.DELETE }) : null;
    }).then(function () {
      return DB.set("directory", cred.uid, { role: role, name: fullName, username: uname, prn: "" });
    }).then(function () {
      return DB.create("logins", key, { uid: cred.uid, email: email, username: uname }).catch(function () {
        throw new Error("This username is already taken.");
      });
    }).then(function () { A.registering = false; return A.afterAuth(); }, function (e) {
      // do not leave a half-made account that blocks the e-mail next time.
      // A.registering stays true a moment longer so the sign-out caused by the cleanup
      // does not redraw the sign-up form and wipe the error message / what the user typed.
      var cleanup = cred ? AUTH.deleteCurrent().catch(function () {}) : Promise.resolve();
      return cleanup.then(function () {
        setTimeout(function () { A.registering = false; }, 800);
        throw e;
      });
    });
  };

  A.svc.login = function (identifier, password) {
    var id = identifier.trim();
    return DB.get("logins", "u_" + id.toLowerCase()).then(function (l) { return l || DB.get("logins", "p_" + id); }).then(function (l) {
      if (!l) { var e = new Error("Invalid username or password."); e.code = "auth/invalid-credential"; throw e; }
      return AUTH.signIn(l.email, password);
    });
  };

  A.svc.forgot = function (identifier) {
    var id = identifier.trim();
    return DB.get("logins", "u_" + id.toLowerCase()).then(function (l) { return l || DB.get("logins", "p_" + id); }).then(function (l) {
      if (!l) throw new Error("No account found with that username or PRN.");
      if (l.email.slice(-("@" + A.domain).length) === "@" + A.domain)
        throw new Error("This account has no recovery e-mail. Please ask your teacher/administrator for help.");
      return AUTH.sendReset(l.email).then(function () { return l.email.replace(/^(.).*(@.*)$/, "$1***$2"); });
    });
  };

  A.svc.changePassword = function (oldPw, newPw) { return AUTH.changePassword(oldPw, newPw).then(function () { return pushActivity("Changed password"); }); };

  A.afterAuth = function () {
    var u = AUTH.current();
    if (!u) { A.S.user = null; A.S.profile = null; A.stopStore(); if (A.showAuth) A.showAuth(); return Promise.resolve(); }
    A.S.user = u;
    return DB.get("users", u.uid).then(function (p) {
      if (!p) {
        A.toast("Account profile not found. Please sign up again.", "error");
        return AUTH.signOut();
      }
      A.S.profile = p; A.startStore();
      if (A.enterApp) A.enterApp();
    }).catch(function (e) { A.toast(A.errMsg(e), "error"); });
  };

  // ------------------------------------------------------------------ profile
  A.svc.saveProfile = function (patch) {
    var p = me(), id = uid(), chain = Promise.resolve();
    if (patch.prn !== undefined && patch.prn !== (p.prn || "")) {
      var newPrn = patch.prn, oldPrn = p.prn || "";
      chain = chain.then(function () {
        if (!newPrn) return null;
        return DB.create("logins", "p_" + newPrn, { uid: id, email: A.S.user.email, username: p.username }).catch(function () {
          throw new Error("This PRN is already registered by another student.");
        });
      }).then(function () { return oldPrn ? DB.del("logins", "p_" + oldPrn) : null; });
    }
    return chain.then(function () { return DB.update("users", id, patch); }).then(function () {
      var dir = {};
      if (patch.name !== undefined) dir.name = patch.name;
      if (patch.prn !== undefined) dir.prn = patch.prn;
      return Object.keys(dir).length ? DB.set("directory", id, dir, { merge: true }) : null;
    }).then(function () { return pushActivity("Updated profile details"); });
  };

  /** profile picture: stored as a small data-URL inside the user's own document */
  A.svc.setPhoto = function (dataUrl) { return DB.update("users", uid(), { photo: dataUrl || DB.DELETE }); };

  // ------------------------------------------------------------------ teacher: divisions & students
  function syncAudience(div) {
    var ops = [], uids = div.studentUids;
    if (Q.timetable(div.id)) ops.push({ op: "update", c: "timetables", id: div.id, data: { studentUids: uids } });
    A.store.gradeItems.forEach(function (g) { if (g.divisionId === div.id) ops.push({ op: "update", c: "gradeItems", id: g.id, data: { studentUids: uids } }); });
    A.store.posts.forEach(function (p) { if (p.scope === div.id) ops.push({ op: "update", c: "posts", id: p.id, data: { studentUids: uids } }); });
    return ops.length ? DB.batch(ops) : Promise.resolve();
  }

  A.svc.createDivision = function (o) {
    var f = {};
    ["name", "subject", "faculty", "program", "sem", "year", "school"].forEach(function (k) { f[k] = (o[k] || "").trim(); });
    if (Object.keys(f).some(function (k) { return !f[k]; })) return Promise.reject(new Error("Please fill all fields to create a division."));
    if (A.store.divisions.some(function (d) { return d.name.toLowerCase() === f.name.toLowerCase(); }))
      return Promise.reject(new Error('A division named "' + f.name + '" already exists.'));
    f.teacherUid = uid(); f.teacherName = me().name; f.roster = []; f.studentUids = []; f.created = Date.now();
    return DB.set("divisions", DB.newId(), f).then(function () { return pushActivity("Created division: " + f.name); });
  };

  A.svc.deleteDivision = function (divId) {
    var d = Q.div(divId), ops = [{ op: "delete", c: "divisions", id: divId }];
    A.store.attendance.forEach(function (a) { if (a.divisionId === divId) ops.push({ op: "delete", c: "attendance", id: a.id }); });
    A.store.marks.forEach(function (m) { if (m.divisionId === divId) ops.push({ op: "delete", c: "marks", id: m.id }); });
    A.store.gradeItems.forEach(function (g) { if (g.divisionId === divId) ops.push({ op: "delete", c: "gradeItems", id: g.id }); });
    A.store.posts.forEach(function (p) { if (p.scope === divId) ops.push({ op: "delete", c: "posts", id: p.id }); });
    if (Q.timetable(divId)) ops.push({ op: "delete", c: "timetables", id: divId });
    return DB.batch(ops).then(function () { return pushActivity("Deleted division: " + d.name); });
  };

  A.svc.addStudent = function (divId, prn, roll) {
    var d = Q.div(divId); prn = (prn || "").trim(); roll = (roll || "").trim();
    if (!prn || !roll) return Promise.reject(new Error("Please enter both PRN and roll number."));
    var sp;
    return DB.get("logins", "p_" + prn).then(function (l) {
      if (!l) throw new Error("No student found with this PRN. The student must set their PRN in their profile first.");
      return DB.get("users", l.uid);
    }).then(function (u) {
      if (!u || u.role !== "student") throw new Error("No student found with this PRN.");
      sp = u;
      if (d.studentUids.indexOf(u.id) > -1 || d.roster.some(function (r) { return r.roll === roll; }))
        throw new Error("Student with this PRN or Roll No. already exists in this division.");
      var roster = d.roster.concat([{ uid: u.id, roll: roll }]);
      d.roster = roster; d.studentUids = roster.map(function (r) { return r.uid; });
      return DB.update("divisions", divId, { roster: d.roster, studentUids: d.studentUids });
    }).then(function () { return syncAudience(d); })
      .then(function () { return pushNotify("New Student Added", sp.name + " has been added to division " + d.name + "."); })
      .then(function () { pushActivity("Added " + sp.name + " to " + d.name); return sp.name; });
  };

  A.svc.removeStudent = function (divId, studentUid) {
    var d = Q.div(divId);
    var roster = d.roster.filter(function (r) { return r.uid !== studentUid; });
    d.roster = roster; d.studentUids = roster.map(function (r) { return r.uid; });
    var ops = [{ op: "update", c: "divisions", id: divId, data: { roster: d.roster, studentUids: d.studentUids } },
      { op: "delete", c: "attendance", id: divId + "_" + studentUid }];
    A.store.gradeItems.forEach(function (g) { if (g.divisionId === divId) ops.push({ op: "delete", c: "marks", id: g.id + "_" + studentUid }); });
    return DB.batch(ops).then(function () { return syncAudience(d); }).then(function () { return pushActivity("Removed " + Q.stu(studentUid).name + " from " + d.name); });
  };

  // ------------------------------------------------------------------ teacher: attendance
  A.svc.saveAttendance = function (divId, edits, newDate, presentUids) {
    var d = Q.div(divId), patches = {}, warn = "";
    d.roster.forEach(function (r) { patches[r.uid] = {}; });
    Object.keys(edits || {}).forEach(function (u) { if (patches[u]) Object.keys(edits[u]).forEach(function (date) { patches[u][date] = edits[u][date]; }); });
    var newAbsent = [];
    if (newDate) {
      var exists = d.roster.some(function (r) { return Q.records(divId, r.uid)[newDate] !== undefined; });
      if (exists) warn = "Attendance for that date already exists - edit it in the grid instead (other changes were saved).";
      else d.roster.forEach(function (r) {
        var p = presentUids.indexOf(r.uid) > -1; patches[r.uid][newDate] = p; if (!p) newAbsent.push(r.uid);
      });
    }
    var ops = d.roster.map(function (r) {
      return { op: "set", merge: true, c: "attendance", id: divId + "_" + r.uid,
        data: { divisionId: divId, studentUid: r.uid, teacherUid: uid(), records: patches[r.uid] } };
    });
    var notes = [];
    newAbsent.forEach(function (u) {
      var rec = {}, base = Q.records(divId, u);
      Object.keys(base).forEach(function (k) { rec[k] = base[k]; });
      Object.keys(patches[u]).forEach(function (k) { rec[k] = patches[u][k]; });
      var streak = 0, dates = Object.keys(rec).sort().reverse();
      for (var i = 0; i < dates.length; i++) { if (rec[dates[i]]) break; streak++; }
      if (streak >= 3) {
        var text = Q.stu(u).name + " has been absent for " + streak + " consecutive classes in division " + d.name + ".";
        if (!(feed().notifications || []).some(function (n) { return n.text === text; })) notes.push(text);
      }
    });
    return DB.batch(ops).then(function () {
      return notes.reduce(function (p, t) { return p.then(function () { return pushNotify("Consecutive Absence Alert", t); }); }, Promise.resolve());
    }).then(function () { pushActivity("Saved attendance for " + d.name); return warn; });
  };

  A.svc.sendReminder = function (studentUid) {
    var divIds = A.store.divisions.map(function (d) { return d.id; });
    var st = Q.attStats(studentUid, divIds), name = Q.stu(studentUid).name;
    var body = "Hello " + name + ", your attendance is currently " + st.pct + "%, which is below the required 75%. " +
      "Please attend upcoming classes regularly or meet me to discuss. - " + me().name;
    return A.svc.sendMessage(studentUid, name, body).then(function () { return pushActivity("Sent attendance reminder to " + name); });
  };

  // ------------------------------------------------------------------ teacher: gradebook
  A.svc.createGradeItem = function (o) {
    var title = (o.title || "").trim(), d = Q.div(o.divisionId), fm = A.int(o.finalMax);
    if (!title || !d || !fm || fm < 1) return Promise.reject(new Error("Please fill Subject Name, select a Division, and enter a valid Final Exam Max Marks."));
    if (A.store.gradeItems.some(function (g) { return g.divisionId === d.id && g.title.toLowerCase() === title.toLowerCase(); }))
      return Promise.reject(new Error('A grade item named "' + title + '" in division "' + d.name + '" already exists.'));
    var id = DB.newId();
    return DB.set("gradeItems", id, { teacherUid: uid(), divisionId: d.id, divisionName: d.name, title: title, finalMax: fm,
      studentUids: d.studentUids.slice(), created: Date.now() }).then(function () { pushActivity("Created grade sheet: " + title + " for " + d.name); return id; });
  };

  A.svc.saveMarks = function (itemId, entries) {
    var g = Q.item(itemId), d = Q.div(g.divisionId);
    function num(v, max) { if (v === "" || v === null || v === undefined) return null; var n = A.int(v); return n === null ? null : A.clamp(n, 0, max); }
    var ops = d.roster.map(function (r) {
      var e = entries[r.uid] || {};
      var m = { ut1: num(e.ut1, A.UT_MAX), ut2: num(e.ut2, A.UT_MAX) };
      var ok = (m.ut1 !== null || m.ut2 !== null) && (m.ut1 || 0) + (m.ut2 || 0) >= A.COMBINED_PASS;
      m.finalExam = ok ? num(e.final, g.finalMax) : null;
      m.itemId = itemId; m.divisionId = g.divisionId; m.studentUid = r.uid; m.teacherUid = uid();
      return { op: "set", c: "marks", id: itemId + "_" + r.uid, data: m };
    });
    return DB.batch(ops).then(function () { return pushActivity("Saved marks for " + g.title + " in " + d.name); });
  };

  A.svc.deleteGradeItem = function (itemId) {
    var g = Q.item(itemId), ops = [{ op: "delete", c: "gradeItems", id: itemId }];
    A.store.marks.forEach(function (m) { if (m.itemId === itemId) ops.push({ op: "delete", c: "marks", id: m.id }); });
    return DB.batch(ops).then(function () { return pushActivity("Deleted grade sheet: " + g.title + " (" + g.divisionName + ")"); });
  };

  // ------------------------------------------------------------------ teacher: timetable
  var DEFAULT_SLOTS = [["09:00", "10:00", false, ""], ["10:00", "11:00", false, ""], ["11:00", "12:00", false, ""],
    ["12:00", "13:00", true, "LUNCH BREAK"], ["13:00", "14:00", false, ""], ["14:00", "15:00", false, ""], ["15:00", "16:00", false, ""]];
  A.svc.createTimetable = function (divId) {
    var d = Q.div(divId);
    var slots = DEFAULT_SLOTS.map(function (s) { return { id: "s" + A.newId(), start: s[0], end: s[1], isBreak: s[2], name: s[3] }; });
    return DB.set("timetables", divId, { teacherUid: uid(), teacherName: me().name, divisionId: divId, divisionName: d.name,
      studentUids: d.studentUids.slice(), slots: slots, cells: {} }).then(function () { return pushActivity("Created default timetable structure for " + d.name); });
  };
  A.svc.saveTimetable = function (divId, slots, cells, note) {
    slots = slots.slice().sort(function (a, b) { return a.start < b.start ? -1 : a.start > b.start ? 1 : a.end < b.end ? -1 : 1; });
    return DB.update("timetables", divId, { slots: slots, cells: cells }).then(function () { return pushActivity(note || "Saved timetable for " + Q.div(divId).name); });
  };
  A.svc.deleteTimetable = function (divId) { return DB.del("timetables", divId).then(function () { return pushActivity("Deleted timetable for " + Q.div(divId).name); }); };

  // ------------------------------------------------------------------ communication
  function scopeInfo(scope) {
    if (scope === "ALL") return { scope: "ALL", scopeName: "ALL", studentUids: [] };
    var d = Q.div(scope);
    if (!d) throw new Error("Please choose a valid target.");
    return { scope: d.id, scopeName: d.name, studentUids: d.studentUids.slice() };
  }
  A.svc.postAnnouncement = function (o) {
    var title = (o.title || "").trim(), body = (o.body || "").trim();
    if (!title || !body) return Promise.reject(new Error("Please fill the title, message and choose a valid target."));
    var s = scopeInfo(o.scope);
    var doc = { type: "announcement", teacherUid: uid(), teacherName: me().name, title: title, body: body, created: Date.now() };
    Object.keys(s).forEach(function (k) { doc[k] = s[k]; });
    return DB.set("posts", DB.newId(), doc).then(function () { return pushActivity("Posted announcement: " + title + " to " + s.scopeName); });
  };
  A.svc.postAssignment = function (o) {
    var title = (o.title || "").trim(), desc = (o.description || "").trim(), mm = A.int(o.maxMarks);
    if (!title || !desc) return Promise.reject(new Error("Please fill the title, description and choose a valid target."));
    if (!o.dueDate || !mm || mm < 1) return Promise.reject(new Error("Please set a Due Date and Max Marks."));
    var s = scopeInfo(o.scope);
    var doc = { type: "assignment", teacherUid: uid(), teacherName: me().name, title: title, body: desc, dueDate: o.dueDate, maxMarks: mm, created: Date.now() };
    Object.keys(s).forEach(function (k) { doc[k] = s[k]; });
    return DB.set("posts", DB.newId(), doc).then(function () { return pushActivity("Created assignment: " + title + " for " + s.scopeName + ", due " + A.dmy(o.dueDate)); });
  };
  A.svc.deletePost = function (id) { return DB.del("posts", id).then(function () { return pushActivity("Deleted a post"); }); };
  A.svc.markSeen = function (postId) { return DB.set("seen", postId + "_" + uid(), { uid: uid(), postId: postId }); };

  A.svc.sendMessage = function (toUid, toName, body) {
    body = (body || "").trim();
    if (!body) return Promise.reject(new Error("Please write a message."));
    return DB.set("messages", DB.newId(), { fromUid: uid(), toUid: toUid, fromName: me().name, toName: toName, body: body, created: Date.now(), read: false });
  };
  A.svc.messageByPrn = function (prn, body) {
    prn = (prn || "").trim();
    return DB.get("logins", "p_" + prn).then(function (l) {
      if (!l) throw new Error("No student found with this PRN.");
      return DB.get("directory", l.uid);
    }).then(function (dir) {
      return A.svc.sendMessage(dir.id, dir.name, body).then(function () { pushActivity("Sent direct message to " + dir.name + " (" + prn + ")"); return dir.name; });
    });
  };
  A.svc.markRead = function (ids) {
    if (!ids.length) return Promise.resolve();
    return DB.batch(ids.map(function (id) { return { op: "update", c: "messages", id: id, data: { read: true } }; }));
  };
  A.svc.support = function (subject, message) {
    if (!(message || "").trim()) return Promise.reject(new Error("Please write a message before sending."));
    return DB.set("supportRequests", DB.newId(), { uid: uid(), name: me().name, subject: subject || "", message: message, created: Date.now() });
  };
})();
