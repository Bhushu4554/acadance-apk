/* Acadance 4 - shared UI layer: route progress bar, skeleton loaders, richer empty states, ring charts,
   animated counters, pull-to-refresh, back-to-top, password helpers. Loaded after ui.js. */
(function () {
  "use strict";
  var A = window.A, html = A.html, icon = A.icon, U = A.ui;
  var reduce = !!(window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches);

  // ------------------------------------------------------------------ thin progress bar at the top of the screen
  var barEl, barTimer, safe, active = 0;
  function bar() {
    if (!barEl) { barEl = document.getElementById("route-bar"); if (!barEl) { barEl = document.createElement("div"); barEl.id = "route-bar"; document.body.appendChild(barEl); } }
    return barEl;
  }
  A.bar = {
    start: function () {
      active++; if (active > 1) return;
      var b = bar(), v = 14;
      clearInterval(barTimer); clearTimeout(safe);
      b.style.transition = "none"; b.style.width = "0%"; b.classList.add("on"); void b.offsetWidth; b.style.transition = ""; b.style.width = v + "%";
      barTimer = setInterval(function () { v += (92 - v) * 0.12; b.style.width = v + "%"; }, 280);
      safe = setTimeout(function () { active = 1; A.bar.done(); }, 15000); // never leave the bar stuck
    },
    done: function () {
      if (active > 0) active--; if (active > 0) return;
      var b = bar(); clearInterval(barTimer); clearTimeout(safe);
      b.style.width = "100%";
      setTimeout(function () { b.classList.remove("on"); setTimeout(function () { if (!active) b.style.width = "0%"; }, 320); }, 240);
    }
  };

  // ------------------------------------------------------------------ skeleton screens (shown until the first data arrives)
  function s(cls, style) { return html`<div class="sk ${cls || ""}" ${style ? A.raw('style="' + A.esc(style) + '"') : ""}></div>`; }
  function statSk() { return html`<div class="sk-card"><div class="sk-row"><div class="grow">${s("sk-line w50")}${s("", "height:30px;width:40%")}</div>${s("sk-circle", "width:42px;height:42px")}</div></div>`; }
  function listSk(n) {
    var out = [];
    for (var i = 0; i < n; i++) out.push(html`<div class="sk-card"><div class="sk-row">${s("sk-circle", "width:44px;height:44px")}<div class="grow">${s("sk-line w70")}${s("sk-line w50")}</div></div></div>`);
    return out;
  }
  U.skeleton = function (parts) {
    var page = (parts && parts[1]) || "home", detail = parts && parts.length > 2, body;
    if (page === "home") body = html`<div class="sk-hero sk"></div>
      <div class="grid cols-3">${statSk()}${statSk()}${statSk()}</div>
      <div class="grid cols-2"><div class="sk-stack">${listSk(3)}</div><div class="sk-stack">${listSk(2)}</div></div>`;
    else if (detail || page === "schedule" || page === "export") body = html`${s("sk-title")}<div class="sk-card">${s("sk-line w90")}${s("sk-line w70")}${s("sk-line w90")}${s("sk-line w50")}${s("sk-line w90")}${s("sk-line w70")}${s("sk-line w90")}</div>`;
    else if (page === "profile" || page === "settings" || page === "password" || page === "help") body = html`${s("sk-title")}<div class="sk-card">${s("", "height:46px")}${s("", "height:46px")}${s("", "height:46px")}${s("", "height:90px")}</div>`;
    else body = html`${s("sk-title")}<div class="sk-stack">${listSk(4)}</div>`;
    return html`<div class="sk-wrap" aria-busy="true" role="status" aria-label="Loading your data">${body}<div class="sk-caption"><i></i> Loading your data…</div></div>`;
  };

  // ------------------------------------------------------------------ friendlier empty state
  U.empty = function (ic, text, action) {
    return html`<div class="empty"><div class="em-art">${icon(ic, 34)}</div><p>${text}</p>${action || ""}</div>`;
  };

  // ------------------------------------------------------------------ ring (donut) with a marker at the 75% target
  U.ring = function (pct, o) {
    o = o || {};
    var size = o.size || 120, sw = o.stroke || Math.max(8, Math.round(size / 11)), r = (size - sw) / 2, c = 2 * Math.PI * r, cx = size / 2;
    var p = A.clamp(+pct || 0, 0, 100), tone = o.tone || (o.brand ? "brand" : A.tone(p));
    var a = 1.5 * Math.PI, h = sw / 2 + 2, x1 = cx + (r - h) * Math.cos(a), y1 = cx + (r - h) * Math.sin(a), x2 = cx + (r + h) * Math.cos(a), y2 = cx + (r + h) * Math.sin(a);
    return html`<span class="ring ${tone}" style="width:${size}px;height:${size}px" role="img" aria-label="${Math.round(p)}%">
      <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"><circle class="trk" cx="${cx}" cy="${cx}" r="${r}" fill="none" stroke-width="${sw}"/>
      <circle class="val" cx="${cx}" cy="${cx}" r="${r}" fill="none" stroke-width="${sw}" stroke-linecap="round" stroke-dasharray="${c.toFixed(2)}" stroke-dashoffset="${c.toFixed(2)}" data-off="${(c * (1 - p / 100)).toFixed(2)}"/>
      ${o.tick === false ? "" : html`<line class="tick" x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke-width="3" stroke-linecap="round"/>`}</svg>
      <span class="ring-txt"><b style="font-size:${Math.round(size * 0.26)}px">${o.text !== undefined ? o.text : Math.round(p) + "%"}</b>${o.label ? html`<small>${o.label}</small>` : ""}</span></span>`;
  };

  // ------------------------------------------------------------------ password fields: show/hide + strength meter
  A.acts["pw-eye"] = function (el) {
    var inp = el.parentNode.querySelector("input"), show = inp.type === "password";
    inp.type = show ? "text" : "password";
    el.innerHTML = A.str(icon(show ? "eye-off" : "eye", 18)); el.setAttribute("aria-label", show ? "Hide password" : "Show password");
  };
  function strength(v) {
    var n = 0; if (v.length >= 8) n++; if (/[a-z]/.test(v) && /[A-Z]/.test(v)) n++; if (/\d/.test(v)) n++; if (/[^A-Za-z0-9]/.test(v)) n++;
    if (!v) return { n: 0, t: "Use 8+ characters with upper & lowercase letters and a number.", c: "var(--border-strong)" };
    return [{ n: 1, t: "Weak - add length and variety.", c: "var(--bad)" }, { n: 1, t: "Weak - add length and variety.", c: "var(--bad)" }, { n: 2, t: "Fair - almost there.", c: "var(--accent)" },
      { n: 3, t: "Good password.", c: "var(--good)" }, { n: 4, t: "Excellent password.", c: "var(--primary)" }][n];
  }
  function enhancePasswords(root) {
    if (!root) return;
    root.querySelectorAll('input[type="password"]').forEach(function (inp) {
      if (inp.closest(".pw-wrap") || inp.closest(".input-icon")) return;
      var w = document.createElement("span"); w.className = "pw-wrap"; w.style.display = "block";
      inp.parentNode.insertBefore(w, inp); w.appendChild(inp);
      var b = document.createElement("button"); b.type = "button"; b.className = "pw-eye"; b.setAttribute("data-act", "pw-eye"); b.setAttribute("aria-label", "Show password"); b.innerHTML = A.str(icon("eye", 18)); w.appendChild(b);
      if (inp.name === "new") {
        var m = document.createElement("div"); m.className = "pw-meter"; m.innerHTML = '<div class="bar"><i></i></div><small></small>'; w.parentNode.appendChild(m);
        var paint = function () { var r = strength(inp.value), i = m.querySelector("i"); i.style.width = r.n * 25 + "%"; i.style.background = r.c; m.querySelector("small").textContent = r.t; };
        inp.addEventListener("input", paint); paint();
      }
    });
  }

  // ------------------------------------------------------------------ animated numbers
  function countUp(root) {
    if (reduce || !root) return;
    root.querySelectorAll(".stat .value, [data-count]").forEach(function (el) {
      if (el.children.length) return;
      var m = /^(\d+(?:\.\d+)?)(%?)$/.exec(el.textContent.trim()); if (!m) return;
      var to = parseFloat(m[1]), dec = (m[1].split(".")[1] || "").length, suf = m[2], t0 = performance.now(), dur = 650;
      if (to === 0) return;
      (function step(t) {
        var k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
        el.textContent = (to * e).toFixed(dec) + suf;
        if (k < 1) requestAnimationFrame(step); else el.textContent = m[1] + suf;
      })(t0);
    });
  }

  // ------------------------------------------------------------------ hook run after every render
  A.afterRender = function (main, rt, info) {
    requestAnimationFrame(function () {
      setTimeout(function () { document.querySelectorAll("[data-off]").forEach(function (el) { el.style.strokeDashoffset = el.getAttribute("data-off"); }); }, 60);
    });
    document.querySelectorAll("img.avatar").forEach(function (img) {
      img.classList.add("img-fade");
      if (img.complete) img.classList.add("in"); else img.addEventListener("load", function () { img.classList.add("in"); }, { once: true });
    });
    if (!info.loading) { enhancePasswords(main); if (info.entering) countUp(main); }
  };

  // ------------------------------------------------------------------ live filter for card lists  <input data-filter-items=".list .item">
  document.addEventListener("input", function (e) {
    var f = e.target.closest && e.target.closest("[data-filter-items]");
    if (!f) return;
    var q = f.value.trim().toLowerCase(), n = 0;
    document.querySelectorAll(f.getAttribute("data-filter-items")).forEach(function (el) {
      var hit = !q || el.textContent.toLowerCase().indexOf(q) > -1; el.style.display = hit ? "" : "none"; if (hit) n++;
    });
    var none = document.getElementById("filter-none"); if (none) none.hidden = n > 0;
  }, true);

  // ------------------------------------------------------------------ skip link + back to top + pull to refresh
  document.addEventListener("click", function (e) {
    var sk = e.target.closest && e.target.closest("[data-skip]");
    if (sk) { e.preventDefault(); var c = document.getElementById("content") || document.getElementById("app"); if (c) { c.focus({ preventScroll: false }); c.scrollIntoView(); } }
    var t = e.target.closest && e.target.closest("#to-top");
    if (t) window.scrollTo({ top: 0, behavior: reduce ? "auto" : "smooth" });
  });
  var topBtn = null, ptr = null;
  function ensureChrome() {
    if (!topBtn) { topBtn = document.createElement("button"); topBtn.id = "to-top"; topBtn.type = "button"; topBtn.setAttribute("aria-label", "Back to top"); topBtn.innerHTML = A.str(icon("arrow-up", 20)); document.body.appendChild(topBtn); }
    if (!ptr) { ptr = document.createElement("div"); ptr.id = "ptr"; ptr.setAttribute("aria-hidden", "true"); ptr.innerHTML = A.str(icon("refresh", 20)); document.body.appendChild(ptr); }
  }
  var tick = false;
  window.addEventListener("scroll", function () {
    if (tick) return; tick = true;
    requestAnimationFrame(function () { tick = false; ensureChrome(); topBtn.classList.toggle("show", window.scrollY > 640 && !document.body.classList.contains("auth-body")); });
  }, { passive: true });

  var sy = 0, dy = 0, pulling = false;
  document.addEventListener("touchstart", function (e) {
    if (window.scrollY > 0 || !A.S.profile || A.modalOpen() || e.touches.length !== 1 || document.body.classList.contains("auth-body")) return;
    if (e.target.closest && e.target.closest(".table-wrap, .tabs, .modal, .notif-panel, .day-chips, input, textarea, select, .captcha")) return;
    ensureChrome(); sy = e.touches[0].clientY; dy = 0; pulling = true;
  }, { passive: true });
  document.addEventListener("touchmove", function (e) {
    if (!pulling) return;
    dy = e.touches[0].clientY - sy;
    if (dy < 0) { pulling = false; ptr.classList.remove("pull"); ptr.style.transform = ""; return; }
    if (dy > 10) { ptr.classList.add("pull"); ptr.style.transform = "translateY(" + (Math.min(dy * 0.45, 70) - 60) + "px) rotate(" + dy * 2.2 + "deg)"; }
  }, { passive: true });
  document.addEventListener("touchend", function () {
    if (!pulling) return; pulling = false;
    if (dy > 110) {
      if (A.dirty) { A.toast("Save your changes before refreshing.", "warning"); ptr.classList.remove("pull"); ptr.style.transform = ""; return; }
      ptr.style.transform = ""; ptr.classList.add("busy");
      if (A.bar) A.bar.start();
      setTimeout(function () { A.render(true); ptr.classList.remove("busy", "pull"); A.toast("Up to date.", "info"); }, 700);
    } else { ptr.classList.remove("pull"); ptr.style.transform = ""; }
  }, { passive: true });
})();
